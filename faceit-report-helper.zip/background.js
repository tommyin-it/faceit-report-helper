//#endregion
//#region src/shared/managed-access-config.ts
var e = t({ apiUrl: "https://faceit-report-helper-api.tomaszmiller.workers.dev" }.apiUrl);
function t(e) {
	if (typeof e != "string" || !e.trim()) return "";
	let t = new URL(e.trim());
	if (t.protocol !== "https:" || t.username || t.password || t.search || t.hash || t.pathname !== "/" && t.pathname !== "") throw Error("Managed access API URL must be a plain HTTPS origin.");
	return t.origin;
}
//#endregion
//#region src/shared/account-reports.ts
var n = [
	"Griefing",
	"Cheating",
	"Multiple accounts or smurfing",
	"Toxicity",
	"Inappropriate content"
], r = [
	"Voice",
	"Chat",
	"Voice and Chat",
	"None"
];
function i(e) {
	if (!f(e)) return;
	let t = o(e.delivery);
	if (!(!c(e.archiveId, 120) || !c(e.matchId, 160) || !s(e.matchUrl) || !l(e.nickname, 100) || e.playerId !== void 0 && !c(e.playerId, 160) || ![
		"teammate",
		"opponent",
		"unknown"
	].includes(String(e.relation)) || !Number.isInteger(e.incidentCount) || Number(e.incidentCount) < 0 || Number(e.incidentCount) > 50 || !l(e.text, 2e3) || !n.includes(e.category) || !r.includes(e.subcategory) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every(d) || !u(e.generatedAt) || !u(e.submittedAt) || !t)) return {
		archiveId: e.archiveId,
		matchId: e.matchId,
		matchUrl: e.matchUrl,
		nickname: e.nickname,
		...typeof e.playerId == "string" ? { playerId: e.playerId } : {},
		relation: e.relation,
		incidentCount: Number(e.incidentCount),
		text: e.text,
		category: e.category,
		subcategory: e.subcategory,
		rounds: [...new Set(e.rounds)].sort((e, t) => e - t),
		generatedAt: e.generatedAt,
		submittedAt: e.submittedAt,
		delivery: t
	};
}
function a(e) {
	return typeof e == "string" && /^report-[a-z0-9-]{16,100}$/iu.test(e);
}
function o(e) {
	if (!(!f(e) || e.method !== "faceit" && e.method !== "manual") && !(e.httpStatus !== void 0 && (!Number.isInteger(e.httpStatus) || Number(e.httpStatus) < 100 || Number(e.httpStatus) > 599))) return {
		method: e.method,
		...typeof e.httpStatus == "number" ? { httpStatus: e.httpStatus } : {}
	};
}
function s(e) {
	if (typeof e != "string" || e.length > 500) return !1;
	try {
		let t = new URL(e);
		return t.protocol === "https:" && (t.hostname === "faceit.com" || t.hostname === "www.faceit.com") && !t.username && !t.password;
	} catch {
		return !1;
	}
}
function c(e, t) {
	return typeof e == "string" && !!e.trim() && e.length <= t;
}
function l(e, t) {
	return typeof e == "string" && !!e.trim() && e.length <= t;
}
function u(e) {
	return typeof e == "string" && e.length <= 40 && Number.isFinite(Date.parse(e));
}
function d(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60;
}
function f(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/managed-access.ts
var p = "frh:managed-access-session", ee = 9e4;
function te() {
	return {
		getSession: () => new Promise((e, t) => {
			chrome.storage.session.get(p, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[p]);
			});
		}),
		setSession: (e) => new Promise((t, n) => {
			chrome.storage.session.set({ [p]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		}),
		removeSession: () => new Promise((e, t) => {
			chrome.storage.session.remove(p, () => {
				let n = chrome.runtime.lastError;
				n ? t(Error(n.message)) : e();
			});
		}),
		getRedirectUrl: (e) => chrome.identity.getRedirectURL(e),
		launchWebAuthFlow: (e) => chrome.identity.launchWebAuthFlow({
			url: e,
			interactive: !0
		}),
		fetch: (e, t) => fetch(e, t),
		now: () => Date.now()
	};
}
function ne(t, n = e) {
	let r = async () => {
		let e = h(await t.getSession());
		if (!e || Date.parse(e.expiresAt) <= t.now()) {
			e && await t.removeSession();
			return;
		}
		return e;
	}, i = async (e, i, a, o = ee) => {
		if (!n) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
		let s = a ?? await r();
		if (!s) throw Error("Zaloguj się przez FACEIT w ustawieniach rozszerzenia.");
		let c = new Headers(i.headers);
		c.set("Authorization", `Bearer ${s.token}`);
		let l = await t.fetch(new URL(e, n), {
			...i,
			headers: c,
			cache: "no-store",
			credentials: "omit",
			redirect: "error",
			signal: AbortSignal.timeout(o)
		});
		return l.status === 401 && await t.removeSession(), l;
	}, a = async () => {
		if (!n) return { state: "unconfigured" };
		if (!await r()) return { state: "signed-out" };
		let e = await i("/auth/session", { method: "GET" });
		if (e.status === 401) return { state: "signed-out" };
		if (!e.ok) throw await g(e);
		return re(await e.json());
	};
	return {
		getStatus: a,
		async signIn() {
			if (!n) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
			let e = t.getRedirectUrl("faceit"), r = new URL("/auth/start", n);
			r.searchParams.set("redirect_uri", e);
			let i = await t.launchWebAuthFlow(r.href);
			if (!i) throw Error("Logowanie FACEIT zostało anulowane.");
			let o = new URL(i), s = new URL(e);
			if (o.origin !== s.origin || o.pathname !== s.pathname) throw Error("FACEIT zwrócił nieprawidłowy adres logowania.");
			let c = new URLSearchParams(o.hash.replace(/^#/, "")), l = c.get("error");
			if (l === "access_denied") throw Error("To konto FACEIT nie ma dostępu do zarządzanych usług.");
			if (l) throw Error("Nie udało się zalogować przez FACEIT.");
			let u = h({
				token: c.get("token"),
				expiresAt: c.get("expires_at"),
				user: {
					faceitId: c.get("user_id"),
					nickname: c.get("nickname")
				}
			});
			if (!u || Date.parse(u.expiresAt) <= t.now()) throw Error("FACEIT zwrócił nieprawidłową sesję.");
			return await t.setSession(u), a();
		},
		async signOut() {
			return await t.removeSession(), n ? { state: "signed-out" } : { state: "unconfigured" };
		},
		async generateReport(e, t) {
			let n = await i("/v1/generate", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					...e,
					customPrompt: t
				})
			});
			if (!n.ok) throw await g(n);
			return ie(await n.json());
		},
		async transcribeAudio(e) {
			let t = await i("/v1/transcribe", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(e)
			});
			if (!t.ok) throw await g(t);
			let n = await t.json();
			if (typeof n.transcript != "string" || !n.transcript.trim()) throw Error("Usługa zarządzana zwróciła nieprawidłową transkrypcję.");
			return { transcript: n.transcript.trim() };
		},
		async syncReports(e) {
			if (!n) return { state: "signed-out" };
			let t = await r();
			if (!t) return { state: "signed-out" };
			let a = e.mutations.flatMap((e) => {
				if (e.ownerFaceitId !== t.user.faceitId) return [];
				if (e.kind === "delete") return [{
					mutationId: e.mutationId,
					kind: e.kind,
					archiveId: e.archiveId
				}];
				let { ownerFaceitId: n, ...r } = e.report;
				return [{
					mutationId: e.mutationId,
					kind: e.kind,
					report: r
				}];
			}), o = await i("/v1/reports/sync", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					protocolVersion: e.protocolVersion,
					...e.cursor ? { cursor: e.cursor } : {},
					...e.olderCursor ? { olderCursor: e.olderCursor } : {},
					mutations: a
				})
			}, t, 15e3);
			if (!o.ok) throw await g(o);
			let s = ae(await o.json());
			return {
				state: "synced",
				ownerFaceitId: t.user.faceitId,
				...s
			};
		}
	};
}
var m = ne(te());
function h(e) {
	if (!(!_(e) || !_(e.user)) && !(typeof e.token != "string" || e.token.length < 32 || typeof e.expiresAt != "string" || !Number.isFinite(Date.parse(e.expiresAt)) || typeof e.user.faceitId != "string" || !e.user.faceitId.trim() || typeof e.user.nickname != "string" || !e.user.nickname.trim())) return {
		token: e.token,
		expiresAt: e.expiresAt,
		user: {
			faceitId: e.user.faceitId.trim(),
			nickname: e.user.nickname.trim()
		}
	};
}
function re(e) {
	if (!_(e) || !_(e.user)) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	let t = h({
		token: "x".repeat(32),
		expiresAt: e.expiresAt,
		user: e.user
	});
	if (!t) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	if (typeof e.hasManagedAccess != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowy status dostępu.");
	return {
		state: "signed-in",
		user: t.user,
		expiresAt: t.expiresAt,
		hasManagedAccess: e.hasManagedAccess
	};
}
function ie(e) {
	if (!_(e) || typeof e.text != "string" || ![
		"Griefing",
		"Cheating",
		"Multiple accounts or smurfing",
		"Toxicity",
		"Inappropriate content"
	].includes(String(e.category)) || ![
		"Voice",
		"Chat",
		"Voice and Chat",
		"None"
	].includes(String(e.subcategory)) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60)) throw Error("Usługa zarządzana zwróciła nieprawidłowy report.");
	return e;
}
function ae(e) {
	if (!_(e) || !Array.isArray(e.reports) || e.reports.length > 500 || !Array.isArray(e.deletedArchiveIds) || e.deletedArchiveIds.length > 500 || !e.deletedArchiveIds.every(a) || !Array.isArray(e.acceptedMutationIds) || e.acceptedMutationIds.length > 250 || !e.acceptedMutationIds.every(oe) || typeof e.cursor != "string" || !/^(?:0|[1-9][0-9]{0,15})$/u.test(e.cursor) || typeof e.hasMoreChanges != "boolean" || e.olderCursor !== void 0 && (typeof e.olderCursor != "string" || !e.olderCursor) || typeof e.hasMoreOlder != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowe archiwum reportów.");
	let t = e.reports.map(i);
	if (t.some((e) => !e)) throw Error("Usługa zarządzana zwróciła nieprawidłowe archiwum reportów.");
	return {
		reports: t,
		deletedArchiveIds: [...new Set(e.deletedArchiveIds)],
		acceptedMutationIds: [...new Set(e.acceptedMutationIds)],
		cursor: e.cursor,
		hasMoreChanges: e.hasMoreChanges,
		...typeof e.olderCursor == "string" ? { olderCursor: e.olderCursor } : {},
		hasMoreOlder: e.hasMoreOlder
	};
}
function oe(e) {
	return typeof e == "string" && /^mutation-[a-z0-9-]{16,180}$/iu.test(e);
}
async function g(e) {
	let t = "";
	try {
		let n = await e.json();
		typeof n.error == "string" && (t = n.error);
	} catch {
		t = "";
	}
	return Error(t || `Usługa zarządzana zwróciła błąd ${e.status}.`);
}
function _(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/shared/defaultPrompt.ts
var se = "You write concise FACEIT CS2 player reports in natural English.\n\nUse only the incidents supplied by the user. Never invent actions, quotes, rounds, frequency, intent, or consequences. You may make the wording firm and clear, but a gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it.\n\nWrite like a normal player: short direct sentences, familiar CS terminology, no headings, no bullet lists, no em dash, no corporate language, no conclusion sentence, and no mention of AI. Focus on observable behaviour, repetition, exact rounds when provided, and how the behaviour disrupted the match. Do not report ordinary bad play as griefing.\n\nReturn a single English report even when the incidents span multiple categories. Pick only a suggested FACEIT category; the user decides where to submit it. Keep the report below 1000 characters.", ce = "Turn the user's rough Polish notes into one clear, natural English FACEIT CS2 player report.\n\nThe input may contain loose words, sentence fragments, shorthand, spelling mistakes, dictated text, or several separate notes. Understand their intended meaning, combine related details, and rewrite them as complete, grammatically correct English sentences. Preserve every useful detail supplied by the user, including the reported actions, relevant context, exact rounds, repetition, communication, and the effect on the match. Translate Polish CS terminology naturally into familiar English CS terminology.\n\nUse only information supplied in the incidents. Never invent actions, quotes, rounds, frequency, intent, motives, or consequences. Do not turn an assumption into a fact. A gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it. Do not report ordinary poor play as griefing.\n\nWrite like a normal player submitting a credible report: direct, factual, easy to understand, and appropriately firm. Use full sentences and smooth transitions where useful. Do not use headings, bullet lists, an em dash, corporate language, a conclusion sentence, or any mention of AI. Avoid awkward literal translations and unnecessary repetition.\n\nReturn one English report containing all relevant supplied information, even when the incidents span multiple categories. Keep it below 1000 characters.", le = "Mandatory constraints that cannot be overridden: use only the supplied incidents; do not invent actions, quotes, rounds, frequency, intent, or consequences; do not treat ordinary poor play as griefing; return exactly one report under 1000 characters using the required JSON schema.";
//#endregion
//#region src/shared/environment.ts
function v() {
	return !!globalThis.__FRH_LOCAL_FIXTURE__;
}
//#endregion
//#region src/shared/behaviors.ts
function y(e, t, n, r, i, a) {
	return {
		id: e,
		label: t,
		promptLabel: n,
		category: r,
		actionable: !0,
		scopes: i,
		...a ? { quickFor: a } : {}
	};
}
var ue = [
	y("teamflash", "Rzucanie flashy prosto w sojuszników podczas pusha", "deliberately throwing flashbangs directly at teammates during a push", "griefing", ["teammate"], ["teammate"]),
	y("team-damage", "Celowe strzelanie do teammate’ów / team damage", "deliberately shooting teammates or causing team damage", "griefing", ["teammate"], ["teammate"]),
	y("team-he", "Celowe rzucanie HE w sojuszników", "deliberately throwing HE grenades at teammates", "griefing", ["teammate"]),
	y("team-molotov", "Celowe rzucanie molotovów pod sojuszników", "deliberately throwing Molotovs under teammates", "griefing", ["teammate"]),
	y("blocking", "Bodyblockowanie teammate’a w drzwiach lub przejściu", "deliberately body-blocking a teammate in a doorway or passage", "griefing", ["teammate"], ["teammate"]),
	y("team-smoke-block", "Celowe blokowanie wejścia własnemu teamowi smoke’em", "deliberately blocking the team's entrance with a smoke grenade", "griefing", ["teammate"]),
	y("knife-nonparticipation", "Celowe bieganie z nożem i nieuczestniczenie w rundzie", "deliberately running with a knife and not participating in the round", "griefing", ["teammate"]),
	y("intentional-suicide", "Celowe popełnianie samobójstwa w rundzie", "deliberately committing suicide during a round", "griefing", ["teammate"]),
	y("bomb-separation", "Zabieranie bomby i celowe odchodzenie od reszty drużyny", "taking the bomb and deliberately moving away from the rest of the team", "griefing", ["teammate"]),
	y("bomb-at-spawn", "Celowe zostawianie bomby na spawnie", "deliberately leaving the bomb at spawn", "griefing", ["teammate"]),
	y("afk", "AFK przez znaczną część rundy", "being AFK for a significant part of the round", "griefing", ["teammate"], ["teammate"]),
	y("evading-kick", "Minimalne poruszanie się tylko w celu uniknięcia AFK/kicka", "moving only enough to avoid an AFK removal or kick", "griefing", ["teammate"]),
	y("throwing", "Celowe oddawanie rund / brak próby wygrania rundy", "deliberately giving away rounds or making no attempt to win", "griefing", ["teammate"], ["teammate"]),
	y("position-revealing-shots", "Celowe strzelanie w ściany / powietrze w celu zdradzenia pozycji drużyny", "deliberately shooting walls or the air to reveal the team's position", "griefing", ["teammate"]),
	y("spawn-molotov", "Celowe rzucanie molotovów na własnym spawnie", "deliberately throwing Molotovs at the team's own spawn", "griefing", ["teammate"]),
	y("utility-waste", "Celowe marnowanie utility drużyny", "deliberately wasting the team's utility", "griefing", ["teammate"]),
	y("refuse-defuse", "Celowe niepodejmowanie próby defuse mimo możliwości", "deliberately refusing to attempt a possible defuse", "griefing", ["teammate"]),
	y("block-plant", "Celowe utrudnianie plantowania bomby", "deliberately obstructing a bomb plant", "griefing", ["teammate"]),
	y("block-defuse", "Celowe utrudnianie rozbrajania bomby teammate’owi", "deliberately obstructing a teammate's defuse", "griefing", ["teammate"]),
	y("discard-equipment", "Celowe wyrzucanie broni/utility w miejsca niedostępne dla drużyny", "deliberately throwing weapons or utility where teammates cannot retrieve them", "griefing", ["teammate"]),
	y("mic-spam", "Ciągłe krzyczenie i zakłócanie komunikacji voice", "repeatedly shouting and disrupting voice communication", "toxicity", ["teammate"], ["teammate"]),
	y("voice-music", "Puszczanie muzyki / soundboardu przez voice chat", "playing music or a soundboard over voice chat", "toxicity", ["teammate"]),
	y("chat-spam", "Spamowanie wiadomości lub bindów na czacie", "spamming messages or binds in text chat", "toxicity", ["any"]),
	y("early-giveup-spam", "Floodowanie „gg”, „end”, „ff” itp. od początku meczu", "flooding chat with 'gg', 'end', 'ff', or similar messages from the start of the match", "toxicity", ["any"]),
	y("harassment", "Ciągłe personalne obrażanie konkretnego gracza", "repeatedly directing personal insults at a specific player", "toxicity", ["any"], ["teammate", "opponent"]),
	y("racism", "Używanie rasistowskich wyzwisk", "using racist slurs", "toxicity", ["any"], ["teammate", "opponent"]),
	y("homophobia", "Homofobiczne komentarze lub wyzwiska", "making homophobic comments or using homophobic slurs", "toxicity", ["any"]),
	y("sexism", "Seksistowskie komentarze lub wyzwiska", "making sexist comments or using sexist slurs", "toxicity", ["any"]),
	y("threats", "Grożenie innemu graczowi śmiercią lub przemocą", "threatening another player with death or violence", "toxicity", ["any"]),
	y("self-harm", "Zachęcanie innego gracza do samobójstwa / self-harm", "encouraging another player to commit suicide or self-harm", "toxicity", ["any"]),
	y("hateful-nickname", "Obraźliwy / nienawistny nickname", "using an offensive or hateful nickname", "toxicity", ["any"], ["opponent"]),
	y("hateful-avatar", "Obraźliwy / nienawistny avatar lub zdjęcie profilowe", "using an offensive or hateful avatar or profile picture", "toxicity", ["any"]),
	y("report-spam", "Spamowanie komendą !report lub nawoływanie do masowego reportowania", "spamming the !report command or calling for mass reports", "toxicity", ["any"]),
	y("wallhack", "Używanie wallhacka / informacji o przeciwniku bez możliwości ich zdobycia", "using a wallhack or enemy information that could not legitimately be obtained", "cheating", ["any"], ["opponent"]),
	y("aimbot", "Używanie aimbota / nienaturalne automatyczne namierzanie przeciwników", "using an aimbot or unnatural automatic targeting of opponents", "cheating", ["any"], ["opponent"]),
	y("triggerbot", "Triggerbot / automatyczne oddawanie strzału po wejściu przeciwnika w celownik", "using a triggerbot that automatically fires when an opponent enters the crosshair", "cheating", ["any"], ["opponent"]),
	y("aim-assistance", "Inne niedozwolone wspomaganie celowania lub recoil control", "using other prohibited aim assistance or recoil control", "cheating", ["any"]),
	y("stream-sniping", "Stream sniping w celu zdobywania informacji o przeciwniku", "stream sniping to obtain information about an opponent", "cheating", ["any"], ["opponent"]),
	y("enemy-position-ghosting", "Ghosting — przekazywanie informacji o pozycjach przeciwników bez podstaw do ich posiadania", "communicating enemy positions without a legitimate source for that information", "cheating", ["any"]),
	y("ghosting", "Przekazywanie przeciwnikom pozycji własnych teammate’ów przez all-chat", "revealing teammates' positions to opponents through all-chat", "cheating", ["any"]),
	y("smurf", "Granie na dodatkowym koncie znacznie poniżej rzeczywistego poziomu gracza", "playing on an additional account far below the player's true skill level", "smurfing", ["any"], ["opponent"]),
	y("deranking", "Celowe zaniżanie ELO/ranku, aby grać przeciwko słabszym graczom", "deliberately lowering ELO or rank to play against weaker opponents", "smurfing", ["any"]),
	y("boosting", "Boostowanie konta innego gracza poprzez grę na znacznie niższym poziomie lobby", "boosting another player's account by playing in a substantially lower-skilled lobby", "smurfing", ["any"], ["opponent"]),
	y("account-sharing", "Udostępnianie / używanie cudzego konta w celu podniesienia jego ELO", "sharing or using another person's account to raise its ELO", "smurfing", ["any"]),
	y("matchmaking-evasion", "Tworzenie nowego konta w celu obchodzenia właściwego poziomu matchmakingu", "creating a new account to evade the player's proper matchmaking level", "smurfing", ["any"])
], de = new Map(ue.map((e) => [e.id, e]));
function b(e) {
	let t = e.trim().replace(/\s+/g, " ").toLocaleLowerCase();
	return t ? `custom:${t}` : "";
}
//#endregion
//#region src/shared/domain.ts
function fe(e) {
	let t = e.playerId || e.nickname.toLocaleLowerCase();
	return `${e.matchId}:${t}`;
}
function pe(e) {
	switch (e.kind) {
		case "single": return `Runda ${e.round}`;
		case "range": return `Rundy ${e.from}–${e.to}`;
		case "selected":
			if (e.rounds.length === 0) return "Runda nieznana";
			if (e.rounds.some((e) => e > 24)) {
				let t = [...new Set(e.rounds.filter((e) => e >= 1 && e <= 24))].sort((e, t) => e - t);
				return t.length === 0 ? "Dogrywka" : `${t.length === 1 ? `Runda ${t[0]}` : `Rundy ${he(t)}`} i dogrywka`;
			}
			return e.rounds.length === 1 ? `Runda ${e.rounds[0]}` : `Rundy ${he(e.rounds)}`;
		case "whole": return "Cały mecz";
		case "unknown": return "Bez wskazanych rund";
	}
}
function me(e) {
	return e.trim().replace(/\s+/g, " ");
}
function x(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e ?? []) {
		let e = me(r), i = e.toLocaleLowerCase();
		!e || n.has(i) || (n.add(i), t.push(e));
	}
	return t;
}
function he(e) {
	let t = [...new Set(e)].sort((e, t) => e - t), n = [], r = t[0], i = t[0];
	for (let e of t.slice(1)) {
		if (e === i + 1) {
			i = e;
			continue;
		}
		n.push(r === i ? `${r}` : `${r}–${i}`), r = e, i = e;
	}
	return r !== void 0 && i !== void 0 && n.push(r === i ? `${r}` : `${r}–${i}`), n.join(", ");
}
//#endregion
//#region src/shared/prompt.ts
var S = [
	"Rewrite the report in a significantly firmer, more decisive tone. Make the player's behavior sound clearly unacceptable and emphasize how seriously it disrupted the team and harmed the match. Use strong, direct language that encourages a moderator to take the report seriously. Preserve every factual detail exactly. Do not invent actions, intent, repetition, quotes, consequences, or rounds.",
	"Rewrite the report to sound forceful, urgent, and uncompromising. Clearly condemn the reported behavior and strongly emphasize its negative impact on the team and the integrity of the match. Remove soft, hesitant, or neutral wording. Make every sentence direct and impactful while remaining suitable for a FACEIT moderation report. Do not add, alter, or exaggerate any factual claims.",
	"Rewrite this report using the strongest credible language appropriate for a formal FACEIT complaint. Present the described conduct as completely unacceptable and make its disruptive impact impossible to overlook. Use sharp, authoritative, high-impact sentences and an urgent tone. The result should strongly communicate that moderator attention is warranted. Intensify only the wording and presentation - never invent or exaggerate behavior, intent, frequency, evidence, quotes, rounds, or consequences."
], ge = {
	normal: "Write a balanced, factual report. Adapt length to the evidence, normally 3 to 5 short sentences.",
	stronger: S[0]
};
function _e(e, t, n, r = 1) {
	if (t !== "normal" && n) {
		let e = Math.min(3, Math.max(1, r));
		return [
			`Task: ${S[e - 1]}`,
			`Intensity pass: ${e} of 3`,
			"Edit only the latest ready English report below. Treat it as the sole source text for this rewrite.",
			"Preserve every factual claim, player identity, round number, category, and subcategory.",
			"Do not reconstruct the report from source notes and do not introduce new information.",
			`Category: ${n.category}`,
			`Subcategory: ${n.subcategory}`,
			`Rounds: ${n.rounds.length ? n.rounds.join(", ") : "none"}`,
			"Ready report:",
			n.text
		].join("\n");
	}
	let i = e.incidents.map((e, t) => {
		let n = [], r = [];
		for (let t of e.behaviorIds) {
			let e = de.get(t);
			e && (e.actionable ? n : r).push(e.promptLabel);
		}
		n.push(...x(e.customBehaviorLabels).map((e) => `user-defined offence: ${e}`));
		let i = e.rounds.kind === "unknown" ? [] : [`Time: ${pe(e.rounds)}`], a = [...e.note.trim() ? [`User note: ${e.note.trim()}`] : [], ...(e.transcriptEntries ?? []).map((e) => e.trim()).filter(Boolean).map((e, t) => `Voice note ${t + 1}: ${e}`)];
		return [
			`Incident ${t + 1}`,
			...i,
			`Offences selected: ${n.length ? n.join("; ") : "none"}`,
			`Gameplay context: ${r.length ? r.join("; ") : "none"}`,
			`User confirmed deliberate sabotage: ${e.intentionalSabotage ? "yes" : "no"}`,
			...a.length > 0 ? a : ["User details: none"]
		].join("\n");
	});
	return [
		`Reported player: ${e.nickname}`,
		`Relation: ${e.relation}`,
		`Requested version: ${ge[t]}`,
		"",
		i.join("\n\n")
	].join("\n");
}
function ve(e) {
	let t = e.replace(/[—–]/g, "-").replace(/\s+/g, " ").trim();
	if (t.length <= 1e3) return t;
	let n = t.slice(0, 997), r = Math.max(n.lastIndexOf("."), n.lastIndexOf("!"), n.lastIndexOf("?"));
	if (r >= 650) return n.slice(0, r + 1);
	let i = n.lastIndexOf(" ");
	return `${n.slice(0, i > 0 ? i : 997)}...`;
}
//#endregion
//#region src/shared/preferences.ts
var C = "Zgłoś gracza";
function w(e) {
	if (typeof e != "string") return C;
	let t = e.trim().replace(/\s+/gu, " ");
	return t ? Array.from(t).slice(0, 32).join("") : C;
}
//#endregion
//#region src/shared/config.ts
var T = {
	apiAccessMode: "personal",
	xaiApiKey: "",
	deepgramApiKey: "",
	xaiModel: "grok-4.20-0309-non-reasoning",
	transcriptionLanguage: "pl",
	customPrompt: ce,
	rosterActionLabel: C
}, E = {
	drafts: "frh:drafts",
	reports: "frh:reports",
	settings: "frh:settings",
	customBehaviors: "frh:custom-behaviors",
	behaviorUsage: "frh:behavior-usage",
	activeReportOwner: "frh:active-report-owner",
	deletedReports: "frh:deleted-reports",
	reportMutations: "frh:report-mutations",
	reportTombstones: "frh:report-tombstones",
	reportCursors: "frh:report-cursors",
	reportArchiveVersion: "frh:report-archive-version"
}, ye = "Zgłoś frajera", D = 2;
function be() {
	return {
		get(e) {
			if (v() || typeof chrome > "u" || !chrome.storage?.local) {
				let t = localStorage.getItem(e);
				return Promise.resolve(t ? JSON.parse(t) : void 0);
			}
			return new Promise((t, n) => {
				chrome.storage.local.get(e, (r) => {
					let i = chrome.runtime.lastError;
					i ? n(Error(i.message)) : t(r[e]);
				});
			});
		},
		set(e) {
			if (v() || typeof chrome > "u" || !chrome.storage?.local) {
				for (let [t, n] of Object.entries(e)) localStorage.setItem(t, JSON.stringify(n));
				return Promise.resolve();
			}
			return new Promise((t, n) => {
				chrome.storage.local.set(e, () => {
					let e = chrome.runtime.lastError;
					e ? n(Error(e.message)) : t();
				});
			});
		},
		subscribe(e) {
			if (v() || typeof chrome > "u" || !chrome.storage?.onChanged) return () => void 0;
			let t = (t, n) => {
				n === "local" && e(t);
			};
			return chrome.storage.onChanged.addListener(t), () => chrome.storage.onChanged.removeListener(t);
		}
	};
}
function xe(e) {
	let t = Promise.resolve(), n = async () => {
		let [t, n, r, i, a, o, s, c] = await Promise.all([
			e.get(E.drafts),
			e.get(E.reports),
			e.get(E.activeReportOwner),
			e.get(E.reportMutations),
			e.get(E.reportTombstones),
			e.get(E.reportCursors),
			e.get(E.deletedReports),
			e.get(E.reportArchiveVersion)
		]), l = Array.isArray(n) ? [...n] : [], u = A(r), d = we([...Array.isArray(a) ? a : [], ...Array.isArray(s) ? s : []]), f = Te(i);
		if (c !== D) {
			for (let e of l) !e.ownerFaceitId || De(d, e.ownerFaceitId, e.archiveId) || j(f, {
				mutationId: M("upsert", e.archiveId),
				ownerFaceitId: e.ownerFaceitId,
				archiveId: e.archiveId,
				kind: "upsert"
			});
			for (let e of d) e.ownerFaceitId && j(f, {
				mutationId: M("delete", e.archiveId),
				ownerFaceitId: e.ownerFaceitId,
				archiveId: e.archiveId,
				kind: "delete"
			});
		}
		return {
			drafts: N(t) ? { ...t } : {},
			reports: l,
			...u ? { activeOwnerFaceitId: u } : {},
			pendingMutations: f,
			tombstones: d,
			cursors: Ee(o)
		};
	}, r = (t) => e.set({
		[E.drafts]: t.drafts,
		[E.reports]: t.reports,
		[E.activeReportOwner]: t.activeOwnerFaceitId ?? null,
		[E.reportMutations]: t.pendingMutations,
		[E.reportTombstones]: t.tombstones,
		[E.reportCursors]: t.cursors,
		[E.reportArchiveVersion]: D,
		[E.deletedReports]: []
	});
	return {
		read: n,
		saveDraft(n) {
			let r = t.catch(() => void 0).then(async () => {
				let t = { ...await e.get(E.drafts) ?? {} };
				t[n.key] = ke(n), await e.set({ [E.drafts]: t });
			});
			return t = r, r;
		},
		mutate(e) {
			let i = t.catch(() => void 0).then(async () => {
				let t = await n(), i = await e(t);
				return await r(t), i;
			});
			return t = i, i;
		},
		subscribe(t) {
			return e.subscribe?.((e) => {
				Object.keys(e).some((e) => Ce.has(e)) && t();
			}) ?? (() => void 0);
		}
	};
}
function Se(e) {
	let t = xe(e), n = async () => {
		let t = await e.get(E.settings), n = {
			...T,
			...t
		};
		return n.xaiModel.trim() === "grok-4.3" && (n.xaiModel = T.xaiModel), n.customPrompt.trim() === se.trim() && (n.customPrompt = T.customPrompt), n.apiAccessMode = t?.apiAccessMode === "managed" ? "managed" : "personal", n.rosterActionLabel = w(n.rosterActionLabel), n.rosterActionLabel === ye && (n.rosterActionLabel = C), n;
	}, r = (t) => e.set({ [E.settings]: {
		...t,
		rosterActionLabel: w(t.rosterActionLabel)
	} }), i = async () => Me(await e.get(E.behaviorUsage));
	return {
		persistence: {
			getSettings: n,
			saveSettings: r,
			async getBehaviorSnapshot() {
				let [t, n] = await Promise.all([e.get(E.customBehaviors), i()]);
				return {
					customBehaviors: x(t),
					usage: n
				};
			},
			async saveCustomBehaviors(t) {
				let n = x(t);
				return await e.set({ [E.customBehaviors]: n }), n;
			},
			async recordBehaviorUsage(t, n = []) {
				let r = await i(), a = Ae(t, n);
				for (let e of a) r[e] = (r[e] ?? 0) + 1;
				return await e.set({ [E.behaviorUsage]: r }), r;
			},
			async loadReportWorkspace(e) {
				let [r, i] = await Promise.all([t.read(), n()]);
				return {
					draft: r.drafts[fe(e)] ?? Object.values(r.drafts).find((t) => t.matchId === e.matchId && t.nickname.toLocaleLowerCase() === e.nickname.toLocaleLowerCase()),
					matchDrafts: Object.values(r.drafts).filter((t) => t.matchId === e.matchId),
					transcriptionLanguage: i.transcriptionLanguage
				};
			},
			saveDraft(e) {
				return t.saveDraft(e);
			},
			async getRosterBadges() {
				let e = await t.read(), n = /* @__PURE__ */ new Map();
				for (let t of Object.values(e.drafts)) {
					let e = P(t.matchId, t.nickname), r = n.get(e) ?? {
						draftEntries: 0,
						reports: 0
					};
					r.draftEntries += t.incidents.length, n.set(e, r);
				}
				for (let t of Oe(e.reports, e.activeOwnerFaceitId)) {
					let e = P(t.matchId, t.nickname), r = n.get(e) ?? {
						draftEntries: 0,
						reports: 0
					};
					r.reports += 1, n.set(e, r);
				}
				return n;
			},
			async getRosterActionLabel() {
				return (await n()).rosterActionLabel;
			},
			subscribeRosterChanges(t) {
				return e.subscribe?.((e) => {
					let n = /* @__PURE__ */ new Set();
					(E.drafts in e || E.reports in e) && n.add("badges");
					let r = e[E.settings];
					r && Ne(r) && n.add("action-label"), n.size > 0 && t(n);
				}) ?? (() => void 0);
			}
		},
		accountReportArchiveStore: t
	};
}
var O = Se(be()), k = O.persistence;
O.accountReportArchiveStore;
var Ce = /* @__PURE__ */ new Set([
	E.reports,
	E.activeReportOwner,
	E.deletedReports,
	E.reportMutations,
	E.reportTombstones,
	E.reportCursors,
	E.reportArchiveVersion
]);
function A(e) {
	return typeof e == "string" && e.trim() ? e.trim() : void 0;
}
function we(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (!N(n) || typeof n.archiveId != "string" || !n.archiveId) continue;
		let e = A(n.ownerFaceitId), r = {
			archiveId: n.archiveId,
			...e ? { ownerFaceitId: e } : {}
		};
		t.set(Pe(r), r);
	}
	return [...t.values()];
}
function Te(e) {
	if (!Array.isArray(e)) return [];
	let t = [];
	for (let n of e) !N(n) || typeof n.mutationId != "string" || typeof n.archiveId != "string" || typeof n.ownerFaceitId != "string" || !n.ownerFaceitId.trim() || n.kind !== "upsert" && n.kind !== "delete" || j(t, {
		mutationId: n.mutationId,
		ownerFaceitId: n.ownerFaceitId.trim(),
		archiveId: n.archiveId,
		kind: n.kind
	});
	return t;
}
function j(e, t) {
	let n = (e) => e.ownerFaceitId === t.ownerFaceitId && e.archiveId === t.archiveId, r = e.find(n);
	(r?.kind !== "delete" || t.kind !== "upsert") && (r && e.splice(e.findIndex(n), 1), e.push(t));
}
function Ee(e) {
	if (!N(e)) return {};
	let t = {};
	for (let [n, r] of Object.entries(e)) !n.trim() || !N(r) || (t[n] = {
		...typeof r.cursor == "string" && /^(?:0|[1-9][0-9]*)$/u.test(r.cursor) ? { cursor: r.cursor } : {},
		...typeof r.olderCursor == "string" && r.olderCursor ? { olderCursor: r.olderCursor } : {},
		hasMoreOlder: r.hasMoreOlder === !0
	});
	return t;
}
function De(e, t, n) {
	return e.some((e) => e.ownerFaceitId === t && e.archiveId === n);
}
function M(e, t) {
	return `mutation-migration-${e}-${t.toLocaleLowerCase().replace(/[^a-z0-9-]/gu, "-").slice(0, 150)}`;
}
function Oe(e, t) {
	return e.filter((e) => t ? e.ownerFaceitId === t : !e.ownerFaceitId).sort(Fe);
}
function N(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function ke(e) {
	return {
		...e,
		incidents: e.incidents.map((e) => ({
			...e,
			customBehaviorLabels: x(e.customBehaviorLabels)
		})),
		composer: e.composer ? {
			...e.composer,
			customBehaviorLabels: x(e.composer.customBehaviorLabels)
		} : void 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function Ae(e, t) {
	return [...e.map((e) => e.trim()).filter(Boolean), ...x(t).map(b)].filter((e, t, n) => e && n.indexOf(e) === t);
}
function je(e) {
	let t = e.trim();
	return t.startsWith("custom:") ? b(t.slice(7)) : t;
}
function Me(e) {
	let t = {};
	for (let [n, r] of Object.entries(e ?? {})) {
		let e = je(n);
		!e || !Number.isFinite(r) || r <= 0 || (t[e] = (t[e] ?? 0) + Math.floor(r));
	}
	return t;
}
function P(e, t) {
	return `${e}:${t.toLocaleLowerCase()}`;
}
function Ne(e) {
	let t = e.oldValue, n = e.newValue;
	return w(t?.rosterActionLabel) !== w(n?.rosterActionLabel);
}
function Pe(e) {
	return `${e.ownerFaceitId ?? ""}:${e.archiveId}`;
}
function Fe(e, t) {
	return Date.parse(t.submittedAt) - Date.parse(e.submittedAt) || t.archiveId.localeCompare(e.archiveId);
}
//#endregion
//#region src/shared/api.ts
async function Ie(e) {
	let t = await k.getSettings();
	if (!t.deepgramApiKey.trim()) throw Error("Brak klucza Deepgram. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = new URLSearchParams({
		model: "nova-3",
		language: e.language,
		smart_format: "true"
	}), r = v() ? `/__frh-api/deepgram/v1/listen?${n}` : `https://api.deepgram.com/v1/listen?${n}`, i = await fetch(r, {
		method: "POST",
		headers: {
			Authorization: `Token ${t.deepgramApiKey.trim()}`,
			"Content-Type": e.mimeType || "audio/webm"
		},
		body: Re(e.audioBase64)
	});
	if (!i.ok) throw await F("Deepgram", i);
	let a = (await i.json()).results?.channels?.[0]?.alternatives?.[0]?.transcript?.trim();
	if (!a) throw Error("Deepgram nie rozpoznał mowy w nagraniu.");
	return { transcript: a };
}
async function Le(e) {
	let t = await k.getSettings();
	if (!t.xaiApiKey.trim()) throw Error("Brak klucza xAI. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = t.xaiModel.trim() || "grok-4.20-0309-non-reasoning", r = {
		model: n,
		store: !1,
		max_output_tokens: 500,
		instructions: `${t.customPrompt.trim()}\n\n${le}`,
		input: [{
			role: "user",
			content: _e(e.draft, e.mode, e.sourceReport, e.enhancementPass)
		}],
		text: { format: {
			type: "json_schema",
			name: "faceit_report",
			strict: !0,
			schema: {
				type: "object",
				properties: {
					category: {
						type: "string",
						enum: [
							"Griefing",
							"Cheating",
							"Multiple accounts or smurfing",
							"Toxicity",
							"Inappropriate content"
						]
					},
					subcategory: {
						type: "string",
						enum: [
							"Voice",
							"Chat",
							"Voice and Chat",
							"None"
						]
					},
					rounds: {
						type: "array",
						items: {
							type: "integer",
							minimum: 1,
							maximum: 60
						}
					},
					text: { type: "string" }
				},
				required: [
					"category",
					"subcategory",
					"rounds",
					"text"
				],
				additionalProperties: !1
			}
		} }
	};
	n === "grok-4.3" && (r.reasoning_effort = "none");
	let i = v() ? "/__frh-api/xai/v1/responses" : "https://api.x.ai/v1/responses", a = await fetch(i, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${t.xaiApiKey.trim()}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify(r)
	});
	if (!a.ok) throw await F("xAI", a);
	let o = await a.json(), s = o.output_text ?? o.output?.flatMap((e) => e.content ?? []).find((e) => e.text)?.text;
	if (!s) throw Error("xAI zwróciło pustą odpowiedź.");
	let c;
	try {
		c = JSON.parse(s);
	} catch {
		throw Error("xAI zwróciło odpowiedź w nieprawidłowym formacie.");
	}
	if (!c.text || !c.category || !Array.isArray(c.rounds)) throw Error("xAI zwróciło niekompletny report.");
	let l = e.mode === "normal" ? void 0 : e.sourceReport;
	return {
		...c,
		category: l?.category ?? c.category,
		subcategory: l?.subcategory ?? c.subcategory,
		rounds: l?.rounds ?? [...new Set(c.rounds)].sort((e, t) => e - t),
		text: ve(c.text)
	};
}
function Re(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = t.charCodeAt(e);
	return n;
}
async function F(e, t) {
	let n = "";
	try {
		let e = await t.json();
		n = typeof e.error == "string" ? e.error : e.error?.message || e.message || "";
	} catch {
		n = await t.text().catch(() => "");
	}
	return /* @__PURE__ */ Error(`${e} zwróciło błąd ${t.status}${n ? `: ${n.slice(0, 240)}` : ""}`);
}
//#endregion
//#region src/background/provider.ts
async function ze(e) {
	let t = await k.getSettings();
	return t.apiAccessMode === "managed" ? m.generateReport(e, t.customPrompt) : Le(e);
}
async function Be(e) {
	return (await k.getSettings()).apiAccessMode === "managed" ? m.transcribeAudio(e) : Ie(e);
}
//#endregion
//#region src/shared/side-panel-state.ts
var I = "frh:side-panel-state", L = { view: "home" };
function R(e) {
	if (!We(e) || !Ue(e.view)) return L;
	let t = Ve(e.target);
	if (e.view === "report" && !t) return L;
	let n = He(e.availableRound);
	return {
		view: e.view,
		...t ? { target: t } : {},
		...n === void 0 ? {} : { availableRound: n }
	};
}
function Ve(e) {
	if (!(!We(e) || typeof e.matchId != "string" || !e.matchId.trim() || typeof e.matchUrl != "string" || !e.matchUrl.trim() || typeof e.nickname != "string" || !e.nickname.trim() || e.relation !== "teammate" && e.relation !== "opponent" && e.relation !== "unknown")) return {
		matchId: e.matchId.trim(),
		matchUrl: e.matchUrl.trim(),
		nickname: e.nickname.trim(),
		relation: e.relation,
		...typeof e.playerId == "string" && e.playerId.trim() ? { playerId: e.playerId.trim() } : {},
		...e.startingSide === "CT" || e.startingSide === "T" ? { startingSide: e.startingSide } : {}
	};
}
function He(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60 ? Number(e) : void 0;
}
function Ue(e) {
	return e === "home" || e === "report" || e === "settings";
}
function We(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/side-panel.ts
function Ge() {
	return {
		configureActionClick: () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }),
		openForTab: (e) => chrome.sidePanel.open({ tabId: e }),
		openForCurrentWindow: () => chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT }),
		getState: () => new Promise((e, t) => {
			chrome.storage.session.get(I, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[I]);
			});
		}),
		setState: (e) => new Promise((t, n) => {
			chrome.storage.session.set({ [I]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		})
	};
}
function Ke(e) {
	let t = async () => R(await e.getState()), n = async (t) => {
		let n = R(t);
		return await e.setState(n), n;
	}, r = async (t) => (typeof t == "number" ? await e.openForTab(t) : await e.openForCurrentWindow(), { opened: !0 });
	return {
		configureActionClick: () => e.configureActionClick(),
		async openSettings(e) {
			let i = r(e), a = await t();
			return await Promise.all([i, n({
				...a,
				view: "settings"
			})]), { opened: !0 };
		},
		async openReport(e, t, i) {
			let a = r(i);
			return await Promise.all([a, n({
				view: "report",
				target: e,
				availableRound: t
			})]), { opened: !0 };
		},
		async updateReport(e, r) {
			let i = await t();
			return i.target?.matchId !== e.matchId || i.target.nickname.toLocaleLowerCase() !== e.nickname.toLocaleLowerCase() ? i : n({
				...i,
				target: e,
				availableRound: r
			});
		},
		async setView(e) {
			let r = await t();
			return e === "report" && !r.target ? n(L) : n({
				...r,
				view: e
			});
		},
		getState: t
	};
}
var z = Ke(Ge()), B = {
	repository: "tommyin-it/faceit-report-helper",
	assetName: "faceit-report-helper.zip",
	metadataUrl: "https://tommyin-it.github.io/faceit-report-helper/latest.json"
}, qe = B.metadataUrl, Je = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$/, Ye = 65535, V = `/${B.repository}/releases`, Xe = `${V}/latest/download/${B.assetName}`;
function H(e) {
	if (!Je.test(e)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	let t = e.split(".").map(Number);
	if (t.every((e) => e === 0) || t.some((e) => e > Ye)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	return [...t, ...Array(4 - t.length).fill(0)];
}
function Ze(e, t) {
	let n = H(e), r = H(t);
	for (let e = 0; e < n.length; e += 1) if (n[e] !== r[e]) return n[e] < r[e] ? -1 : 1;
	return 0;
}
function Qe(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function U(e, t) {
	if (typeof e != "string") throw Error("Brak bezpiecznego adresu wydania.");
	let n = new URL(e);
	if (n.protocol !== "https:" || n.origin !== "https://github.com" || n.pathname !== t || n.search || n.hash || n.username || n.password) throw Error("Nieprawidłowy adres wydania.");
	return n.href;
}
function W(e) {
	if (!Qe(e) || e.schemaVersion !== 1 || typeof e.version != "string") throw Error("Nieprawidłowy format informacji o aktualizacji.");
	if (H(e.version), typeof e.publishedAt != "string" || !Number.isFinite(Date.parse(e.publishedAt))) throw Error("Nieprawidłowa data wydania.");
	let t = `${V}/tag/v${e.version}`, n = e.sha256;
	if (n !== void 0 && (typeof n != "string" || !/^[a-f0-9]{64}$/.test(n))) throw Error("Nieprawidłowa suma kontrolna wydania.");
	return {
		schemaVersion: 1,
		version: e.version,
		downloadUrl: U(e.downloadUrl, Xe),
		releaseNotesUrl: U(e.releaseNotesUrl, t),
		publishedAt: e.publishedAt,
		...n ? { sha256: n } : {}
	};
}
function G(e, t) {
	return !t || Ze(e, t.version) >= 0 ? {
		updateAvailable: !1,
		currentVersion: e
	} : {
		updateAvailable: !0,
		currentVersion: e,
		latestVersion: t.version,
		downloadUrl: t.downloadUrl,
		releaseNotesUrl: t.releaseNotesUrl,
		publishedAt: t.publishedAt
	};
}
//#endregion
//#region src/background/update.ts
var K = "frh:update-check", $e = 432e5, et = 8e3, q;
function tt() {
	return new Promise((e) => {
		chrome.storage.local.get(K, (t) => {
			if (chrome.runtime.lastError) {
				e(void 0);
				return;
			}
			let n = t[K];
			if (typeof n != "object" || !n) {
				e(void 0);
				return;
			}
			let r = n;
			if (typeof r.checkedAt != "number" || !Number.isFinite(r.checkedAt)) {
				e(void 0);
				return;
			}
			try {
				e({
					checkedAt: r.checkedAt,
					...r.metadata ? { metadata: W(r.metadata) } : {}
				});
			} catch {
				e(void 0);
			}
		});
	});
}
function J(e) {
	return new Promise((t) => {
		chrome.storage.local.set({ [K]: e }, () => t());
	});
}
async function nt() {
	let e = await fetch(qe, {
		cache: "no-store",
		credentials: "omit",
		redirect: "error",
		signal: AbortSignal.timeout(et)
	});
	if (!e.ok) throw Error(`Serwer aktualizacji zwrócił błąd ${e.status}.`);
	return W(await e.json());
}
async function rt() {
	let e = chrome.runtime.getManifest().version, t = Date.now(), n = await tt();
	if (n && t - n.checkedAt < $e) return G(e, n.metadata);
	try {
		let n = await nt();
		return await J({
			checkedAt: t,
			metadata: n
		}), G(e, n);
	} catch {
		return await J({
			checkedAt: t,
			...n?.metadata ? { metadata: n.metadata } : {}
		}), G(e, n?.metadata);
	}
}
function it() {
	return q ||= rt().finally(() => {
		q = void 0;
	}), q;
}
//#endregion
//#region src/shared/faceit-report.ts
var at = {
	Griefing: {
		category: "negative",
		subCategory: "griefing"
	},
	Toxicity: {
		category: "negative",
		subCategory: "toxic"
	},
	Cheating: {
		category: "cheat",
		subCategory: "cheating"
	},
	"Multiple accounts or smurfing": {
		category: "negative",
		subCategory: "smurfing"
	},
	"Inappropriate content": {
		category: "negative",
		subCategory: "inappropriate"
	}
}, Y = 1e3, ot = 160;
function st(e) {
	let t = Z(e.matchId, "identyfikatora meczu"), n = Z(e.playerId, "FACEIT ID zgłaszanego gracza");
	if (!e.generated) throw Error("Bezpośrednia wysyłka wymaga wygenerowanego zgłoszenia.");
	let r = at[e.generated.category];
	if (!r) throw Error("Wygenerowane zgłoszenie ma nieobsługiwaną kategorię.");
	if (typeof e.generated.text != "string") throw Error("Treść zgłoszenia ma nieprawidłowy format.");
	let i = e.generated.text.trim();
	if (!i) throw Error("Treść zgłoszenia nie może być pusta.");
	if (i.length > Y) throw Error(`Treść zgłoszenia może mieć maksymalnie ${Y} znaków.`);
	let a = X(e.generated.rounds), o = a.filter((e) => e <= 24), s = a.filter((e) => e > 24).map((e) => e - 24), c = o.length > 0 || s.length > 0 ? {
		...o.length > 0 ? { rounds: o } : {},
		...s.length > 0 ? { overtimes: s } : {}
	} : void 0;
	return {
		matchId: t,
		reportedUserId: n,
		...r,
		comment: i,
		...c ? { gameData: c } : {}
	};
}
function ct(e) {
	let t = lt(e);
	if (!t) throw Error("FACEIT zwrócił nieprawidłową historię zgłoszeń.");
	return t.flatMap((e) => {
		let t = ut(e);
		return t ? [t] : [];
	});
}
function lt(e) {
	if (Array.isArray(e)) return e;
	if ($(e)) {
		if (Array.isArray(e.payload)) return e.payload;
		if ($(e.data) && Array.isArray(e.data.payload)) return e.data.payload;
	}
}
function ut(e) {
	if (!$(e)) return;
	let t = Q(e.matchId), n = Q(e.reportedUserId), r = Q(e.category), i = Q(e.subCategory);
	if (!t || !n || !r || !i) return;
	let a = dt(e.gameData);
	return {
		matchId: t,
		reportedUserId: n,
		category: r,
		subCategory: i,
		comment: typeof e.comment == "string" ? e.comment.slice(0, Y) : "",
		...a ? { gameData: a } : {}
	};
}
function dt(e) {
	if (!$(e)) return;
	let t = X(e.rounds), n = X(e.overtimes);
	if (t.length !== 0 || n.length !== 0) return {
		...t.length > 0 ? { rounds: t } : {},
		...n.length > 0 ? { overtimes: n } : {}
	};
}
function X(e) {
	return Array.isArray(e) ? [...new Set(e)].filter((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60).sort((e, t) => e - t) : [];
}
function Z(e, t) {
	let n = Q(e);
	if (!n) throw Error(`Brak ${t}. Odśwież pokój meczu i spróbuj ponownie.`);
	return n;
}
function Q(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	if (!(!t || t.length > ot)) return t;
}
function $(e) {
	return typeof e == "object" && !!e;
}
//#endregion
//#region src/background/faceit-report.ts
var ft = "https://www.faceit.com/api/fbi/v1", pt = 3e4;
function mt(e = {}) {
	let t = {
		request: fetch,
		now: () => (/* @__PURE__ */ new Date()).toISOString(),
		...e
	};
	return {
		async submit(e) {
			let n = st(e), r = await ht(t, gt(n.matchId), {
				method: "POST",
				credentials: "include",
				headers: _t(!0),
				body: JSON.stringify(n),
				signal: AbortSignal.timeout(pt)
			});
			if (!r.ok) throw vt(r.status);
			return {
				submittedAt: t.now(),
				httpStatus: r.status
			};
		},
		async getForMatch(e) {
			let n = await ht(t, gt(e), {
				method: "GET",
				credentials: "include",
				headers: _t(!1),
				signal: AbortSignal.timeout(pt)
			});
			if (!n.ok) throw vt(n.status);
			return { reports: ct(await n.json()) };
		}
	};
}
async function ht(e, t, n) {
	try {
		return await e.request(t, n);
	} catch {
		throw Error("Nie udało się połączyć z FACEIT. Sprawdź połączenie i spróbuj ponownie.");
	}
}
function gt(e) {
	let t = e.trim();
	if (!t || t.length > 160) throw Error("Brak prawidłowego identyfikatora meczu.");
	return `${ft}/matches/${encodeURIComponent(t)}/report`;
}
function _t(e) {
	return {
		Accept: "application/json, text/plain, */*",
		"faceit-referer": "web-next",
		...e ? { "Content-Type": "application/json" } : {}
	};
}
function vt(e) {
	return Error(e === 401 || e === 403 ? "Zaloguj się na stronie FACEIT w tej przeglądarce i spróbuj ponownie." : e === 409 ? "To zgłoszenie zostało już wysłane do FACEIT." : e === 429 ? "Zbyt wiele żądań do FACEIT. Odczekaj chwilę i spróbuj ponownie." : e >= 400 && e < 500 ? `FACEIT odrzucił zgłoszenie (HTTP ${e}).` : `FACEIT jest chwilowo niedostępny (HTTP ${e}).`);
}
var yt = mt();
//#endregion
//#region src/background/index.ts
function bt(e, t) {
	switch (e.type) {
		case "OPEN_OPTIONS": return z.openSettings(t.tab?.id);
		case "OPEN_REPORT_PANEL": return z.openReport(e.target, e.availableRound, t.tab?.id);
		case "UPDATE_REPORT_PANEL": return z.updateReport(e.target, e.availableRound);
		case "SET_SIDE_PANEL_VIEW": return z.setView(e.view);
		case "GET_SIDE_PANEL_STATE": return z.getState();
		case "CHECK_FOR_UPDATE": return it();
		case "GET_MANAGED_ACCESS_STATUS": return m.getStatus();
		case "SIGN_IN_MANAGED_ACCESS": return m.signIn();
		case "SIGN_OUT_MANAGED_ACCESS": return m.signOut();
		case "TRANSCRIBE_AUDIO": return Be(e);
		case "GENERATE_REPORT": return ze(e);
		case "SUBMIT_FACEIT_REPORT": return yt.submit(e.draft);
		case "GET_FACEIT_MATCH_REPORTS": return yt.getForMatch(e.matchId);
		case "SYNC_ACCOUNT_REPORTS": return m.syncReports(e);
	}
}
z.configureActionClick().catch((e) => {
	console.error("Unable to configure the extension side panel.", e);
}), chrome.runtime.onMessage.addListener((e, t, n) => (bt(e, t).then((e) => n({
	ok: !0,
	data: e
})).catch((e) => n({
	ok: !1,
	error: e instanceof Error ? e.message : "Nieznany błąd."
})), !0));
//#endregion
