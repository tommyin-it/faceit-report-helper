async function e(e, t, n, r) {
	if (r.aborted) throw Error("Logowanie FACEIT zostało anulowane.");
	let i = await e.currentTab(), a = await e.createTab(), o = new URL(n);
	try {
		return await new Promise((n, i) => {
			let s = !1, c = () => {}, l = () => {}, u = (e, t) => {
				s || (s = !0, clearTimeout(f), clearInterval(p), c(), l(), r.removeEventListener("abort", d), t ? i(t) : n(e));
			}, d = () => u(void 0, /* @__PURE__ */ Error("Logowanie FACEIT zostało anulowane.")), f = setTimeout(() => u(void 0, /* @__PURE__ */ Error("Upłynął czas logowania (3 minuty). Kliknij „Zaloguj przez FACEIT”, aby spróbować ponownie.")), 18e4), p = setInterval(() => {
				e.keepAlive().catch(() => u(void 0, /* @__PURE__ */ Error("Przerwano połączenie z przeglądarką.")));
			}, 2e4);
			try {
				c = e.listenNavigation((e) => {
					if (e.tabId !== a || e.frameId !== 0) return;
					let t;
					try {
						t = new URL(e.url);
					} catch {
						return;
					}
					t.origin !== o.origin || t.pathname !== o.pathname || t.search || t.username || t.password || u(t.href);
				}, o.hostname), l = e.listenRemoved((e) => {
					e === a && d();
				}), r.addEventListener("abort", d, { once: !0 }), r.aborted ? d() : e.navigate(a, t).catch(() => u(void 0, /* @__PURE__ */ Error("Nie udało się otworzyć strony logowania FACEIT w karcie.")));
			} catch {
				u(void 0, /* @__PURE__ */ Error("Nie udało się uruchomić obsługi powrotu logowania. Przeładuj rozszerzenie i sprawdź jego uprawnienia."));
			}
		});
	} finally {
		await e.close(a).catch(() => void 0), i !== void 0 && await e.focus(i).catch(() => void 0);
	}
}
function t() {
	return {
		currentTab: async () => (await chrome.tabs.query({
			active: !0,
			currentWindow: !0
		}))[0]?.id,
		createTab: async () => {
			let e = await chrome.tabs.create({
				url: "about:blank",
				active: !0
			});
			if (e.id === void 0) throw Error("Nie udało się otworzyć karty logowania.");
			return e.id;
		},
		navigate: (e, t) => chrome.tabs.update(e, { url: t }),
		close: (e) => chrome.tabs.remove(e),
		focus: (e) => chrome.tabs.update(e, { active: !0 }),
		keepAlive: () => chrome.runtime.getPlatformInfo(),
		listenNavigation: (e, t) => {
			let n = { url: [{ hostEquals: t }] };
			return chrome.webNavigation.onBeforeNavigate.addListener(e, n), chrome.webNavigation.onCommitted.addListener(e, n), chrome.webNavigation.onErrorOccurred.addListener(e, n), () => {
				chrome.webNavigation.onBeforeNavigate.removeListener(e), chrome.webNavigation.onCommitted.removeListener(e), chrome.webNavigation.onErrorOccurred.removeListener(e);
			};
		},
		listenRemoved: (e) => (chrome.tabs.onRemoved.addListener(e), () => chrome.tabs.onRemoved.removeListener(e))
	};
}
var n = { apiUrl: "https://faceit-report-helper-api.tomaszmiller.workers.dev" }, r = "frh:managed-access-session", i = a(n.apiUrl);
function a(e) {
	if (typeof e != "string" || !e.trim()) return "";
	let t = new URL(e.trim());
	if (t.protocol !== "https:" || t.username || t.password || t.search || t.hash || t.pathname !== "/" && t.pathname !== "") throw Error("Managed access API URL must be a plain HTTPS origin.");
	return t.origin;
}
function o(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	if (!t || t.length > 2048 || /[\s\p{Cc}]/u.test(t)) return;
	let n;
	try {
		n = new URL(t);
	} catch {
		return;
	}
	if (!(n.protocol !== "https:" && n.protocol !== "http:" || n.username || n.password || !n.hostname.includes("."))) return t;
}
function s(e, t = 5) {
	let n = [];
	for (let r of e ?? []) {
		let e = o(r);
		if (!(!e || n.includes(e)) && (n.push(e), n.length >= t)) break;
	}
	return n;
}
//#endregion
//#region src/shared/account-reports.ts
var c = [
	"Griefing",
	"Cheating",
	"Multiple accounts or smurfing",
	"Toxicity",
	"Inappropriate content"
], l = [
	"Voice",
	"Chat",
	"Voice and Chat",
	"None"
];
function u(e) {
	if (!re(e)) return;
	let t = f(e.delivery);
	if (!m(e.archiveId, 120) || !m(e.matchId, 160) || !p(e.matchUrl) || !ee(e.nickname, 100) || e.playerId !== void 0 && !m(e.playerId, 160) || ![
		"teammate",
		"opponent",
		"unknown"
	].includes(String(e.relation)) || !Number.isInteger(e.incidentCount) || Number(e.incidentCount) < 0 || Number(e.incidentCount) > 50 || !ee(e.text, 2e3) || !c.includes(e.category) || !l.includes(e.subcategory) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every(ne) || e.evidenceUrls !== void 0 && !Array.isArray(e.evidenceUrls) || !te(e.generatedAt) || !te(e.submittedAt) || !t) return;
	let n = s(e.evidenceUrls);
	return {
		archiveId: e.archiveId,
		matchId: e.matchId,
		matchUrl: e.matchUrl,
		nickname: e.nickname,
		...typeof e.playerId == "string" ? { playerId: e.playerId } : {},
		relation: e.relation,
		incidentCount: Number(e.incidentCount),
		text: e.text,
		category: e.category,
		subcategory: e.subcategory,
		rounds: [...new Set(e.rounds)].sort((e, t) => e - t),
		...n.length > 0 ? { evidenceUrls: n } : {},
		generatedAt: e.generatedAt,
		submittedAt: e.submittedAt,
		delivery: t
	};
}
function d(e) {
	return typeof e == "string" && /^report-[a-z0-9-]{16,100}$/iu.test(e);
}
function f(e) {
	if (!(!re(e) || e.method !== "faceit" && e.method !== "manual") && !(e.httpStatus !== void 0 && (!Number.isInteger(e.httpStatus) || Number(e.httpStatus) < 100 || Number(e.httpStatus) > 599))) return {
		method: e.method,
		...typeof e.httpStatus == "number" ? { httpStatus: e.httpStatus } : {}
	};
}
function p(e) {
	if (typeof e != "string" || e.length > 500) return !1;
	try {
		let t = new URL(e);
		return t.protocol === "https:" && (t.hostname === "faceit.com" || t.hostname === "www.faceit.com") && !t.username && !t.password;
	} catch {
		return !1;
	}
}
function m(e, t) {
	return typeof e == "string" && !!e.trim() && e.length <= t;
}
function ee(e, t) {
	return typeof e == "string" && !!e.trim() && e.length <= t;
}
function te(e) {
	return typeof e == "string" && e.length <= 40 && Number.isFinite(Date.parse(e));
}
function ne(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60;
}
function re(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/managed-access.ts
var h = r, ie = 1e5;
function ae() {
	return {
		getSession: () => new Promise((e, t) => {
			chrome.storage.local.get(h, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[h]);
			});
		}),
		setSession: (e) => new Promise((t, n) => {
			chrome.storage.local.set({ [h]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		}),
		removeSession: () => new Promise((e, t) => {
			chrome.storage.local.remove(h, () => {
				let n = chrome.runtime.lastError;
				n ? t(Error(n.message)) : e();
			});
		}),
		getRedirectUrl: (e) => chrome.identity.getRedirectURL(e),
		launchAuthTab: (n, r, i) => e(t(), n, r, i),
		fetch: (e, t) => fetch(e, t),
		now: () => Date.now()
	};
}
function oe(e, t = i) {
	let n = async () => {
		let t = _(await e.getSession());
		if (!t || Date.parse(t.expiresAt) <= e.now()) {
			t && await e.removeSession();
			return;
		}
		return t;
	}, r = async (r, i, a, o = ie) => {
		if (!t) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
		let s = a ?? await n();
		if (!s) throw Error("Zaloguj się przez FACEIT w ustawieniach rozszerzenia.");
		let c = new Headers(i.headers);
		c.set("Authorization", `Bearer ${s.token}`);
		let l = await e.fetch(new URL(r, t), {
			...i,
			headers: c,
			cache: "no-store",
			credentials: "omit",
			redirect: "error",
			signal: AbortSignal.timeout(o)
		});
		return l.status === 401 && await e.removeSession(), l;
	}, a = async () => {
		if (!t) return { state: "unconfigured" };
		if (!await n()) return { state: "signed-out" };
		let e = await r("/auth/session", { method: "GET" });
		if (e.status === 401) return { state: "signed-out" };
		if (!e.ok) throw await v(e);
		return se(await e.json());
	}, o, s, c = async (n) => {
		if (!t) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
		let i = e.getRedirectUrl("faceit"), a = new URL("/auth/start", t);
		a.searchParams.set("redirect_uri", i);
		let o = await e.launchAuthTab(a.href, i, n);
		if (!o) throw Error("Logowanie FACEIT zostało anulowane.");
		let s = new URL(o), c = new URL(i);
		if (s.origin !== c.origin || s.pathname !== c.pathname || s.search || s.username || s.password) throw Error("FACEIT zwrócił nieprawidłowy adres logowania.");
		let l = new URLSearchParams(s.hash.replace(/^#/, "")), u = l.get("error");
		if (u === "access_denied") throw Error("To konto FACEIT nie ma dostępu do zarządzanych usług.");
		if (u) throw Error("Nie udało się zalogować przez FACEIT.");
		let d = _({
			token: l.get("token"),
			expiresAt: l.get("expires_at"),
			user: {
				faceitId: l.get("user_id"),
				nickname: l.get("nickname")
			}
		});
		if (!d || Date.parse(d.expiresAt) <= e.now()) throw Error("FACEIT zwrócił nieprawidłową sesję.");
		if (n.aborted) throw Error("Logowanie FACEIT zostało anulowane.");
		let f = await r("/auth/session", { method: "GET" }, d, 15e3);
		if (!f.ok) throw await v(f);
		let p = se(await f.json());
		if (p.state !== "signed-in" || p.user.faceitId !== d.user.faceitId) throw Error("FACEIT zwrócił niespójną sesję logowania.");
		if (n.aborted) throw Error("Logowanie FACEIT zostało anulowane.");
		if (await e.setSession(d), n.aborted) throw await e.removeSession(), Error("Logowanie FACEIT zostało anulowane.");
		return p;
	};
	return {
		getStatus: a,
		signIn() {
			return o ||= (s = new AbortController(), c(s.signal).finally(() => {
				o = void 0, s = void 0;
			})), o;
		},
		async signOut() {
			s?.abort();
			let i = await n();
			if (i && t) try {
				await r("/auth/logout", { method: "POST" }, i, 1e4);
			} catch {}
			return await e.removeSession(), t ? { state: "signed-out" } : { state: "unconfigured" };
		},
		async generateReport(e, t) {
			let n = await r("/v1/generate", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					...e,
					customPrompt: t
				})
			});
			if (!n.ok) throw await v(n);
			return ce(await n.json());
		},
		async transcribeAudio(e) {
			let t = await r("/v1/transcribe", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(e)
			});
			if (!t.ok) throw await v(t);
			let n = await t.json();
			if (typeof n.transcript != "string" || !n.transcript.trim()) throw Error("Usługa zarządzana zwróciła nieprawidłową transkrypcję.");
			return { transcript: n.transcript.trim() };
		},
		async syncReports(e) {
			if (!t) return { state: "signed-out" };
			let i = await n();
			if (!i) return { state: "signed-out" };
			let a = e.mutations.flatMap((e) => {
				if (e.ownerFaceitId !== i.user.faceitId) return [];
				if (e.kind === "delete") return [{
					mutationId: e.mutationId,
					kind: e.kind,
					archiveId: e.archiveId
				}];
				let { ownerFaceitId: t, ...n } = e.report;
				return [{
					mutationId: e.mutationId,
					kind: e.kind,
					report: n
				}];
			}), o = await r("/v1/reports/sync", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					protocolVersion: e.protocolVersion,
					...e.cursor ? { cursor: e.cursor } : {},
					...e.olderCursor ? { olderCursor: e.olderCursor } : {},
					mutations: a
				})
			}, i, 15e3);
			if (!o.ok) throw await v(o);
			let s = le(await o.json());
			return {
				state: "synced",
				ownerFaceitId: i.user.faceitId,
				...s
			};
		}
	};
}
var g = oe(ae());
function _(e) {
	if (!(!y(e) || !y(e.user)) && !(typeof e.token != "string" || e.token.length < 32 || typeof e.expiresAt != "string" || !Number.isFinite(Date.parse(e.expiresAt)) || typeof e.user.faceitId != "string" || !e.user.faceitId.trim() || typeof e.user.nickname != "string" || !e.user.nickname.trim())) return {
		token: e.token,
		expiresAt: e.expiresAt,
		user: {
			faceitId: e.user.faceitId.trim(),
			nickname: e.user.nickname.trim()
		}
	};
}
function se(e) {
	if (!y(e) || !y(e.user)) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	let t = _({
		token: "x".repeat(32),
		expiresAt: e.expiresAt,
		user: e.user
	});
	if (!t) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	if (typeof e.hasManagedAccess != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowy status dostępu.");
	return {
		state: "signed-in",
		user: t.user,
		expiresAt: t.expiresAt,
		hasManagedAccess: e.hasManagedAccess
	};
}
function ce(e) {
	if (!y(e) || typeof e.text != "string" || ![
		"Griefing",
		"Cheating",
		"Multiple accounts or smurfing",
		"Toxicity",
		"Inappropriate content"
	].includes(String(e.category)) || ![
		"Voice",
		"Chat",
		"Voice and Chat",
		"None"
	].includes(String(e.subcategory)) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60)) throw Error("Usługa zarządzana zwróciła nieprawidłowy report.");
	return e;
}
function le(e) {
	if (!y(e) || !Array.isArray(e.reports) || e.reports.length > 500 || !Array.isArray(e.deletedArchiveIds) || e.deletedArchiveIds.length > 500 || !e.deletedArchiveIds.every(d) || !Array.isArray(e.acceptedMutationIds) || e.acceptedMutationIds.length > 250 || !e.acceptedMutationIds.every(ue) || typeof e.cursor != "string" || !/^(?:0|[1-9][0-9]{0,15})$/u.test(e.cursor) || typeof e.hasMoreChanges != "boolean" || e.olderCursor !== void 0 && (typeof e.olderCursor != "string" || !e.olderCursor) || typeof e.hasMoreOlder != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowe archiwum reportów.");
	let t = e.reports.map(u);
	if (t.some((e) => !e)) throw Error("Usługa zarządzana zwróciła nieprawidłowe archiwum reportów.");
	return {
		reports: t,
		deletedArchiveIds: [...new Set(e.deletedArchiveIds)],
		acceptedMutationIds: [...new Set(e.acceptedMutationIds)],
		cursor: e.cursor,
		hasMoreChanges: e.hasMoreChanges,
		...typeof e.olderCursor == "string" ? { olderCursor: e.olderCursor } : {},
		hasMoreOlder: e.hasMoreOlder
	};
}
function ue(e) {
	return typeof e == "string" && /^mutation-[a-z0-9-]{16,180}$/iu.test(e);
}
async function v(e) {
	let t = "";
	try {
		let n = await e.json();
		typeof n.error == "string" && (t = n.error);
	} catch {
		t = "";
	}
	return Error(t || `Usługa zarządzana zwróciła błąd ${e.status}.`);
}
function y(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/shared/operation-error.ts
var b = class extends Error {
	details;
	constructor(e, t) {
		super(e), this.details = t, this.name = "OperationError";
	}
}, de = "You write concise FACEIT CS2 player reports in natural English.\n\nUse only the incidents supplied by the user. Never invent actions, quotes, rounds, frequency, intent, or consequences. You may make the wording firm and clear, but a gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it.\n\nWrite like a normal player: short direct sentences, familiar CS terminology, no headings, no bullet lists, no em dash, no corporate language, no conclusion sentence, and no mention of AI. Focus on observable behaviour, repetition, exact rounds when provided, and how the behaviour disrupted the match. Do not report ordinary bad play as griefing.\n\nReturn a single English report even when the incidents span multiple categories. Pick only a suggested FACEIT category; the user decides where to submit it. Keep the report below 1000 characters.", fe = "Turn the user's rough Polish notes into one clear, natural English FACEIT CS2 player report.\n\nThe input may contain loose words, sentence fragments, shorthand, spelling mistakes, dictated text, or several separate notes. Understand their intended meaning, combine related details, and rewrite them as complete, grammatically correct English sentences. Preserve every useful detail supplied by the user, including the reported actions, relevant context, exact rounds, repetition, communication, and the effect on the match. Translate Polish CS terminology naturally into familiar English CS terminology.\n\nUse only information supplied in the incidents. Never invent actions, quotes, rounds, frequency, intent, motives, or consequences. Do not turn an assumption into a fact. A gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it. Do not report ordinary poor play as griefing.\n\nWrite like a normal player submitting a credible report: direct, factual, easy to understand, and appropriately firm. Use full sentences and smooth transitions where useful. Do not use headings, bullet lists, an em dash, corporate language, a conclusion sentence, or any mention of AI. Avoid awkward literal translations and unnecessary repetition.\n\nReturn one English report containing all relevant supplied information, even when the incidents span multiple categories. Keep it below 1000 characters.", pe = "Mandatory constraints that cannot be overridden: use only the supplied incidents; do not invent actions, quotes, rounds, frequency, intent, or consequences; do not treat ordinary poor play as griefing; return exactly one report under 1000 characters using the required JSON schema.";
//#endregion
//#region src/shared/environment.ts
function x() {
	return !!globalThis.__FRH_LOCAL_FIXTURE__;
}
//#endregion
//#region src/shared/behaviors.ts
function S(e, t, n, r, i, a) {
	return {
		id: e,
		label: t,
		promptLabel: n,
		category: r,
		actionable: !0,
		scopes: i,
		...a ? { quickFor: a } : {}
	};
}
var me = [
	S("teamflash", "Rzucanie flashy prosto w sojuszników podczas pusha", "deliberately throwing flashbangs directly at teammates during a push", "griefing", ["teammate"], ["teammate"]),
	S("team-damage", "Celowe strzelanie do teammate’ów / team damage", "deliberately shooting teammates or causing team damage", "griefing", ["teammate"], ["teammate"]),
	S("team-he", "Celowe rzucanie HE w sojuszników", "deliberately throwing HE grenades at teammates", "griefing", ["teammate"]),
	S("team-molotov", "Celowe rzucanie molotovów pod sojuszników", "deliberately throwing Molotovs under teammates", "griefing", ["teammate"]),
	S("blocking", "Bodyblockowanie teammate’a w drzwiach lub przejściu", "deliberately body-blocking a teammate in a doorway or passage", "griefing", ["teammate"], ["teammate"]),
	S("team-smoke-block", "Celowe blokowanie wejścia własnemu teamowi smoke’em", "deliberately blocking the team's entrance with a smoke grenade", "griefing", ["teammate"]),
	S("knife-nonparticipation", "Celowe bieganie z nożem i nieuczestniczenie w rundzie", "deliberately running with a knife and not participating in the round", "griefing", ["teammate"]),
	S("intentional-suicide", "Celowe popełnianie samobójstwa w rundzie", "deliberately committing suicide during a round", "griefing", ["teammate"]),
	S("bomb-separation", "Zabieranie bomby i celowe odchodzenie od reszty drużyny", "taking the bomb and deliberately moving away from the rest of the team", "griefing", ["teammate"]),
	S("bomb-at-spawn", "Celowe zostawianie bomby na spawnie", "deliberately leaving the bomb at spawn", "griefing", ["teammate"]),
	S("afk", "AFK przez znaczną część rundy", "being AFK for a significant part of the round", "griefing", ["teammate"], ["teammate"]),
	S("evading-kick", "Minimalne poruszanie się tylko w celu uniknięcia AFK/kicka", "moving only enough to avoid an AFK removal or kick", "griefing", ["teammate"]),
	S("throwing", "Celowe oddawanie rund / brak próby wygrania rundy", "deliberately giving away rounds or making no attempt to win", "griefing", ["teammate"], ["teammate"]),
	S("position-revealing-shots", "Celowe strzelanie w ściany / powietrze w celu zdradzenia pozycji drużyny", "deliberately shooting walls or the air to reveal the team's position", "griefing", ["teammate"]),
	S("spawn-molotov", "Celowe rzucanie molotovów na własnym spawnie", "deliberately throwing Molotovs at the team's own spawn", "griefing", ["teammate"]),
	S("utility-waste", "Celowe marnowanie utility drużyny", "deliberately wasting the team's utility", "griefing", ["teammate"]),
	S("refuse-defuse", "Celowe niepodejmowanie próby defuse mimo możliwości", "deliberately refusing to attempt a possible defuse", "griefing", ["teammate"]),
	S("block-plant", "Celowe utrudnianie plantowania bomby", "deliberately obstructing a bomb plant", "griefing", ["teammate"]),
	S("block-defuse", "Celowe utrudnianie rozbrajania bomby teammate’owi", "deliberately obstructing a teammate's defuse", "griefing", ["teammate"]),
	S("discard-equipment", "Celowe wyrzucanie broni/utility w miejsca niedostępne dla drużyny", "deliberately throwing weapons or utility where teammates cannot retrieve them", "griefing", ["teammate"]),
	S("mic-spam", "Ciągłe krzyczenie i zakłócanie komunikacji voice", "repeatedly shouting and disrupting voice communication", "toxicity", ["teammate"], ["teammate"]),
	S("voice-music", "Puszczanie muzyki / soundboardu przez voice chat", "playing music or a soundboard over voice chat", "toxicity", ["teammate"]),
	S("chat-spam", "Spamowanie wiadomości lub bindów na czacie", "spamming messages or binds in text chat", "toxicity", ["any"]),
	S("early-giveup-spam", "Floodowanie „gg”, „end”, „ff” itp. od początku meczu", "flooding chat with 'gg', 'end', 'ff', or similar messages from the start of the match", "toxicity", ["any"]),
	S("harassment", "Ciągłe personalne obrażanie konkretnego gracza", "repeatedly directing personal insults at a specific player", "toxicity", ["any"], ["teammate", "opponent"]),
	S("racism", "Używanie rasistowskich wyzwisk", "using racist slurs", "toxicity", ["any"], ["teammate", "opponent"]),
	S("homophobia", "Homofobiczne komentarze lub wyzwiska", "making homophobic comments or using homophobic slurs", "toxicity", ["any"]),
	S("sexism", "Seksistowskie komentarze lub wyzwiska", "making sexist comments or using sexist slurs", "toxicity", ["any"]),
	S("threats", "Grożenie innemu graczowi śmiercią lub przemocą", "threatening another player with death or violence", "toxicity", ["any"]),
	S("self-harm", "Zachęcanie innego gracza do samobójstwa / self-harm", "encouraging another player to commit suicide or self-harm", "toxicity", ["any"]),
	S("hateful-nickname", "Obraźliwy / nienawistny nickname", "using an offensive or hateful nickname", "toxicity", ["any"], ["opponent"]),
	S("hateful-avatar", "Obraźliwy / nienawistny avatar lub zdjęcie profilowe", "using an offensive or hateful avatar or profile picture", "toxicity", ["any"]),
	S("report-spam", "Spamowanie komendą !report lub nawoływanie do masowego reportowania", "spamming the !report command or calling for mass reports", "toxicity", ["any"]),
	S("wallhack", "Używanie wallhacka / informacji o przeciwniku bez możliwości ich zdobycia", "using a wallhack or enemy information that could not legitimately be obtained", "cheating", ["any"], ["opponent"]),
	S("aimbot", "Używanie aimbota / nienaturalne automatyczne namierzanie przeciwników", "using an aimbot or unnatural automatic targeting of opponents", "cheating", ["any"], ["opponent"]),
	S("triggerbot", "Triggerbot / automatyczne oddawanie strzału po wejściu przeciwnika w celownik", "using a triggerbot that automatically fires when an opponent enters the crosshair", "cheating", ["any"], ["opponent"]),
	S("aim-assistance", "Inne niedozwolone wspomaganie celowania lub recoil control", "using other prohibited aim assistance or recoil control", "cheating", ["any"]),
	S("stream-sniping", "Stream sniping w celu zdobywania informacji o przeciwniku", "stream sniping to obtain information about an opponent", "cheating", ["any"], ["opponent"]),
	S("enemy-position-ghosting", "Ghosting — przekazywanie informacji o pozycjach przeciwników bez podstaw do ich posiadania", "communicating enemy positions without a legitimate source for that information", "cheating", ["any"]),
	S("ghosting", "Przekazywanie przeciwnikom pozycji własnych teammate’ów przez all-chat", "revealing teammates' positions to opponents through all-chat", "cheating", ["any"]),
	S("smurf", "Granie na dodatkowym koncie znacznie poniżej rzeczywistego poziomu gracza", "playing on an additional account far below the player's true skill level", "smurfing", ["any"], ["opponent"]),
	S("deranking", "Celowe zaniżanie ELO/ranku, aby grać przeciwko słabszym graczom", "deliberately lowering ELO or rank to play against weaker opponents", "smurfing", ["any"]),
	S("boosting", "Boostowanie konta innego gracza poprzez grę na znacznie niższym poziomie lobby", "boosting another player's account by playing in a substantially lower-skilled lobby", "smurfing", ["any"], ["opponent"]),
	S("account-sharing", "Udostępnianie / używanie cudzego konta w celu podniesienia jego ELO", "sharing or using another person's account to raise its ELO", "smurfing", ["any"]),
	S("matchmaking-evasion", "Tworzenie nowego konta w celu obchodzenia właściwego poziomu matchmakingu", "creating a new account to evade the player's proper matchmaking level", "smurfing", ["any"])
], he = new Map(me.map((e) => [e.id, e]));
function ge(e) {
	let t = e.trim().replace(/\s+/g, " ").toLocaleLowerCase();
	return t ? `custom:${t}` : "";
}
//#endregion
//#region src/shared/domain.ts
function _e(e) {
	return `${e}-${crypto.randomUUID()}`;
}
function ve(e) {
	let t = e.playerId || e.nickname.toLocaleLowerCase();
	return `${e.matchId}:${t}`;
}
function ye() {
	let e = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: _e("incident"),
		rounds: { kind: "unknown" },
		behaviorIds: [],
		customBehaviorLabels: [],
		note: "",
		transcriptEntries: [],
		intentionalSabotage: !1,
		createdAt: e,
		updatedAt: e
	};
}
function be(e) {
	switch (e.kind) {
		case "single": return `Runda ${e.round}`;
		case "range": return `Rundy ${e.from}–${e.to}`;
		case "selected":
			if (e.rounds.length === 0) return "Runda nieznana";
			if (e.rounds.some((e) => e > 24)) {
				let t = [...new Set(e.rounds.filter((e) => e >= 1 && e <= 24))].sort((e, t) => e - t);
				return t.length === 0 ? "Dogrywka" : `${t.length === 1 ? `Runda ${t[0]}` : `Rundy ${Se(t)}`} i dogrywka`;
			}
			return e.rounds.length === 1 ? `Runda ${e.rounds[0]}` : `Rundy ${Se(e.rounds)}`;
		case "whole": return "Cały mecz";
		case "unknown": return "Bez wskazanych rund";
	}
}
function xe(e) {
	return e.trim().replace(/\s+/g, " ");
}
function C(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e ?? []) {
		let e = xe(r), i = e.toLocaleLowerCase();
		!e || n.has(i) || (n.add(i), t.push(e));
	}
	return t;
}
function Se(e) {
	let t = [...new Set(e)].sort((e, t) => e - t), n = [], r = t[0], i = t[0];
	for (let e of t.slice(1)) {
		if (e === i + 1) {
			i = e;
			continue;
		}
		n.push(r === i ? `${r}` : `${r}–${i}`), r = e, i = e;
	}
	return r !== void 0 && i !== void 0 && n.push(r === i ? `${r}` : `${r}–${i}`), n.join(", ");
}
//#endregion
//#region src/shared/prompt.ts
var Ce = [
	"Rewrite the report in a significantly firmer, more decisive tone. Make the player's behavior sound clearly unacceptable and emphasize how seriously it disrupted the team and harmed the match. Use strong, direct language that encourages a moderator to take the report seriously. Preserve every factual detail exactly. Do not invent actions, intent, repetition, quotes, consequences, or rounds.",
	"Rewrite the report to sound forceful, urgent, and uncompromising. Clearly condemn the reported behavior and strongly emphasize its negative impact on the team and the integrity of the match. Remove soft, hesitant, or neutral wording. Make every sentence direct and impactful while remaining suitable for a FACEIT moderation report. Do not add, alter, or exaggerate any factual claims.",
	"Rewrite this report using the strongest credible language appropriate for a formal FACEIT complaint. Present the described conduct as completely unacceptable and make its disruptive impact impossible to overlook. Use sharp, authoritative, high-impact sentences and an urgent tone. The result should strongly communicate that moderator attention is warranted. Intensify only the wording and presentation - never invent or exaggerate behavior, intent, frequency, evidence, quotes, rounds, or consequences."
], we = {
	normal: "Write a balanced, factual report. Adapt length to the evidence, normally 3 to 5 short sentences.",
	stronger: Ce[0]
};
function Te(e, t, n, r = 1) {
	if (t !== "normal" && n) {
		let e = Math.min(3, Math.max(1, r));
		return [
			`Task: ${Ce[e - 1]}`,
			`Intensity pass: ${e} of 3`,
			"Edit only the latest ready English report below. Treat it as the sole source text for this rewrite.",
			"Preserve every factual claim, player identity, round number, category, and subcategory.",
			"Do not reconstruct the report from source notes and do not introduce new information.",
			`Category: ${n.category}`,
			`Subcategory: ${n.subcategory}`,
			`Rounds: ${n.rounds.length ? n.rounds.join(", ") : "none"}`,
			"Ready report:",
			n.text
		].join("\n");
	}
	let i = e.incidents.map((e, t) => {
		let n = [], r = [];
		for (let t of e.behaviorIds) {
			let e = he.get(t);
			e && (e.actionable ? n : r).push(e.promptLabel);
		}
		n.push(...C(e.customBehaviorLabels).map((e) => `user-defined offence: ${e}`));
		let i = e.rounds.kind === "unknown" ? [] : [`Time: ${be(e.rounds)}`], a = [...e.note.trim() ? [`User note: ${e.note.trim()}`] : [], ...(e.transcriptEntries ?? []).map((e) => e.trim()).filter(Boolean).map((e, t) => `Voice note ${t + 1}: ${e}`)];
		return [
			`Incident ${t + 1}`,
			...i,
			`Offences selected: ${n.length ? n.join("; ") : "none"}`,
			`Gameplay context: ${r.length ? r.join("; ") : "none"}`,
			`User confirmed deliberate sabotage: ${e.intentionalSabotage ? "yes" : "no"}`,
			...a.length > 0 ? a : ["User details: none"]
		].join("\n");
	});
	return [
		`Reported player: ${e.nickname}`,
		`Relation: ${e.relation}`,
		`Requested version: ${we[t]}`,
		"",
		i.join("\n\n")
	].join("\n");
}
function Ee(e) {
	let t = e.replace(/[—–]/g, "-").replace(/\s+/g, " ").trim();
	if (t.length <= 1e3) return t;
	let n = t.slice(0, 997), r = Math.max(n.lastIndexOf("."), n.lastIndexOf("!"), n.lastIndexOf("?"));
	if (r >= 650) return n.slice(0, r + 1);
	let i = n.lastIndexOf(" ");
	return `${n.slice(0, i > 0 ? i : 997)}...`;
}
//#endregion
//#region src/shared/preferences.ts
var w = "Zgłoś gracza";
function T(e) {
	if (typeof e != "string") return w;
	let t = e.trim().replace(/\s+/gu, " ");
	return t ? Array.from(t).slice(0, 32).join("") : w;
}
//#endregion
//#region src/shared/config.ts
var E = {
	apiAccessMode: "personal",
	xaiApiKey: "",
	deepgramApiKey: "",
	xaiModel: "grok-4.20-0309-non-reasoning",
	transcriptionLanguage: "pl",
	customPrompt: fe,
	rosterActionLabel: w
}, De = 108e5;
function Oe(e) {
	let t = Date.parse(e.updatedAt);
	return Number.isFinite(t) ? t + De : 0;
}
function D(e, t = Date.now()) {
	return Oe(e) <= t;
}
//#endregion
//#region src/shared/storage.ts
var O = {
	drafts: "frh:drafts",
	reports: "frh:reports",
	settings: "frh:settings",
	customBehaviors: "frh:custom-behaviors",
	behaviorUsage: "frh:behavior-usage",
	activeReportOwner: "frh:active-report-owner",
	deletedReports: "frh:deleted-reports",
	reportMutations: "frh:report-mutations",
	reportTombstones: "frh:report-tombstones",
	reportCursors: "frh:report-cursors",
	reportArchiveVersion: "frh:report-archive-version"
}, ke = "Zgłoś frajera", Ae = 2;
function k() {
	return {
		get(e) {
			if (x() || typeof chrome > "u" || !chrome.storage?.local) {
				let t = localStorage.getItem(e);
				return Promise.resolve(t ? JSON.parse(t) : void 0);
			}
			return new Promise((t, n) => {
				chrome.storage.local.get(e, (r) => {
					let i = chrome.runtime.lastError;
					i ? n(Error(i.message)) : t(r[e]);
				});
			});
		},
		set(e) {
			if (x() || typeof chrome > "u" || !chrome.storage?.local) {
				for (let [t, n] of Object.entries(e)) localStorage.setItem(t, JSON.stringify(n));
				return Promise.resolve();
			}
			return new Promise((t, n) => {
				chrome.storage.local.set(e, () => {
					let e = chrome.runtime.lastError;
					e ? n(Error(e.message)) : t();
				});
			});
		},
		subscribe(e) {
			if (x() || typeof chrome > "u" || !chrome.storage?.onChanged) return () => void 0;
			let t = (t, n) => {
				n === "local" && e(t);
			};
			return chrome.storage.onChanged.addListener(t), () => chrome.storage.onChanged.removeListener(t);
		}
	};
}
function je(e) {
	return typeof navigator < "u" && navigator.locks ? navigator.locks.request("frh:archive-mutations", e) : e();
}
function A(e) {
	let t = Promise.resolve(), n = async () => {
		let [t, n, r, i, a, o, s, c] = await Promise.all([
			e.get(O.drafts),
			e.get(O.reports),
			e.get(O.activeReportOwner),
			e.get(O.reportMutations),
			e.get(O.reportTombstones),
			e.get(O.reportCursors),
			e.get(O.deletedReports),
			e.get(O.reportArchiveVersion)
		]), l = Array.isArray(n) ? [...n] : [], u = Fe(r), d = Ie([...Array.isArray(a) ? a : [], ...Array.isArray(s) ? s : []]), f = Le(i);
		if (c !== Ae) {
			for (let e of l) !e.ownerFaceitId || ze(d, e.ownerFaceitId, e.archiveId) || M(f, {
				mutationId: Be("upsert", e.archiveId),
				ownerFaceitId: e.ownerFaceitId,
				archiveId: e.archiveId,
				kind: "upsert"
			});
			for (let e of d) e.ownerFaceitId && M(f, {
				mutationId: Be("delete", e.archiveId),
				ownerFaceitId: e.ownerFaceitId,
				archiveId: e.archiveId,
				kind: "delete"
			});
		}
		return {
			drafts: N(t) ? { ...t } : {},
			reports: l,
			...u ? { activeOwnerFaceitId: u } : {},
			pendingMutations: f,
			tombstones: d,
			cursors: Re(o)
		};
	}, r = (t) => e.set({
		[O.drafts]: t.drafts,
		[O.reports]: t.reports,
		[O.activeReportOwner]: t.activeOwnerFaceitId ?? null,
		[O.reportMutations]: t.pendingMutations,
		[O.reportTombstones]: t.tombstones,
		[O.reportCursors]: t.cursors,
		[O.reportArchiveVersion]: Ae,
		[O.deletedReports]: []
	});
	return {
		read: n,
		saveDraft(n) {
			let r = t.catch(() => void 0).then(() => je(async () => {
				let t = { ...await e.get(O.drafts) ?? {} };
				t[n.key] = He(n), await e.set({ [O.drafts]: t });
			}));
			return t = r, r;
		},
		mutate(e) {
			let i = t.catch(() => void 0).then(() => je(async () => {
				let t = await n(), i = await e(t);
				return await r(t), i;
			}));
			return t = i, i;
		},
		subscribe(t) {
			return e.subscribe?.((e) => {
				Object.keys(e).some((e) => Pe.has(e)) && t();
			}) ?? (() => void 0);
		}
	};
}
function Me(e) {
	let t = A(e), n = async () => {
		let e = await t.read();
		return Object.values(e.drafts).some((e) => D(e)) ? t.mutate((e) => {
			for (let [t, n] of Object.entries(e.drafts)) D(n) && delete e.drafts[t];
			return e;
		}) : e;
	}, r = async () => {
		let t = await e.get(O.settings), n = {
			...E,
			...t
		};
		return n.xaiModel.trim() === "grok-4.3" && (n.xaiModel = E.xaiModel), n.customPrompt.trim() === de.trim() && (n.customPrompt = E.customPrompt), n.apiAccessMode = t?.apiAccessMode === "managed" ? "managed" : "personal", n.rosterActionLabel = T(n.rosterActionLabel), n.rosterActionLabel === ke && (n.rosterActionLabel = w), n;
	}, i = (t) => e.set({ [O.settings]: {
		...t,
		rosterActionLabel: T(t.rosterActionLabel)
	} }), a = async () => Ge(await e.get(O.behaviorUsage));
	return {
		persistence: {
			getSettings: r,
			saveSettings: i,
			async getBehaviorSnapshot() {
				let [t, n] = await Promise.all([e.get(O.customBehaviors), a()]);
				return {
					customBehaviors: C(t),
					usage: n
				};
			},
			async saveCustomBehaviors(t) {
				let n = C(t);
				return await e.set({ [O.customBehaviors]: n }), n;
			},
			async recordBehaviorUsage(t, n = []) {
				let r = await a(), i = Ue(t, n);
				for (let e of i) r[e] = (r[e] ?? 0) + 1;
				return await e.set({ [O.behaviorUsage]: r }), r;
			},
			async loadReportWorkspace(e) {
				let [t, i] = await Promise.all([n(), r()]);
				return {
					draft: t.drafts[ve(e)] ?? Object.values(t.drafts).find((t) => t.matchId === e.matchId && t.nickname.toLocaleLowerCase() === e.nickname.toLocaleLowerCase()),
					matchDrafts: Object.values(t.drafts).filter((t) => t.matchId === e.matchId),
					transcriptionLanguage: i.transcriptionLanguage
				};
			},
			async getLocalDrafts() {
				let e = await n();
				return Object.values(e.drafts).filter((e) => e.incidents.length > 0 || e.generated || e.composer?.note.trim()).sort((e, t) => t.updatedAt.localeCompare(e.updatedAt));
			},
			saveDraft(e) {
				return t.saveDraft(e);
			},
			async getRosterBadges() {
				let e = await n(), t = /* @__PURE__ */ new Map();
				for (let n of Object.values(e.drafts)) {
					let e = Ke(n.matchId, n.nickname), r = t.get(e) ?? {
						draftEntries: 0,
						reports: 0
					};
					r.draftEntries += n.incidents.length, t.set(e, r);
				}
				for (let n of Ve(e.reports, e.activeOwnerFaceitId)) {
					let e = Ke(n.matchId, n.nickname), r = t.get(e) ?? {
						draftEntries: 0,
						reports: 0
					};
					r.reports += 1, t.set(e, r);
				}
				return t;
			},
			async getRosterActionLabel() {
				return (await r()).rosterActionLabel;
			},
			subscribeRosterChanges(t) {
				return e.subscribe?.((e) => {
					let n = /* @__PURE__ */ new Set();
					(O.drafts in e || O.reports in e) && n.add("badges");
					let r = e[O.settings];
					r && qe(r) && n.add("action-label"), n.size > 0 && t(n);
				}) ?? (() => void 0);
			}
		},
		accountReportArchiveStore: t
	};
}
var Ne = Me(k()), j = Ne.persistence;
Ne.accountReportArchiveStore;
var Pe = /* @__PURE__ */ new Set([
	O.reports,
	O.activeReportOwner,
	O.deletedReports,
	O.reportMutations,
	O.reportTombstones,
	O.reportCursors,
	O.reportArchiveVersion
]);
function Fe(e) {
	return typeof e == "string" && e.trim() ? e.trim() : void 0;
}
function Ie(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (!N(n) || typeof n.archiveId != "string" || !n.archiveId) continue;
		let e = Fe(n.ownerFaceitId), r = {
			archiveId: n.archiveId,
			...e ? { ownerFaceitId: e } : {}
		};
		t.set(Je(r), r);
	}
	return [...t.values()];
}
function Le(e) {
	if (!Array.isArray(e)) return [];
	let t = [];
	for (let n of e) !N(n) || typeof n.mutationId != "string" || typeof n.archiveId != "string" || typeof n.ownerFaceitId != "string" || !n.ownerFaceitId.trim() || n.kind !== "upsert" && n.kind !== "delete" || M(t, {
		mutationId: n.mutationId,
		ownerFaceitId: n.ownerFaceitId.trim(),
		archiveId: n.archiveId,
		kind: n.kind
	});
	return t;
}
function M(e, t) {
	let n = (e) => e.ownerFaceitId === t.ownerFaceitId && e.archiveId === t.archiveId, r = e.find(n);
	(r?.kind !== "delete" || t.kind !== "upsert") && (r && e.splice(e.findIndex(n), 1), e.push(t));
}
function Re(e) {
	if (!N(e)) return {};
	let t = {};
	for (let [n, r] of Object.entries(e)) !n.trim() || !N(r) || (t[n] = {
		...typeof r.cursor == "string" && /^(?:0|[1-9][0-9]*)$/u.test(r.cursor) ? { cursor: r.cursor } : {},
		...typeof r.olderCursor == "string" && r.olderCursor ? { olderCursor: r.olderCursor } : {},
		hasMoreOlder: r.hasMoreOlder === !0
	});
	return t;
}
function ze(e, t, n) {
	return e.some((e) => e.ownerFaceitId === t && e.archiveId === n);
}
function Be(e, t) {
	return `mutation-migration-${e}-${t.toLocaleLowerCase().replace(/[^a-z0-9-]/gu, "-").slice(0, 150)}`;
}
function Ve(e, t) {
	return e.filter((e) => t ? e.ownerFaceitId === t : !e.ownerFaceitId).sort(Ye);
}
function N(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function He(e) {
	let { evidenceUrls: t, ...n } = e, r = s(t);
	return {
		...n,
		...r.length > 0 ? { evidenceUrls: r } : {},
		incidents: e.incidents.map((e) => ({
			...e,
			customBehaviorLabels: C(e.customBehaviorLabels)
		})),
		composer: e.composer ? {
			...e.composer,
			customBehaviorLabels: C(e.composer.customBehaviorLabels)
		} : void 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function Ue(e, t) {
	return [...e.map((e) => e.trim()).filter(Boolean), ...C(t).map(ge)].filter((e, t, n) => e && n.indexOf(e) === t);
}
function We(e) {
	let t = e.trim();
	return t.startsWith("custom:") ? ge(t.slice(7)) : t;
}
function Ge(e) {
	let t = {};
	for (let [n, r] of Object.entries(e ?? {})) {
		let e = We(n);
		!e || !Number.isFinite(r) || r <= 0 || (t[e] = (t[e] ?? 0) + Math.floor(r));
	}
	return t;
}
function Ke(e, t) {
	return `${e}:${t.toLocaleLowerCase()}`;
}
function qe(e) {
	let t = e.oldValue, n = e.newValue;
	return T(t?.rosterActionLabel) !== T(n?.rosterActionLabel);
}
function Je(e) {
	return `${e.ownerFaceitId ?? ""}:${e.archiveId}`;
}
function Ye(e, t) {
	return Date.parse(t.submittedAt) - Date.parse(e.submittedAt) || t.archiveId.localeCompare(e.archiveId);
}
//#endregion
//#region src/shared/api.ts
async function Xe(e) {
	let t = await j.getSettings();
	if (!t.deepgramApiKey.trim()) throw Error("Brak klucza Deepgram. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = new URLSearchParams({
		model: "nova-3",
		language: e.language,
		smart_format: "true"
	}), r = x() ? `/__frh-api/deepgram/v1/listen?${n}` : `https://api.deepgram.com/v1/listen?${n}`, i = await fetch(r, {
		method: "POST",
		headers: {
			Authorization: `Token ${t.deepgramApiKey.trim()}`,
			"Content-Type": e.mimeType || "audio/webm"
		},
		body: Qe(e.audioBase64)
	});
	if (!i.ok) throw await $e("Deepgram", i);
	let a = (await i.json()).results?.channels?.[0]?.alternatives?.[0]?.transcript?.trim();
	if (!a) throw Error("Deepgram nie rozpoznał mowy w nagraniu.");
	return { transcript: a };
}
async function Ze(e) {
	let t = await j.getSettings();
	if (!t.xaiApiKey.trim()) throw Error("Brak klucza xAI. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = t.xaiModel.trim() || "grok-4.20-0309-non-reasoning", r = {
		model: n,
		store: !1,
		max_output_tokens: 500,
		instructions: `${t.customPrompt.trim()}\n\n${pe}`,
		input: [{
			role: "user",
			content: Te(e.draft, e.mode, e.sourceReport, e.enhancementPass)
		}],
		text: { format: {
			type: "json_schema",
			name: "faceit_report",
			strict: !0,
			schema: {
				type: "object",
				properties: {
					category: {
						type: "string",
						enum: [
							"Griefing",
							"Cheating",
							"Multiple accounts or smurfing",
							"Toxicity",
							"Inappropriate content"
						]
					},
					subcategory: {
						type: "string",
						enum: [
							"Voice",
							"Chat",
							"Voice and Chat",
							"None"
						]
					},
					rounds: {
						type: "array",
						items: {
							type: "integer",
							minimum: 1,
							maximum: 60
						}
					},
					text: { type: "string" }
				},
				required: [
					"category",
					"subcategory",
					"rounds",
					"text"
				],
				additionalProperties: !1
			}
		} }
	};
	n === "grok-4.3" && (r.reasoning_effort = "none");
	let i = x() ? "/__frh-api/xai/v1/responses" : "https://api.x.ai/v1/responses", a = await fetch(i, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${t.xaiApiKey.trim()}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify(r)
	});
	if (!a.ok) throw await $e("xAI", a);
	let o = await a.json(), s = o.output_text ?? o.output?.flatMap((e) => e.content ?? []).find((e) => e.text)?.text;
	if (!s) throw Error("xAI zwróciło pustą odpowiedź.");
	let c;
	try {
		c = JSON.parse(s);
	} catch {
		throw Error("xAI zwróciło odpowiedź w nieprawidłowym formacie.");
	}
	if (!c.text || !c.category || !Array.isArray(c.rounds)) throw Error("xAI zwróciło niekompletny report.");
	let l = e.mode === "normal" ? void 0 : e.sourceReport;
	return {
		...c,
		category: l?.category ?? c.category,
		subcategory: l?.subcategory ?? c.subcategory,
		rounds: l?.rounds ?? [...new Set(c.rounds)].sort((e, t) => e - t),
		text: Ee(c.text)
	};
}
function Qe(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = t.charCodeAt(e);
	return n;
}
async function $e(e, t) {
	let n = "";
	try {
		let e = await t.json();
		n = typeof e.error == "string" ? e.error : e.error?.message || e.message || "";
	} catch {
		n = await t.text().catch(() => "");
	}
	return /* @__PURE__ */ Error(`${e} zwróciło błąd ${t.status}${n ? `: ${n.slice(0, 240)}` : ""}`);
}
//#endregion
//#region src/background/provider-results.ts
var P = A(k());
function et(e) {
	let { pendingResults: t, ...n } = e;
	return JSON.stringify(n);
}
async function tt(e) {
	return e.store.mutate((t) => {
		let n = t.drafts[e.original.key];
		return t.activeOwnerFaceitId !== e.owner || !n || D(n, e.now) || n.createdAt !== e.original.createdAt ? "discarded" : et(n) === et(e.original) ? (e.result.generated && (n.generated = e.result.generated), e.result.transcript && (n.incidents = [...n.incidents, {
			...n.composer ?? ye(),
			note: e.result.transcript
		}], n.composer = void 0, n.generated = void 0), "saved") : (n.pendingResults = [...n.pendingResults ?? [], e.result], "pending");
	});
}
//#endregion
//#region src/background/provider.ts
async function nt(e) {
	let t = await j.getSettings(), n = (await P.read()).activeOwnerFaceitId, r = t.apiAccessMode === "managed" ? await g.generateReport(e, t.customPrompt) : await Ze(e);
	if (n && await tt({
		store: P,
		owner: n,
		original: e.draft,
		result: {
			id: crypto.randomUUID(),
			generated: {
				...r,
				mode: e.mode,
				enhancementPass: e.enhancementPass ?? 0,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				previousTexts: e.mode === "stronger" && e.draft.generated ? [...e.draft.generated.previousTexts ?? [], e.draft.generated.text] : [],
				nextTexts: []
			}
		}
	}) === "discarded") throw Error("Wynik odrzucono: szkic usunięto, wygasł albo zmieniono konto.");
	return r;
}
async function rt(e) {
	let t = await j.getSettings(), n = (await P.read()).activeOwnerFaceitId, r = t.apiAccessMode === "managed" ? await g.transcribeAudio(e) : await Xe(e);
	if (n && e.draft && await tt({
		store: P,
		owner: n,
		original: e.draft,
		result: {
			id: crypto.randomUUID(),
			transcript: r.transcript
		}
	}) === "discarded") throw Error("Transkrypcję odrzucono: szkic usunięto, wygasł albo zmieniono konto.");
	return r;
}
//#endregion
//#region src/shared/side-panel-state.ts
var F = "frh:side-panel-state", I = { view: "home" };
function it(e) {
	if (!ct(e) || !st(e.view)) return I;
	let t = at(e.target);
	if (e.view === "report" && !t) return I;
	let n = ot(e.availableRound);
	return {
		view: e.view,
		...t ? { target: t } : {},
		...n === void 0 ? {} : { availableRound: n }
	};
}
function at(e) {
	if (!(!ct(e) || typeof e.matchId != "string" || !e.matchId.trim() || typeof e.matchUrl != "string" || !e.matchUrl.trim() || typeof e.nickname != "string" || !e.nickname.trim() || e.relation !== "teammate" && e.relation !== "opponent" && e.relation !== "unknown")) return {
		matchId: e.matchId.trim(),
		matchUrl: e.matchUrl.trim(),
		nickname: e.nickname.trim(),
		relation: e.relation,
		...typeof e.playerId == "string" && e.playerId.trim() ? { playerId: e.playerId.trim() } : {},
		...e.startingSide === "CT" || e.startingSide === "T" ? { startingSide: e.startingSide } : {}
	};
}
function ot(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60 ? Number(e) : void 0;
}
function st(e) {
	return e === "home" || e === "report" || e === "settings";
}
function ct(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/side-panel.ts
function lt() {
	return {
		configureActionClick: () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }),
		openForTab: (e) => chrome.sidePanel.open({ tabId: e }),
		openForCurrentWindow: () => chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT }),
		getState: () => new Promise((e, t) => {
			chrome.storage.session.get(F, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[F]);
			});
		}),
		setState: (e) => new Promise((t, n) => {
			chrome.storage.session.set({ [F]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		})
	};
}
function ut(e) {
	let t = async () => it(await e.getState()), n = async (t) => {
		let n = it(t);
		return await e.setState(n), n;
	}, r = async (t) => (typeof t == "number" ? await e.openForTab(t) : await e.openForCurrentWindow(), { opened: !0 });
	return {
		configureActionClick: () => e.configureActionClick(),
		async openSettings(e) {
			let i = r(e), a = await t();
			return await Promise.all([i, n({
				...a,
				view: "settings"
			})]), { opened: !0 };
		},
		async openReport(e, t, i) {
			let a = r(i);
			return await Promise.all([a, n({
				view: "report",
				target: e,
				availableRound: t
			})]), { opened: !0 };
		},
		async updateReport(e, r) {
			let i = await t();
			return i.target?.matchId !== e.matchId || i.target.nickname.toLocaleLowerCase() !== e.nickname.toLocaleLowerCase() ? i : n({
				...i,
				target: e,
				availableRound: r
			});
		},
		async setView(e) {
			let r = await t();
			return e === "report" && !r.target ? n(I) : n({
				...r,
				view: e
			});
		},
		getState: t
	};
}
var L = ut(lt()), R = {
	repository: "tommyin-it/faceit-report-helper",
	assetName: "faceit-report-helper.zip",
	metadataUrl: "https://tommyin-it.github.io/faceit-report-helper/latest.json"
}, dt = R.metadataUrl, ft = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$/, pt = 65535, mt = `/${R.repository}/releases`, ht = `${mt}/latest/download/${R.assetName}`;
function z(e) {
	if (!ft.test(e)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	let t = e.split(".").map(Number);
	if (t.every((e) => e === 0) || t.some((e) => e > pt)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	return [...t, ...Array(4 - t.length).fill(0)];
}
function gt(e, t) {
	let n = z(e), r = z(t);
	for (let e = 0; e < n.length; e += 1) if (n[e] !== r[e]) return n[e] < r[e] ? -1 : 1;
	return 0;
}
function _t(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function vt(e, t) {
	if (typeof e != "string") throw Error("Brak bezpiecznego adresu wydania.");
	let n = new URL(e);
	if (n.protocol !== "https:" || n.origin !== "https://github.com" || n.pathname !== t || n.search || n.hash || n.username || n.password) throw Error("Nieprawidłowy adres wydania.");
	return n.href;
}
function yt(e) {
	if (!_t(e) || e.schemaVersion !== 1 || typeof e.version != "string") throw Error("Nieprawidłowy format informacji o aktualizacji.");
	if (z(e.version), typeof e.publishedAt != "string" || !Number.isFinite(Date.parse(e.publishedAt))) throw Error("Nieprawidłowa data wydania.");
	let t = `${mt}/tag/v${e.version}`, n = e.sha256;
	if (n !== void 0 && (typeof n != "string" || !/^[a-f0-9]{64}$/.test(n))) throw Error("Nieprawidłowa suma kontrolna wydania.");
	return {
		schemaVersion: 1,
		version: e.version,
		downloadUrl: vt(e.downloadUrl, ht),
		releaseNotesUrl: vt(e.releaseNotesUrl, t),
		publishedAt: e.publishedAt,
		...n ? { sha256: n } : {}
	};
}
function B(e, t) {
	return !t || gt(e, t.version) >= 0 ? {
		updateAvailable: !1,
		currentVersion: e
	} : {
		updateAvailable: !0,
		currentVersion: e,
		latestVersion: t.version,
		downloadUrl: t.downloadUrl,
		releaseNotesUrl: t.releaseNotesUrl,
		publishedAt: t.publishedAt
	};
}
//#endregion
//#region src/background/update.ts
var V = "frh:update-check", bt = 432e5, xt = 8e3, H;
function St() {
	return new Promise((e) => {
		chrome.storage.local.get(V, (t) => {
			if (chrome.runtime.lastError) {
				e(void 0);
				return;
			}
			let n = t[V];
			if (typeof n != "object" || !n) {
				e(void 0);
				return;
			}
			let r = n;
			if (typeof r.checkedAt != "number" || !Number.isFinite(r.checkedAt)) {
				e(void 0);
				return;
			}
			try {
				e({
					checkedAt: r.checkedAt,
					...r.metadata ? { metadata: yt(r.metadata) } : {}
				});
			} catch {
				e(void 0);
			}
		});
	});
}
function Ct(e) {
	return new Promise((t) => {
		chrome.storage.local.set({ [V]: e }, () => t());
	});
}
async function wt() {
	let e = await fetch(dt, {
		cache: "no-store",
		credentials: "omit",
		redirect: "error",
		signal: AbortSignal.timeout(xt)
	});
	if (!e.ok) throw Error(`Serwer aktualizacji zwrócił błąd ${e.status}.`);
	return yt(await e.json());
}
async function Tt() {
	let e = chrome.runtime.getManifest().version, t = Date.now(), n = await St();
	if (n && t - n.checkedAt < bt) return B(e, n.metadata);
	try {
		let n = await wt();
		return await Ct({
			checkedAt: t,
			metadata: n
		}), B(e, n);
	} catch {
		return await Ct({
			checkedAt: t,
			...n?.metadata ? { metadata: n.metadata } : {}
		}), B(e, n?.metadata);
	}
}
function Et() {
	return H ||= Tt().finally(() => {
		H = void 0;
	}), H;
}
//#endregion
//#region src/shared/request-diagnostics.ts
function Dt() {
	try {
		return `Diagnostyka: frh-network-v1\nWersja: ${chrome.runtime.getManifest().version}\nID wtyczki: ${chrome.runtime.id}`;
	} catch {
		return "Diagnostyka: frh-network-v1\nŚrodowisko: test / brak metadanych wtyczki";
	}
}
function Ot(e) {
	return `${e instanceof Error && [
		"TypeError",
		"Error",
		"AbortError",
		"TimeoutError",
		"SecurityError",
		"NetworkError"
	].includes(e.name) ? e.name : "Nieznany typ"}: ${e instanceof Error && [
		"Failed to fetch",
		"Load failed",
		"Illegal invocation",
		"Failed to execute 'fetch' on 'WorkerGlobalScope': Illegal invocation",
		"Failed to execute 'fetch' on 'Window': Illegal invocation",
		"NetworkError when attempting to fetch resource.",
		"The operation was aborted.",
		"The operation was aborted due to timeout"
	].includes(e.message) ? e.message : "Treść pominięta dla ochrony danych"}`;
}
//#endregion
//#region src/background/faceit-traffic.ts
function kt(e) {
	let t = e.now ?? Date.now, n = [], r = !1, i = 0, a = e.readCooldown?.().then((e) => {
		i = e;
	}) ?? Promise.resolve(), o = () => new b(`Limit FACEIT. Spróbuj za ${Math.max(1, Math.ceil((i - t()) / 1e3))} s.`, `FACEIT_COOLDOWN_UNTIL=${i}\nNie ponowiono żądania automatycznie.`), s = async () => {
		if (!r) {
			r = !0;
			try {
				for (await a; n.length;) {
					n.sort((e, t) => t.priority - e.priority);
					let e = n.shift();
					if (e.valid && !e.valid()) {
						e.reject(new b("Anulowano oczekującą wysyłkę po zmianie gracza lub meczu."));
						continue;
					}
					if (i > t()) {
						e.reject(o());
						continue;
					}
					await e.run();
				}
			} catch (e) {
				n.splice(0).forEach((t) => t.reject(e));
			} finally {
				r = !1;
			}
		}
	};
	return { request(r, a, c) {
		return new Promise((l, u) => {
			n.push({
				priority: +(a?.method === "POST"),
				valid: c,
				reject: u,
				run: async () => {
					try {
						let n = await e.fetch(r, {
							...a,
							signal: AbortSignal.timeout(String(r).includes("/users/v1/users/") ? 8e3 : 3e4)
						});
						if (n.status === 429) {
							let r = n.headers.get("Retry-After"), a = r && /^\d+(?:\.\d+)?$/.test(r.trim()) ? Number(r) : NaN, s = r ? Date.parse(r) : NaN;
							i = Math.max(t() + 1e3, Number.isFinite(a) ? t() + a * 1e3 : Number.isFinite(s) ? s : t() + 6e4), await e.saveCooldown?.(i), await n.body?.cancel(), u(o());
							return;
						}
						let s = await n.arrayBuffer();
						l(new Response(n.status === 204 || n.status === 205 || n.status === 304 ? null : s, {
							status: n.status,
							statusText: n.statusText,
							headers: n.headers
						}));
					} catch (e) {
						u(e);
					}
				}
			}), s();
		});
	} };
}
var U = "frh:faceit-cooldown-until", At = kt({
	fetch: (e, t) => globalThis.fetch(e, t),
	readCooldown: async () => typeof chrome > "u" ? 0 : Number((await chrome.storage.local.get(U))[U] ?? 0),
	saveCooldown: async (e) => {
		typeof chrome < "u" && await chrome.storage.local.set({ [U]: e });
	}
}), jt = {
	Griefing: {
		category: "negative",
		subCategory: "griefing"
	},
	Toxicity: {
		category: "negative",
		subCategory: "toxic"
	},
	Cheating: {
		category: "cheat",
		subCategory: "cheating"
	},
	"Multiple accounts or smurfing": {
		category: "negative",
		subCategory: "smurfing"
	},
	"Inappropriate content": {
		category: "negative",
		subCategory: "inappropriate"
	}
}, W = 1e3, Mt = 160;
function Nt(e) {
	let t = zt(e.matchId, "identyfikatora meczu"), n = zt(e.playerId, "FACEIT ID zgłaszanego gracza");
	if (!e.generated) throw Error("Bezpośrednia wysyłka wymaga wygenerowanego zgłoszenia.");
	let r = jt[e.generated.category];
	if (!r) throw Error("Wygenerowane zgłoszenie ma nieobsługiwaną kategorię.");
	if (typeof e.generated.text != "string") throw Error("Treść zgłoszenia ma nieprawidłowy format.");
	let i = e.generated.text.trim();
	if (!i) throw Error("Treść zgłoszenia nie może być pusta.");
	if (i.length > W) throw Error(`Treść zgłoszenia może mieć maksymalnie ${W} znaków.`);
	let a = G(e.generated.rounds), o = a.filter((e) => e <= 24), s = a.filter((e) => e > 24).map((e) => e - 24), c = o.length > 0 || s.length > 0 ? {
		...o.length > 0 ? { rounds: o } : {},
		...s.length > 0 ? { overtimes: s } : {}
	} : void 0, l = Rt(e.evidenceUrls);
	return {
		matchId: t,
		reportedUserId: n,
		...r,
		comment: i,
		...c ? { gameData: c } : {},
		...l.length > 0 ? { urls: l } : {}
	};
}
function Pt(e) {
	let t = Ft(e);
	if (!t) throw Error("FACEIT zwrócił nieprawidłową historię zgłoszeń.");
	return t.flatMap((e) => {
		let t = It(e);
		return t ? [t] : [];
	});
}
function Ft(e) {
	if (Array.isArray(e)) return e;
	if (q(e)) {
		if (Array.isArray(e.payload)) return e.payload;
		if (q(e.data) && Array.isArray(e.data.payload)) return e.data.payload;
	}
}
function It(e) {
	if (!q(e)) return;
	let t = K(e.matchId), n = K(e.reportedUserId), r = K(e.category), i = K(e.subCategory);
	if (!t || !n || !r || !i) return;
	let a = Lt(e.gameData), o = Array.isArray(e.urls) ? s(e.urls, 10) : [];
	return {
		matchId: t,
		reportedUserId: n,
		category: r,
		subCategory: i,
		comment: typeof e.comment == "string" ? e.comment.slice(0, W) : "",
		...a ? { gameData: a } : {},
		...o.length > 0 ? { urls: o } : {}
	};
}
function Lt(e) {
	if (!q(e)) return;
	let t = G(e.rounds), n = G(e.overtimes);
	if (t.length !== 0 || n.length !== 0) return {
		...t.length > 0 ? { rounds: t } : {},
		...n.length > 0 ? { overtimes: n } : {}
	};
}
function Rt(e) {
	let t = [];
	for (let n of e ?? []) {
		let e = o(n);
		if (!e) throw Error("Jeden z linków do dowodów jest nieprawidłowy. Usuń go i dodaj ponownie.");
		t.includes(e) || t.push(e);
	}
	if (t.length > 5) throw Error("Zgłoszenie może zawierać maksymalnie 5 linków do dowodów.");
	return t;
}
function G(e) {
	return Array.isArray(e) ? [...new Set(e)].filter((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60).sort((e, t) => e - t) : [];
}
function zt(e, t) {
	let n = K(e);
	if (!n) throw Error(`Brak ${t}. Odśwież pokój meczu i spróbuj ponownie.`);
	return n;
}
function K(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	if (!(!t || t.length > Mt)) return t;
}
function q(e) {
	return typeof e == "object" && !!e;
}
//#endregion
//#region src/background/faceit-report.ts
var Bt = "https://www.faceit.com/api/fbi/v1", Vt = 3e4;
function Ht(e = {}) {
	let t = {
		request: (e, t) => At.request(e, t),
		now: () => (/* @__PURE__ */ new Date()).toISOString(),
		readName: async (e) => typeof chrome > "u" ? void 0 : (await chrome.storage.local.get(`frh:nickname:${e}`))[`frh:nickname:${e}`],
		saveName: async (e, t) => {
			typeof chrome < "u" && await chrome.storage.local.set({ [`frh:nickname:${e}`]: t });
		},
		...e
	}, n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map(), a = {
		async submit(n, r) {
			let i = Nt(n), a = await Ut(r && !e.request ? {
				...t,
				request: (e, t) => At.request(e, t, r)
			} : t, Wt(i.matchId), {
				method: "POST",
				credentials: "include",
				headers: Gt(!0),
				body: JSON.stringify(i),
				signal: AbortSignal.timeout(Vt)
			});
			if (!a.ok) throw await Kt(a, "POST");
			return {
				submittedAt: t.now(),
				httpStatus: a.status
			};
		},
		async getForMatch(e) {
			let i = await Ut(t, Wt(e), {
				method: "GET",
				credentials: "include",
				headers: Gt(!1),
				signal: AbortSignal.timeout(Vt)
			});
			if (!i.ok) throw await Kt(i, "GET");
			let a = Pt(await i.json()).filter((t) => t.matchId === e), o = /* @__PURE__ */ new Map(), s = [...new Set(a.map((e) => e.reportedUserId))];
			t.deferNames && await Promise.all(s.map(async (e) => {
				let r = n.get(e) ?? await t.readName?.(e);
				r && o.set(e, r.nickname);
			}));
			let c = async () => {
				for (let e = 0; e < s.length; e += 4) await Promise.all(s.slice(e, e + 4).map(async (e) => {
					if (!r.has(e)) {
						r.add(e);
						try {
							let r = n.get(e) ?? await t.readName?.(e);
							if (r && Date.parse(t.now()) - r.at < 864e5) {
								o.set(e, r.nickname);
								return;
							}
							r && o.set(e, r.nickname);
							let i = await t.request(`https://www.faceit.com/api/users/v1/users/${encodeURIComponent(e)}`, {
								headers: { Accept: "application/json" },
								signal: AbortSignal.timeout(8e3)
							});
							if (!i.ok) return;
							let a = await i.json(), s = a?.payload?.nickname;
							if (a?.payload?.id === e && typeof s == "string" && s.trim() && s.length <= 100) {
								o.set(e, s.trim());
								let r = {
									nickname: s.trim(),
									at: Date.parse(t.now())
								};
								n.set(e, r), await t.saveName?.(e, r);
							}
						} catch {} finally {
							r.delete(e);
						}
					}
				}));
			};
			return t.deferNames ? c().catch(() => void 0) : await c(), { reports: a.map((e) => ({
				...e,
				nickname: o.get(e.reportedUserId)
			})) };
		}
	};
	return {
		submit: a.submit,
		getForMatch(e) {
			let t = i.get(e);
			if (t) return t;
			let n = a.getForMatch(e).finally(() => i.delete(e));
			return i.set(e, n), n;
		}
	};
}
async function Ut(e, t, n) {
	let r = Date.now();
	try {
		return await e.request(t, n);
	} catch (e) {
		if (e instanceof b) throw e;
		let t = e instanceof Error && (e.name === "TimeoutError" || e.name === "AbortError");
		throw new b(t ? "FACEIT nie odpowiedział w ciągu 30 sekund. Sprawdź historię zgłoszeń przed ponowną wysyłką." : "Nie udało się połączyć z FACEIT. Przeglądarka mogła zablokować żądanie albo wystąpił błąd sieci.", `${n.method} /api/fbi/v1/matches/{matchId}/report\nEtap: wywołano fetch w tle\nEtap: fetch zakończył się wyjątkiem po ${Date.now() - r} ms\nBłąd przeglądarki: ${Ot(e)}\n${t ? "Przekroczono limit czasu: 30 s." : "Błąd transportu: przeglądarka nie udostępniła odpowiedzi HTTP."}\n${n.method === "GET" ? "Nie udało się odczytać historii. To żądanie nie wysyła zgłoszenia." : "Nie można ustalić, czy FACEIT przyjął zgłoszenie ani czy minął czas na jego wysłanie."}`);
	}
}
function Wt(e) {
	let t = e.trim();
	if (!t || t.length > 160) throw Error("Brak prawidłowego identyfikatora meczu.");
	return `${Bt}/matches/${encodeURIComponent(t)}/report`;
}
function Gt(e) {
	return {
		Accept: "application/json, text/plain, */*",
		"faceit-referer": "web-next",
		...e ? { "Content-Type": "application/json" } : {}
	};
}
async function Kt(e, t) {
	let n = e.status, r = [`${t} /api/fbi/v1/matches/{matchId}/report`, `HTTP ${n}`], i = J(e.headers.get("x-request-id") ?? e.headers.get("cf-ray"));
	if (i && r.push(`Identyfikator żądania: ${i}`), e.headers.get("content-type")?.includes("json")) {
		let t = await qt(e);
		if (t && typeof t == "object") {
			let e = t, n = Array.isArray(e.errors) ? e.errors.slice(0, 3) : [e.error ?? e];
			for (let e of n) if (typeof e == "string") {
				let t = J(e);
				t && r.push(`FACEIT: ${t}`);
			} else if (e && typeof e == "object") {
				let t = e, n = J(t.code), i = J(t.message);
				n && r.push(`Kod FACEIT: ${n}`), i && r.push(`FACEIT: ${i}`);
			}
		}
	} else r.push("Serwer zwrócił odpowiedź inną niż JSON. Może to być strona blokady lub weryfikacji dostępu.");
	return new b(Jt(n), r.join("\n"));
}
async function qt(e) {
	let t = e.body?.getReader();
	if (!t) return;
	let n = new TextDecoder(), r = "", i = 0;
	try {
		for (;;) {
			let { done: e, value: a } = await t.read();
			if (e) break;
			if (i += a.byteLength, i > 16384) return;
			r += n.decode(a, { stream: !0 });
		}
		return JSON.parse(r + n.decode());
	} catch {
		return;
	} finally {
		await t.cancel().catch(() => void 0);
	}
}
function J(e) {
	return typeof e != "string" && typeof e != "number" ? "" : String(e).replace(/https?:\/\/\S+/gi, "[adres pominięty]").replace(/Bearer\s+\S+/gi, "Bearer [ukryto]").replace(/(?:token|secret|password|authorization|cookie|api[_-]?key)\s*[:=]\s*\S+/gi, "[dane uwierzytelniające ukryto]").replace(/[A-Za-z0-9_\-+/=]{64,}/g, "[długi identyfikator pominięty]").replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 500);
}
function Jt(e) {
	return e === 401 ? "Zaloguj się na stronie FACEIT w tej przeglądarce i spróbuj ponownie." : e === 403 ? "FACEIT odmówił dostępu (HTTP 403). Sprawdź szczegóły błędu i zalogowanie na stronie FACEIT. Sam status nie rozstrzyga, czy minął czas na zgłoszenie." : e === 409 ? "To zgłoszenie zostało już wysłane do FACEIT (HTTP 409)." : e === 429 ? "Zbyt wiele żądań do FACEIT. Odczekaj chwilę i spróbuj ponownie." : e >= 400 && e < 500 ? `FACEIT odrzucił żądanie (HTTP ${e}). Rozwiń szczegóły błędu.` : `FACEIT jest chwilowo niedostępny (HTTP ${e}).`;
}
var Y = Ht({ deferNames: !0 });
//#endregion
//#region src/shared/current-match.ts
function Yt(e) {
	if (e) try {
		let t = new URL(e);
		return t.origin === "https://www.faceit.com" ? t.pathname.match(/^\/(?:[a-z]{2}\/)?cs2\/room\/(1-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\/|$)/i)?.[1] : void 0;
	} catch {
		return;
	}
}
//#endregion
//#region src/background/provider-notice.ts
var Xt = Promise.resolve();
async function Zt(e, t) {
	let n = (await P.read()).activeOwnerFaceitId, r = crypto.randomUUID(), i = `frh:provider-notice:${n ?? "personal"}:${r}`, a = `frh:provider-notices:${n ?? "personal"}`, o = Xt.then(async () => {
		let e = (await chrome.storage.local.get(a))[a];
		await chrome.storage.local.set({ [a]: [...e ?? [], i] });
	});
	Xt = o.catch(() => void 0), await o;
	let s = (t, n) => chrome.storage.local.set({ [i]: {
		id: r,
		nickname: e,
		state: t,
		message: n,
		at: Date.now()
	} });
	await s("running", "Oczekiwanie na miejsce lub wykonywanie. Kolejka: do 30 s, wykonanie: do 60 s.");
	let c = setInterval(() => {
		chrome.storage.session.get("frh:provider-keepalive").catch(() => void 0);
	}, 2e4);
	try {
		let e = await t();
		return await s("done", "Zakończono. Wynik znajduje się w szkicu pierwotnego gracza lub czeka przy nim na zatwierdzenie."), e;
	} catch (e) {
		throw await s("error", e instanceof Error ? e.message.slice(0, 500) : "Operacja nie powiodła się. Ponów ręcznie."), e;
	} finally {
		clearInterval(c);
	}
}
//#endregion
//#region src/shared/faceit-history-cache.ts
var X = (e) => JSON.stringify([
	e.matchId,
	e.reportedUserId,
	e.comment.trim()
]);
function Qt(e) {
	let t = /* @__PURE__ */ new Map(), n = Promise.resolve(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = (e) => `frh:faceit-history:v1:${encodeURIComponent(e)}`, o = (e) => `frh:faceit-history:v2:${encodeURIComponent(e)}:index`, s = (e, t) => `frh:faceit-history:v2:${encodeURIComponent(e)}:match:${encodeURIComponent(t)}`, c = (t) => {
		let n = i.get(t);
		return n || (n = (async () => {
			if (await e.get(o(t)) !== void 0) return;
			let n = await e.get(a(t)), r = n && typeof n == "object" && !Array.isArray(n) ? Object.entries(n) : [];
			await e.set(Object.fromEntries(r.map(([e, n]) => [s(t, e), n]))), await e.set({ [o(t)]: r.map(([e]) => e) });
		})().catch((e) => {
			throw i.delete(t), e;
		}), i.set(t, n)), n;
	}, l = async (t) => {
		if (!t) return {};
		if (r.has(t)) return structuredClone(r.get(t));
		await c(t);
		let n = await e.get(o(t)) ?? [], i = Object.fromEntries(await Promise.all(n.map(async (n) => [n, await e.get(s(t, n))]))), l = new Set(await e.get(`${a(t)}:hidden`) ?? []);
		if (!i || typeof i != "object" || Array.isArray(i)) return {};
		let u = {};
		for (let [e, t] of Object.entries(i)) {
			if (!t || typeof t.checkedAt != "string" || !Array.isArray(t.reports)) continue;
			let n = Pt({ payload: t.reports }).filter((t) => t.matchId === e && !l.has(X(t))), r = new Map(t.reports.filter(Boolean).map((e) => [e.reportedUserId, e.nickname]));
			u[e] = {
				checkedAt: t.checkedAt,
				reports: n.map((e) => {
					let t = r.get(e.reportedUserId);
					return {
						...e,
						...typeof t == "string" && t.length <= 100 ? { nickname: t } : {}
					};
				})
			};
		}
		return r.set(t, u), u;
	};
	return {
		read: async (t) => {
			let n = await l(t), r = Object.values(n).flatMap((e) => e.reports), i = new Map(await Promise.all([...new Set(r.map((e) => e.reportedUserId))].map(async (t) => [t, await e.get(`frh:nickname:${t}`)])));
			for (let e of r) {
				let t = i.get(e.reportedUserId)?.nickname;
				typeof t == "string" && t.length <= 100 && (e.nickname = t);
			}
			return n;
		},
		hide(t, i) {
			let o = `${a(t)}:hidden`, s = n.then(async () => {
				let n = await e.get(o) ?? [], a = JSON.stringify([
					i.matchId,
					i.reportedUserId,
					i.comment.trim()
				]);
				await e.set({ [o]: [.../* @__PURE__ */ new Set([...n, a])] }), r.delete(t);
			});
			return n = s.catch(() => void 0), s;
		},
		get(i, c, u, d = !1) {
			if (!i) return Promise.reject(/* @__PURE__ */ Error("Brak konta dla historii FACEIT."));
			let f = `${a(i)}:${encodeURIComponent(c)}`, p = t.get(f);
			if (p) return p;
			let m = (async () => {
				let t = (await l(i))[c];
				if (t && !d) return t;
				let { reports: a } = await u(), f = {
					checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
					reports: a
				}, p = n.then(async () => {
					let t = await l(i), n = new Map((t[c]?.reports ?? []).map((e) => [X(e), e]));
					for (let e of a) {
						let t = n.get(X(e));
						n.set(X(e), {
							...e,
							nickname: e.nickname ?? t?.nickname
						});
					}
					f.reports = [...n.values()], await e.set({ [s(i, c)]: f }), await e.set({ [o(i)]: [.../* @__PURE__ */ new Set([...Object.keys(t), c])] }), r.delete(i);
				});
				return n = p.catch(() => void 0), await p, f;
			})().finally(() => t.delete(f));
			return t.set(f, m), m;
		}
	};
}
Qt(k());
//#endregion
//#region src/background/index.ts
var Z = Qt(k()), $t = A(k());
async function Q(e) {
	let t = await $t.read();
	if (!e || t.activeOwnerFaceitId !== e) throw Error("Konto historii uległo zmianie.");
}
var $ = 0;
chrome.tabs.onActivated.addListener(() => {
	$++;
}), chrome.tabs.onUpdated.addListener((e, t) => {
	t.url && $++;
});
function en(e, t) {
	switch (e.type) {
		case "CANCEL_PENDING_FACEIT_SUBMISSIONS": return $++, Promise.resolve({ cancelled: !0 });
		case "READ_FACEIT_HISTORY": return Q(e.owner).then(() => Z.read(e.owner));
		case "LOAD_FACEIT_HISTORY": return Q(e.owner).then(() => Z.get(e.owner, e.matchId, () => Y.getForMatch(e.matchId), e.force));
		case "HIDE_FACEIT_HISTORY": return Q(e.owner).then(async () => (await Z.hide(e.owner, e.report), { hidden: !0 }));
		case "OPEN_OPTIONS": return L.openSettings(t.tab?.id);
		case "OPEN_REPORT_PANEL": return $++, L.openReport(e.target, e.availableRound, t.tab?.id);
		case "UPDATE_REPORT_PANEL": return L.updateReport(e.target, e.availableRound);
		case "SET_SIDE_PANEL_VIEW": return L.setView(e.view);
		case "GET_SIDE_PANEL_STATE": return L.getState();
		case "GET_CURRENT_MATCH": return chrome.tabs.query({
			active: !0,
			currentWindow: !0
		}).then(([e]) => ({ matchId: Yt(e?.url) }));
		case "CHECK_FOR_UPDATE": return Et();
		case "GET_MANAGED_ACCESS_STATUS": return g.getStatus();
		case "SIGN_IN_MANAGED_ACCESS": return g.signIn();
		case "SIGN_OUT_MANAGED_ACCESS": return $++, g.signOut();
		case "TRANSCRIBE_AUDIO": return Zt(e.draft?.nickname ?? "Transkrypcja", () => rt(e));
		case "GENERATE_REPORT": return Zt(e.draft.nickname, () => nt(e));
		case "SUBMIT_FACEIT_REPORT": {
			let t = $;
			return Y.submit(e.draft, () => t === $);
		}
		case "GET_FACEIT_MATCH_REPORTS": return Y.getForMatch(e.matchId);
		case "SYNC_ACCOUNT_REPORTS": return g.syncReports(e);
	}
}
L.configureActionClick().catch((e) => {
	console.error("Unable to configure the extension side panel.", e);
}), chrome.runtime.onMessage.addListener((e, t, n) => (en(e, t).then((e) => n({
	ok: !0,
	data: e
})).catch((t) => n({
	ok: !1,
	error: t instanceof Error ? t.message : "Nieznany błąd.",
	...e.type === "GET_FACEIT_MATCH_REPORTS" || e.type === "SUBMIT_FACEIT_REPORT" ? { details: `${Dt()}\nEtap: service worker odebrał żądanie\n${t instanceof b && t.details ? t.details : "Etap: błąd przed uzyskaniem wyniku operacji"}` } : t instanceof b && t.details ? { details: t.details } : {}
})), !0));
//#endregion
