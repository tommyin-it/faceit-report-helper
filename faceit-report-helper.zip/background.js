//#region src/shared/defaultPrompt.ts
var e = "Turn the user's rough Polish notes into one clear, natural English FACEIT CS2 player report.\n\nThe input may contain loose words, sentence fragments, shorthand, spelling mistakes, dictated text, or several separate notes. Understand their intended meaning, combine related details, and rewrite them as complete, grammatically correct English sentences. Preserve every useful detail supplied by the user, including the reported actions, relevant context, exact rounds, repetition, communication, and the effect on the match. Translate Polish CS terminology naturally into familiar English CS terminology.\n\nUse only information supplied in the incidents. Never invent actions, quotes, rounds, frequency, intent, motives, or consequences. Do not turn an assumption into a fact. A gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it. Do not report ordinary poor play as griefing.\n\nWrite like a normal player submitting a credible report: direct, factual, easy to understand, and appropriately firm. Use full sentences and smooth transitions where useful. Do not use headings, bullet lists, an em dash, corporate language, a conclusion sentence, or any mention of AI. Avoid awkward literal translations and unnecessary repetition.\n\nReturn one English report containing all relevant supplied information, even when the incidents span multiple categories. Keep it below 1000 characters.";
//#endregion
//#region src/shared/environment.ts
function t() {
	return !!globalThis.__FRH_LOCAL_FIXTURE__;
}
//#endregion
//#region src/shared/behaviors.ts
function n(e, t, n, r, i, a) {
	return {
		id: e,
		label: t,
		promptLabel: n,
		category: r,
		actionable: !0,
		scopes: i,
		...a ? { quickFor: a } : {}
	};
}
var r = [
	n("teamflash", "Rzucanie flashy prosto w sojuszników podczas pusha", "deliberately throwing flashbangs directly at teammates during a push", "griefing", ["teammate"], ["teammate"]),
	n("team-damage", "Celowe strzelanie do teammate’ów / team damage", "deliberately shooting teammates or causing team damage", "griefing", ["teammate"], ["teammate"]),
	n("team-he", "Celowe rzucanie HE w sojuszników", "deliberately throwing HE grenades at teammates", "griefing", ["teammate"]),
	n("team-molotov", "Celowe rzucanie molotovów pod sojuszników", "deliberately throwing Molotovs under teammates", "griefing", ["teammate"]),
	n("blocking", "Bodyblockowanie teammate’a w drzwiach lub przejściu", "deliberately body-blocking a teammate in a doorway or passage", "griefing", ["teammate"], ["teammate"]),
	n("team-smoke-block", "Celowe blokowanie wejścia własnemu teamowi smoke’em", "deliberately blocking the team's entrance with a smoke grenade", "griefing", ["teammate"]),
	n("knife-nonparticipation", "Celowe bieganie z nożem i nieuczestniczenie w rundzie", "deliberately running with a knife and not participating in the round", "griefing", ["teammate"]),
	n("intentional-suicide", "Celowe popełnianie samobójstwa w rundzie", "deliberately committing suicide during a round", "griefing", ["teammate"]),
	n("bomb-separation", "Zabieranie bomby i celowe odchodzenie od reszty drużyny", "taking the bomb and deliberately moving away from the rest of the team", "griefing", ["teammate"]),
	n("bomb-at-spawn", "Celowe zostawianie bomby na spawnie", "deliberately leaving the bomb at spawn", "griefing", ["teammate"]),
	n("afk", "AFK przez znaczną część rundy", "being AFK for a significant part of the round", "griefing", ["teammate"], ["teammate"]),
	n("evading-kick", "Minimalne poruszanie się tylko w celu uniknięcia AFK/kicka", "moving only enough to avoid an AFK removal or kick", "griefing", ["teammate"]),
	n("throwing", "Celowe oddawanie rund / brak próby wygrania rundy", "deliberately giving away rounds or making no attempt to win", "griefing", ["teammate"], ["teammate"]),
	n("position-revealing-shots", "Celowe strzelanie w ściany / powietrze w celu zdradzenia pozycji drużyny", "deliberately shooting walls or the air to reveal the team's position", "griefing", ["teammate"]),
	n("spawn-molotov", "Celowe rzucanie molotovów na własnym spawnie", "deliberately throwing Molotovs at the team's own spawn", "griefing", ["teammate"]),
	n("utility-waste", "Celowe marnowanie utility drużyny", "deliberately wasting the team's utility", "griefing", ["teammate"]),
	n("refuse-defuse", "Celowe niepodejmowanie próby defuse mimo możliwości", "deliberately refusing to attempt a possible defuse", "griefing", ["teammate"]),
	n("block-plant", "Celowe utrudnianie plantowania bomby", "deliberately obstructing a bomb plant", "griefing", ["teammate"]),
	n("block-defuse", "Celowe utrudnianie rozbrajania bomby teammate’owi", "deliberately obstructing a teammate's defuse", "griefing", ["teammate"]),
	n("discard-equipment", "Celowe wyrzucanie broni/utility w miejsca niedostępne dla drużyny", "deliberately throwing weapons or utility where teammates cannot retrieve them", "griefing", ["teammate"]),
	n("mic-spam", "Ciągłe krzyczenie i zakłócanie komunikacji voice", "repeatedly shouting and disrupting voice communication", "toxicity", ["teammate"], ["teammate"]),
	n("voice-music", "Puszczanie muzyki / soundboardu przez voice chat", "playing music or a soundboard over voice chat", "toxicity", ["teammate"]),
	n("chat-spam", "Spamowanie wiadomości lub bindów na czacie", "spamming messages or binds in text chat", "toxicity", ["any"]),
	n("early-giveup-spam", "Floodowanie „gg”, „end”, „ff” itp. od początku meczu", "flooding chat with 'gg', 'end', 'ff', or similar messages from the start of the match", "toxicity", ["any"]),
	n("harassment", "Ciągłe personalne obrażanie konkretnego gracza", "repeatedly directing personal insults at a specific player", "toxicity", ["any"], ["teammate", "opponent"]),
	n("racism", "Używanie rasistowskich wyzwisk", "using racist slurs", "toxicity", ["any"], ["teammate", "opponent"]),
	n("homophobia", "Homofobiczne komentarze lub wyzwiska", "making homophobic comments or using homophobic slurs", "toxicity", ["any"]),
	n("sexism", "Seksistowskie komentarze lub wyzwiska", "making sexist comments or using sexist slurs", "toxicity", ["any"]),
	n("threats", "Grożenie innemu graczowi śmiercią lub przemocą", "threatening another player with death or violence", "toxicity", ["any"]),
	n("self-harm", "Zachęcanie innego gracza do samobójstwa / self-harm", "encouraging another player to commit suicide or self-harm", "toxicity", ["any"]),
	n("hateful-nickname", "Obraźliwy / nienawistny nickname", "using an offensive or hateful nickname", "toxicity", ["any"], ["opponent"]),
	n("hateful-avatar", "Obraźliwy / nienawistny avatar lub zdjęcie profilowe", "using an offensive or hateful avatar or profile picture", "toxicity", ["any"]),
	n("report-spam", "Spamowanie komendą !report lub nawoływanie do masowego reportowania", "spamming the !report command or calling for mass reports", "toxicity", ["any"]),
	n("wallhack", "Używanie wallhacka / informacji o przeciwniku bez możliwości ich zdobycia", "using a wallhack or enemy information that could not legitimately be obtained", "cheating", ["any"], ["opponent"]),
	n("aimbot", "Używanie aimbota / nienaturalne automatyczne namierzanie przeciwników", "using an aimbot or unnatural automatic targeting of opponents", "cheating", ["any"], ["opponent"]),
	n("triggerbot", "Triggerbot / automatyczne oddawanie strzału po wejściu przeciwnika w celownik", "using a triggerbot that automatically fires when an opponent enters the crosshair", "cheating", ["any"], ["opponent"]),
	n("aim-assistance", "Inne niedozwolone wspomaganie celowania lub recoil control", "using other prohibited aim assistance or recoil control", "cheating", ["any"]),
	n("stream-sniping", "Stream sniping w celu zdobywania informacji o przeciwniku", "stream sniping to obtain information about an opponent", "cheating", ["any"], ["opponent"]),
	n("enemy-position-ghosting", "Ghosting — przekazywanie informacji o pozycjach przeciwników bez podstaw do ich posiadania", "communicating enemy positions without a legitimate source for that information", "cheating", ["any"]),
	n("ghosting", "Przekazywanie przeciwnikom pozycji własnych teammate’ów przez all-chat", "revealing teammates' positions to opponents through all-chat", "cheating", ["any"]),
	n("smurf", "Granie na dodatkowym koncie znacznie poniżej rzeczywistego poziomu gracza", "playing on an additional account far below the player's true skill level", "smurfing", ["any"], ["opponent"]),
	n("deranking", "Celowe zaniżanie ELO/ranku, aby grać przeciwko słabszym graczom", "deliberately lowering ELO or rank to play against weaker opponents", "smurfing", ["any"]),
	n("boosting", "Boostowanie konta innego gracza poprzez grę na znacznie niższym poziomie lobby", "boosting another player's account by playing in a substantially lower-skilled lobby", "smurfing", ["any"], ["opponent"]),
	n("account-sharing", "Udostępnianie / używanie cudzego konta w celu podniesienia jego ELO", "sharing or using another person's account to raise its ELO", "smurfing", ["any"]),
	n("matchmaking-evasion", "Tworzenie nowego konta w celu obchodzenia właściwego poziomu matchmakingu", "creating a new account to evade the player's proper matchmaking level", "smurfing", ["any"])
], i = new Map(r.map((e) => [e.id, e]));
function a(e) {
	let t = e.trim().replace(/\s+/g, " ").toLocaleLowerCase();
	return t ? `custom:${t}` : "";
}
//#endregion
//#region src/shared/domain.ts
function o(e) {
	return `${e}-${crypto.randomUUID()}`;
}
function s(e) {
	let t = e.playerId || e.nickname.toLocaleLowerCase();
	return `${e.matchId}:${t}`;
}
function c(e) {
	switch (e.kind) {
		case "single": return `Runda ${e.round}`;
		case "range": return `Rundy ${e.from}–${e.to}`;
		case "selected":
			if (e.rounds.length === 0) return "Runda nieznana";
			if (e.rounds.some((e) => e > 24)) {
				let t = [...new Set(e.rounds.filter((e) => e >= 1 && e <= 24))].sort((e, t) => e - t);
				return t.length === 0 ? "Dogrywka" : `${t.length === 1 ? `Runda ${t[0]}` : `Rundy ${d(t)}`} i dogrywka`;
			}
			return e.rounds.length === 1 ? `Runda ${e.rounds[0]}` : `Rundy ${d(e.rounds)}`;
		case "whole": return "Cały mecz";
		case "unknown": return "Bez wskazanych rund";
	}
}
function l(e) {
	return e.trim().replace(/\s+/g, " ");
}
function u(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e ?? []) {
		let e = l(r), i = e.toLocaleLowerCase();
		!e || n.has(i) || (n.add(i), t.push(e));
	}
	return t;
}
function d(e) {
	let t = [...new Set(e)].sort((e, t) => e - t), n = [], r = t[0], i = t[0];
	for (let e of t.slice(1)) {
		if (e === i + 1) {
			i = e;
			continue;
		}
		n.push(r === i ? `${r}` : `${r}–${i}`), r = e, i = e;
	}
	return r !== void 0 && i !== void 0 && n.push(r === i ? `${r}` : `${r}–${i}`), n.join(", ");
}
//#endregion
//#region src/shared/prompt.ts
var f = [
	"Rewrite the report in a significantly firmer, more decisive tone. Make the player's behavior sound clearly unacceptable and emphasize how seriously it disrupted the team and harmed the match. Use strong, direct language that encourages a moderator to take the report seriously. Preserve every factual detail exactly. Do not invent actions, intent, repetition, quotes, consequences, or rounds.",
	"Rewrite the report to sound forceful, urgent, and uncompromising. Clearly condemn the reported behavior and strongly emphasize its negative impact on the team and the integrity of the match. Remove soft, hesitant, or neutral wording. Make every sentence direct and impactful while remaining suitable for a FACEIT moderation report. Do not add, alter, or exaggerate any factual claims.",
	"Rewrite this report using the strongest credible language appropriate for a formal FACEIT complaint. Present the described conduct as completely unacceptable and make its disruptive impact impossible to overlook. Use sharp, authoritative, high-impact sentences and an urgent tone. The result should strongly communicate that moderator attention is warranted. Intensify only the wording and presentation - never invent or exaggerate behavior, intent, frequency, evidence, quotes, rounds, or consequences."
], p = {
	normal: "Write a balanced, factual report. Adapt length to the evidence, normally 3 to 5 short sentences.",
	stronger: f[0]
};
function m(e, t, n, r = 1) {
	if (t !== "normal" && n) {
		let e = Math.min(3, Math.max(1, r));
		return [
			`Task: ${f[e - 1]}`,
			`Intensity pass: ${e} of 3`,
			"Edit only the latest ready English report below. Treat it as the sole source text for this rewrite.",
			"Preserve every factual claim, player identity, round number, category, and subcategory.",
			"Do not reconstruct the report from source notes and do not introduce new information.",
			`Category: ${n.category}`,
			`Subcategory: ${n.subcategory}`,
			`Rounds: ${n.rounds.length ? n.rounds.join(", ") : "none"}`,
			"Ready report:",
			n.text
		].join("\n");
	}
	let a = e.incidents.map((e, t) => {
		let n = [], r = [];
		for (let t of e.behaviorIds) {
			let e = i.get(t);
			e && (e.actionable ? n : r).push(e.promptLabel);
		}
		n.push(...u(e.customBehaviorLabels).map((e) => `user-defined offence: ${e}`));
		let a = e.rounds.kind === "unknown" ? [] : [`Time: ${c(e.rounds)}`], o = [...e.note.trim() ? [`User note: ${e.note.trim()}`] : [], ...(e.transcriptEntries ?? []).map((e) => e.trim()).filter(Boolean).map((e, t) => `Voice note ${t + 1}: ${e}`)];
		return [
			`Incident ${t + 1}`,
			...a,
			`Offences selected: ${n.length ? n.join("; ") : "none"}`,
			`Gameplay context: ${r.length ? r.join("; ") : "none"}`,
			`User confirmed deliberate sabotage: ${e.intentionalSabotage ? "yes" : "no"}`,
			...o.length > 0 ? o : ["User details: none"]
		].join("\n");
	});
	return [
		`Reported player: ${e.nickname}`,
		`Relation: ${e.relation}`,
		`Requested version: ${p[t]}`,
		"",
		a.join("\n\n")
	].join("\n");
}
function h(e) {
	let t = e.replace(/[—–]/g, "-").replace(/\s+/g, " ").trim();
	if (t.length <= 1e3) return t;
	let n = t.slice(0, 997), r = Math.max(n.lastIndexOf("."), n.lastIndexOf("!"), n.lastIndexOf("?"));
	if (r >= 650) return n.slice(0, r + 1);
	let i = n.lastIndexOf(" ");
	return `${n.slice(0, i > 0 ? i : 997)}...`;
}
//#endregion
//#region src/shared/preferences.ts
var g = "Zgłoś gracza";
function _(e) {
	if (typeof e != "string") return g;
	let t = e.trim().replace(/\s+/gu, " ");
	return t ? Array.from(t).slice(0, 32).join("") : g;
}
//#endregion
//#region src/shared/config.ts
var v = {
	xaiApiKey: "",
	deepgramApiKey: "",
	xaiModel: "grok-4.20-0309-non-reasoning",
	transcriptionLanguage: "pl",
	customPrompt: e,
	rosterActionLabel: g
}, y = {
	drafts: "frh:drafts",
	reports: "frh:reports",
	settings: "frh:settings",
	customBehaviors: "frh:custom-behaviors",
	behaviorUsage: "frh:behavior-usage"
}, b = "Zgłoś frajera";
function x() {
	return {
		get(e) {
			if (t() || typeof chrome > "u" || !chrome.storage?.local) {
				let t = localStorage.getItem(e);
				return Promise.resolve(t ? JSON.parse(t) : void 0);
			}
			return new Promise((t, n) => {
				chrome.storage.local.get(e, (r) => {
					let i = chrome.runtime.lastError;
					i ? n(Error(i.message)) : t(r[e]);
				});
			});
		},
		set(e) {
			if (t() || typeof chrome > "u" || !chrome.storage?.local) {
				for (let [t, n] of Object.entries(e)) localStorage.setItem(t, JSON.stringify(n));
				return Promise.resolve();
			}
			return new Promise((t, n) => {
				chrome.storage.local.set(e, () => {
					let e = chrome.runtime.lastError;
					e ? n(Error(e.message)) : t();
				});
			});
		},
		subscribe(e) {
			if (t() || typeof chrome > "u" || !chrome.storage?.onChanged) return () => void 0;
			let n = (t, n) => {
				n === "local" && e(t);
			};
			return chrome.storage.onChanged.addListener(n), () => chrome.storage.onChanged.removeListener(n);
		}
	};
}
function S(e) {
	let t = Promise.resolve(), n = async () => {
		let t = await e.get(y.settings), n = {
			...v,
			...t
		};
		return n.xaiModel.trim() === "grok-4.3" && (n.xaiModel = v.xaiModel), n.customPrompt.trim() === "You write concise FACEIT CS2 player reports in natural English.\n\nUse only the incidents supplied by the user. Never invent actions, quotes, rounds, frequency, intent, or consequences. You may make the wording firm and clear, but a gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it.\n\nWrite like a normal player: short direct sentences, familiar CS terminology, no headings, no bullet lists, no em dash, no corporate language, no conclusion sentence, and no mention of AI. Focus on observable behaviour, repetition, exact rounds when provided, and how the behaviour disrupted the match. Do not report ordinary bad play as griefing.\n\nReturn a single English report even when the incidents span multiple categories. Pick only a suggested FACEIT category; the user decides where to submit it. Keep the report below 1000 characters." && (n.customPrompt = v.customPrompt), n.rosterActionLabel = _(n.rosterActionLabel), n.rosterActionLabel === b && (n.rosterActionLabel = g), n;
	}, r = (t) => e.set({ [y.settings]: {
		...t,
		rosterActionLabel: _(t.rosterActionLabel)
	} }), i = async () => await e.get(y.drafts) ?? {}, a = async () => await e.get(y.reports) ?? [], c = (n) => {
		let r = t.catch(() => void 0).then(async () => {
			let [t, r] = await Promise.all([i(), a()]), o = await n(t, r);
			return await e.set({
				[y.drafts]: t,
				[y.reports]: r
			}), o;
		});
		return t = r, r;
	}, l = async () => D(await e.get(y.behaviorUsage));
	return {
		getSettings: n,
		saveSettings: r,
		async getBehaviorSnapshot() {
			let [t, n] = await Promise.all([e.get(y.customBehaviors), l()]);
			return {
				customBehaviors: u(t),
				usage: n
			};
		},
		async saveCustomBehaviors(t) {
			let n = u(t);
			return await e.set({ [y.customBehaviors]: n }), n;
		},
		async recordBehaviorUsage(t, n = []) {
			let r = await l(), i = T(t, n);
			for (let e of i) r[e] = (r[e] ?? 0) + 1;
			return await e.set({ [y.behaviorUsage]: r }), r;
		},
		async loadReportWorkspace(e) {
			let [t, r, o] = await Promise.all([
				i(),
				a(),
				n()
			]);
			return {
				draft: t[s(e)] ?? Object.values(t).find((t) => t.matchId === e.matchId && t.nickname.toLocaleLowerCase() === e.nickname.toLocaleLowerCase()),
				reports: r,
				matchDrafts: Object.values(t).filter((t) => t.matchId === e.matchId),
				transcriptionLanguage: o.transcriptionLanguage
			};
		},
		saveDraft(e) {
			return c((t) => {
				t[e.key] = w(e);
			});
		},
		archiveDraft(e) {
			return c((t, n) => {
				let r = {
					...w(e),
					archiveId: o("report"),
					submittedAt: (/* @__PURE__ */ new Date()).toISOString()
				};
				return n.unshift(r), delete t[e.key], [...n];
			});
		},
		deleteArchivedReport(e) {
			return c((t, n) => {
				let r = n.filter((t) => t.archiveId !== e);
				return n.splice(0, n.length, ...r), [...n];
			});
		},
		async getRosterBadges() {
			let [e, t] = await Promise.all([i(), a()]), n = /* @__PURE__ */ new Map();
			for (let t of Object.values(e)) {
				let e = O(t.matchId, t.nickname), r = n.get(e) ?? {
					draftEntries: 0,
					reports: 0
				};
				r.draftEntries += t.incidents.length, n.set(e, r);
			}
			for (let e of t) {
				let t = O(e.matchId, e.nickname), r = n.get(t) ?? {
					draftEntries: 0,
					reports: 0
				};
				r.reports += 1, n.set(t, r);
			}
			return n;
		},
		async getRosterActionLabel() {
			return (await n()).rosterActionLabel;
		},
		subscribeRosterChanges(t) {
			return e.subscribe?.((e) => {
				let n = /* @__PURE__ */ new Set();
				(y.drafts in e || y.reports in e) && n.add("badges");
				let r = e[y.settings];
				r && k(r) && n.add("action-label"), n.size > 0 && t(n);
			}) ?? (() => void 0);
		}
	};
}
var C = S(x());
function w(e) {
	return {
		...e,
		incidents: e.incidents.map((e) => ({
			...e,
			customBehaviorLabels: u(e.customBehaviorLabels)
		})),
		composer: e.composer ? {
			...e.composer,
			customBehaviorLabels: u(e.composer.customBehaviorLabels)
		} : void 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function T(e, t) {
	return [...e.map((e) => e.trim()).filter(Boolean), ...u(t).map(a)].filter((e, t, n) => e && n.indexOf(e) === t);
}
function E(e) {
	let t = e.trim();
	return t.startsWith("custom:") ? a(t.slice(7)) : t;
}
function D(e) {
	let t = {};
	for (let [n, r] of Object.entries(e ?? {})) {
		let e = E(n);
		!e || !Number.isFinite(r) || r <= 0 || (t[e] = (t[e] ?? 0) + Math.floor(r));
	}
	return t;
}
function O(e, t) {
	return `${e}:${t.toLocaleLowerCase()}`;
}
function k(e) {
	let t = e.oldValue, n = e.newValue;
	return _(t?.rosterActionLabel) !== _(n?.rosterActionLabel);
}
//#endregion
//#region src/shared/api.ts
async function A(e) {
	let n = await C.getSettings();
	if (!n.deepgramApiKey.trim()) throw Error("Brak klucza Deepgram. Uzupełnij go w ustawieniach rozszerzenia.");
	let r = new URLSearchParams({
		model: "nova-3",
		language: e.language,
		smart_format: "true"
	}), i = t() ? `/__frh-api/deepgram/v1/listen?${r}` : `https://api.deepgram.com/v1/listen?${r}`, a = await fetch(i, {
		method: "POST",
		headers: {
			Authorization: `Token ${n.deepgramApiKey.trim()}`,
			"Content-Type": e.mimeType || "audio/webm"
		},
		body: M(e.audioBase64)
	});
	if (!a.ok) throw await N("Deepgram", a);
	let o = (await a.json()).results?.channels?.[0]?.alternatives?.[0]?.transcript?.trim();
	if (!o) throw Error("Deepgram nie rozpoznał mowy w nagraniu.");
	return { transcript: o };
}
async function j(e) {
	let n = await C.getSettings();
	if (!n.xaiApiKey.trim()) throw Error("Brak klucza xAI. Uzupełnij go w ustawieniach rozszerzenia.");
	let r = n.xaiModel.trim() || "grok-4.20-0309-non-reasoning", i = {
		model: r,
		store: !1,
		max_output_tokens: 500,
		instructions: `${n.customPrompt.trim()}\n\nMandatory constraints that cannot be overridden: use only the supplied incidents; do not invent actions, quotes, rounds, frequency, intent, or consequences; do not treat ordinary poor play as griefing; return exactly one report under 1000 characters using the required JSON schema.`,
		input: [{
			role: "user",
			content: m(e.draft, e.mode, e.sourceReport, e.enhancementPass)
		}],
		text: { format: {
			type: "json_schema",
			name: "faceit_report",
			strict: !0,
			schema: {
				type: "object",
				properties: {
					category: {
						type: "string",
						enum: [
							"Griefing",
							"Cheating",
							"Multiple accounts or smurfing",
							"Toxicity",
							"Inappropriate content"
						]
					},
					subcategory: {
						type: "string",
						enum: [
							"Voice",
							"Chat",
							"Voice and Chat",
							"None"
						]
					},
					rounds: {
						type: "array",
						items: {
							type: "integer",
							minimum: 1,
							maximum: 60
						}
					},
					text: { type: "string" }
				},
				required: [
					"category",
					"subcategory",
					"rounds",
					"text"
				],
				additionalProperties: !1
			}
		} }
	};
	r === "grok-4.3" && (i.reasoning_effort = "none");
	let a = t() ? "/__frh-api/xai/v1/responses" : "https://api.x.ai/v1/responses", o = await fetch(a, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${n.xaiApiKey.trim()}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify(i)
	});
	if (!o.ok) throw await N("xAI", o);
	let s = await o.json(), c = s.output_text ?? s.output?.flatMap((e) => e.content ?? []).find((e) => e.text)?.text;
	if (!c) throw Error("xAI zwróciło pustą odpowiedź.");
	let l;
	try {
		l = JSON.parse(c);
	} catch {
		throw Error("xAI zwróciło odpowiedź w nieprawidłowym formacie.");
	}
	if (!l.text || !l.category || !Array.isArray(l.rounds)) throw Error("xAI zwróciło niekompletny report.");
	let u = e.mode === "normal" ? void 0 : e.sourceReport;
	return {
		...l,
		category: u?.category ?? l.category,
		subcategory: u?.subcategory ?? l.subcategory,
		rounds: u?.rounds ?? [...new Set(l.rounds)].sort((e, t) => e - t),
		text: h(l.text)
	};
}
function M(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = t.charCodeAt(e);
	return n;
}
async function N(e, t) {
	let n = "";
	try {
		let e = await t.json();
		n = typeof e.error == "string" ? e.error : e.error?.message || e.message || "";
	} catch {
		n = await t.text().catch(() => "");
	}
	return /* @__PURE__ */ Error(`${e} zwróciło błąd ${t.status}${n ? `: ${n.slice(0, 240)}` : ""}`);
}
var P = {
	repository: "tommyin-it/faceit-report-helper",
	assetName: "faceit-report-helper.zip",
	metadataUrl: "https://tommyin-it.github.io/faceit-report-helper/latest.json"
}, F = P.metadataUrl, I = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$/, L = 65535, R = `/${P.repository}/releases`, z = `${R}/latest/download/${P.assetName}`;
function B(e) {
	if (!I.test(e)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	let t = e.split(".").map(Number);
	if (t.every((e) => e === 0) || t.some((e) => e > L)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	return [...t, ...Array(4 - t.length).fill(0)];
}
function V(e, t) {
	let n = B(e), r = B(t);
	for (let e = 0; e < n.length; e += 1) if (n[e] !== r[e]) return n[e] < r[e] ? -1 : 1;
	return 0;
}
function H(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function U(e, t) {
	if (typeof e != "string") throw Error("Brak bezpiecznego adresu wydania.");
	let n = new URL(e);
	if (n.protocol !== "https:" || n.origin !== "https://github.com" || n.pathname !== t || n.search || n.hash || n.username || n.password) throw Error("Nieprawidłowy adres wydania.");
	return n.href;
}
function W(e) {
	if (!H(e) || e.schemaVersion !== 1 || typeof e.version != "string") throw Error("Nieprawidłowy format informacji o aktualizacji.");
	if (B(e.version), typeof e.publishedAt != "string" || !Number.isFinite(Date.parse(e.publishedAt))) throw Error("Nieprawidłowa data wydania.");
	let t = `${R}/tag/v${e.version}`, n = e.sha256;
	if (n !== void 0 && (typeof n != "string" || !/^[a-f0-9]{64}$/.test(n))) throw Error("Nieprawidłowa suma kontrolna wydania.");
	return {
		schemaVersion: 1,
		version: e.version,
		downloadUrl: U(e.downloadUrl, z),
		releaseNotesUrl: U(e.releaseNotesUrl, t),
		publishedAt: e.publishedAt,
		...n ? { sha256: n } : {}
	};
}
function G(e, t) {
	return !t || V(e, t.version) >= 0 ? {
		updateAvailable: !1,
		currentVersion: e
	} : {
		updateAvailable: !0,
		currentVersion: e,
		latestVersion: t.version,
		downloadUrl: t.downloadUrl,
		releaseNotesUrl: t.releaseNotesUrl,
		publishedAt: t.publishedAt
	};
}
//#endregion
//#region src/background/update.ts
var K = "frh:update-check", q = 432e5, J = 8e3, Y;
function X() {
	return new Promise((e) => {
		chrome.storage.local.get(K, (t) => {
			if (chrome.runtime.lastError) {
				e(void 0);
				return;
			}
			let n = t[K];
			if (typeof n != "object" || !n) {
				e(void 0);
				return;
			}
			let r = n;
			if (typeof r.checkedAt != "number" || !Number.isFinite(r.checkedAt)) {
				e(void 0);
				return;
			}
			try {
				e({
					checkedAt: r.checkedAt,
					...r.metadata ? { metadata: W(r.metadata) } : {}
				});
			} catch {
				e(void 0);
			}
		});
	});
}
function Z(e) {
	return new Promise((t) => {
		chrome.storage.local.set({ [K]: e }, () => t());
	});
}
async function Q() {
	let e = await fetch(F, {
		cache: "no-store",
		credentials: "omit",
		redirect: "error",
		signal: AbortSignal.timeout(J)
	});
	if (!e.ok) throw Error(`Serwer aktualizacji zwrócił błąd ${e.status}.`);
	return W(await e.json());
}
async function $() {
	let e = chrome.runtime.getManifest().version, t = Date.now(), n = await X();
	if (n && t - n.checkedAt < q) return G(e, n.metadata);
	try {
		let n = await Q();
		return await Z({
			checkedAt: t,
			metadata: n
		}), G(e, n);
	} catch {
		return await Z({
			checkedAt: t,
			...n?.metadata ? { metadata: n.metadata } : {}
		}), G(e, n?.metadata);
	}
}
function ee() {
	return Y ||= $().finally(() => {
		Y = void 0;
	}), Y;
}
//#endregion
//#region src/background/index.ts
function te(e) {
	switch (e.type) {
		case "OPEN_OPTIONS": return chrome.runtime.openOptionsPage().then(() => ({ opened: !0 }));
		case "CHECK_FOR_UPDATE": return ee();
		case "TRANSCRIBE_AUDIO": return A(e);
		case "GENERATE_REPORT": return j(e);
	}
}
chrome.action.onClicked.addListener(() => {
	chrome.runtime.openOptionsPage();
}), chrome.runtime.onMessage.addListener((e, t, n) => (te(e).then((e) => n({
	ok: !0,
	data: e
})).catch((e) => n({
	ok: !1,
	error: e instanceof Error ? e.message : "Nieznany błąd."
})), !0));
//#endregion
