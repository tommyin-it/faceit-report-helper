//#endregion
//#region src/shared/managed-access-config.ts
var e = t({ apiUrl: "https://faceit-report-helper-api.tomaszmiller.workers.dev" }.apiUrl);
function t(e) {
	if (typeof e != "string" || !e.trim()) return "";
	let t = new URL(e.trim());
	if (t.protocol !== "https:" || t.username || t.password || t.search || t.hash || t.pathname !== "/" && t.pathname !== "") throw Error("Managed access API URL must be a plain HTTPS origin.");
	return t.origin;
}
//#endregion
//#region src/shared/account-reports.ts
var n = [
	"Griefing",
	"Cheating",
	"Multiple accounts or smurfing",
	"Toxicity",
	"Inappropriate content"
], r = [
	"Voice",
	"Chat",
	"Voice and Chat",
	"None"
];
function i(e) {
	if (!f(e)) return;
	let t = o(e.delivery);
	if (!(!c(e.archiveId, 120) || !c(e.matchId, 160) || !s(e.matchUrl) || !l(e.nickname, 100) || e.playerId !== void 0 && !c(e.playerId, 160) || ![
		"teammate",
		"opponent",
		"unknown"
	].includes(String(e.relation)) || !Number.isInteger(e.incidentCount) || Number(e.incidentCount) < 0 || Number(e.incidentCount) > 50 || !l(e.text, 2e3) || !n.includes(e.category) || !r.includes(e.subcategory) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every(d) || !u(e.generatedAt) || !u(e.submittedAt) || !t)) return {
		archiveId: e.archiveId,
		matchId: e.matchId,
		matchUrl: e.matchUrl,
		nickname: e.nickname,
		...typeof e.playerId == "string" ? { playerId: e.playerId } : {},
		relation: e.relation,
		incidentCount: Number(e.incidentCount),
		text: e.text,
		category: e.category,
		subcategory: e.subcategory,
		rounds: [...new Set(e.rounds)].sort((e, t) => e - t),
		generatedAt: e.generatedAt,
		submittedAt: e.submittedAt,
		delivery: t
	};
}
function a(e) {
	return typeof e == "string" && /^report-[a-z0-9-]{16,100}$/iu.test(e);
}
function o(e) {
	if (!(!f(e) || e.method !== "faceit" && e.method !== "manual") && !(e.httpStatus !== void 0 && (!Number.isInteger(e.httpStatus) || Number(e.httpStatus) < 100 || Number(e.httpStatus) > 599))) return {
		method: e.method,
		...typeof e.httpStatus == "number" ? { httpStatus: e.httpStatus } : {}
	};
}
function s(e) {
	if (typeof e != "string" || e.length > 500) return !1;
	try {
		let t = new URL(e);
		return t.protocol === "https:" && (t.hostname === "faceit.com" || t.hostname === "www.faceit.com") && !t.username && !t.password;
	} catch {
		return !1;
	}
}
function c(e, t) {
	return typeof e == "string" && !!e.trim() && e.length <= t;
}
function l(e, t) {
	return typeof e == "string" && !!e.trim() && e.length <= t;
}
function u(e) {
	return typeof e == "string" && e.length <= 40 && Number.isFinite(Date.parse(e));
}
function d(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60;
}
function f(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/managed-access.ts
var p = "frh:managed-access-session", ee = 9e4;
function te() {
	return {
		getSession: () => new Promise((e, t) => {
			chrome.storage.session.get(p, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[p]);
			});
		}),
		setSession: (e) => new Promise((t, n) => {
			chrome.storage.session.set({ [p]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		}),
		removeSession: () => new Promise((e, t) => {
			chrome.storage.session.remove(p, () => {
				let n = chrome.runtime.lastError;
				n ? t(Error(n.message)) : e();
			});
		}),
		getRedirectUrl: (e) => chrome.identity.getRedirectURL(e),
		launchWebAuthFlow: (e) => chrome.identity.launchWebAuthFlow({
			url: e,
			interactive: !0
		}),
		fetch: (e, t) => fetch(e, t),
		now: () => Date.now()
	};
}
function ne(t, n = e) {
	let r = async () => {
		let e = h(await t.getSession());
		if (!e || Date.parse(e.expiresAt) <= t.now()) {
			e && await t.removeSession();
			return;
		}
		return e;
	}, i = async (e, i, a, o = ee) => {
		if (!n) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
		let s = a ?? await r();
		if (!s) throw Error("Zaloguj się przez FACEIT w ustawieniach rozszerzenia.");
		let c = new Headers(i.headers);
		c.set("Authorization", `Bearer ${s.token}`);
		let l = await t.fetch(new URL(e, n), {
			...i,
			headers: c,
			cache: "no-store",
			credentials: "omit",
			redirect: "error",
			signal: AbortSignal.timeout(o)
		});
		return l.status === 401 && await t.removeSession(), l;
	}, a = async () => {
		if (!n) return { state: "unconfigured" };
		if (!await r()) return { state: "signed-out" };
		let e = await i("/auth/session", { method: "GET" });
		if (e.status === 401) return { state: "signed-out" };
		if (!e.ok) throw await g(e);
		return re(await e.json());
	};
	return {
		getStatus: a,
		async signIn() {
			if (!n) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
			let e = t.getRedirectUrl("faceit"), r = new URL("/auth/start", n);
			r.searchParams.set("redirect_uri", e);
			let i = await t.launchWebAuthFlow(r.href);
			if (!i) throw Error("Logowanie FACEIT zostało anulowane.");
			let o = new URL(i), s = new URL(e);
			if (o.origin !== s.origin || o.pathname !== s.pathname) throw Error("FACEIT zwrócił nieprawidłowy adres logowania.");
			let c = new URLSearchParams(o.hash.replace(/^#/, "")), l = c.get("error");
			if (l === "access_denied") throw Error("To konto FACEIT nie ma dostępu do zarządzanych usług.");
			if (l) throw Error("Nie udało się zalogować przez FACEIT.");
			let u = h({
				token: c.get("token"),
				expiresAt: c.get("expires_at"),
				user: {
					faceitId: c.get("user_id"),
					nickname: c.get("nickname")
				}
			});
			if (!u || Date.parse(u.expiresAt) <= t.now()) throw Error("FACEIT zwrócił nieprawidłową sesję.");
			return await t.setSession(u), a();
		},
		async signOut() {
			return await t.removeSession(), n ? { state: "signed-out" } : { state: "unconfigured" };
		},
		async generateReport(e, t) {
			let n = await i("/v1/generate", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					...e,
					customPrompt: t
				})
			});
			if (!n.ok) throw await g(n);
			return ie(await n.json());
		},
		async transcribeAudio(e) {
			let t = await i("/v1/transcribe", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(e)
			});
			if (!t.ok) throw await g(t);
			let n = await t.json();
			if (typeof n.transcript != "string" || !n.transcript.trim()) throw Error("Usługa zarządzana zwróciła nieprawidłową transkrypcję.");
			return { transcript: n.transcript.trim() };
		},
		async syncReports(e) {
			if (!n) return { state: "signed-out" };
			let t = await r();
			if (!t) return { state: "signed-out" };
			let a = e.mutations.flatMap((e) => {
				if (e.ownerFaceitId !== t.user.faceitId) return [];
				if (e.kind === "delete") return [{
					mutationId: e.mutationId,
					kind: e.kind,
					archiveId: e.archiveId
				}];
				let { ownerFaceitId: n, ...r } = e.report;
				return [{
					mutationId: e.mutationId,
					kind: e.kind,
					report: r
				}];
			}), o = await i("/v1/reports/sync", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					protocolVersion: e.protocolVersion,
					...e.cursor ? { cursor: e.cursor } : {},
					...e.olderCursor ? { olderCursor: e.olderCursor } : {},
					mutations: a
				})
			}, t, 15e3);
			if (!o.ok) throw await g(o);
			let s = ae(await o.json());
			return {
				state: "synced",
				ownerFaceitId: t.user.faceitId,
				...s
			};
		}
	};
}
var m = ne(te());
function h(e) {
	if (!(!_(e) || !_(e.user)) && !(typeof e.token != "string" || e.token.length < 32 || typeof e.expiresAt != "string" || !Number.isFinite(Date.parse(e.expiresAt)) || typeof e.user.faceitId != "string" || !e.user.faceitId.trim() || typeof e.user.nickname != "string" || !e.user.nickname.trim())) return {
		token: e.token,
		expiresAt: e.expiresAt,
		user: {
			faceitId: e.user.faceitId.trim(),
			nickname: e.user.nickname.trim()
		}
	};
}
function re(e) {
	if (!_(e) || !_(e.user)) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	let t = h({
		token: "x".repeat(32),
		expiresAt: e.expiresAt,
		user: e.user
	});
	if (!t) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	if (typeof e.hasManagedAccess != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowy status dostępu.");
	return {
		state: "signed-in",
		user: t.user,
		expiresAt: t.expiresAt,
		hasManagedAccess: e.hasManagedAccess
	};
}
function ie(e) {
	if (!_(e) || typeof e.text != "string" || ![
		"Griefing",
		"Cheating",
		"Multiple accounts or smurfing",
		"Toxicity",
		"Inappropriate content"
	].includes(String(e.category)) || ![
		"Voice",
		"Chat",
		"Voice and Chat",
		"None"
	].includes(String(e.subcategory)) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60)) throw Error("Usługa zarządzana zwróciła nieprawidłowy report.");
	return e;
}
function ae(e) {
	if (!_(e) || !Array.isArray(e.reports) || e.reports.length > 500 || !Array.isArray(e.deletedArchiveIds) || e.deletedArchiveIds.length > 500 || !e.deletedArchiveIds.every(a) || !Array.isArray(e.acceptedMutationIds) || e.acceptedMutationIds.length > 250 || !e.acceptedMutationIds.every(oe) || typeof e.cursor != "string" || !/^(?:0|[1-9][0-9]{0,15})$/u.test(e.cursor) || typeof e.hasMoreChanges != "boolean" || e.olderCursor !== void 0 && (typeof e.olderCursor != "string" || !e.olderCursor) || typeof e.hasMoreOlder != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowe archiwum reportów.");
	let t = e.reports.map(i);
	if (t.some((e) => !e)) throw Error("Usługa zarządzana zwróciła nieprawidłowe archiwum reportów.");
	return {
		reports: t,
		deletedArchiveIds: [...new Set(e.deletedArchiveIds)],
		acceptedMutationIds: [...new Set(e.acceptedMutationIds)],
		cursor: e.cursor,
		hasMoreChanges: e.hasMoreChanges,
		...typeof e.olderCursor == "string" ? { olderCursor: e.olderCursor } : {},
		hasMoreOlder: e.hasMoreOlder
	};
}
function oe(e) {
	return typeof e == "string" && /^mutation-[a-z0-9-]{16,180}$/iu.test(e);
}
async function g(e) {
	let t = "";
	try {
		let n = await e.json();
		typeof n.error == "string" && (t = n.error);
	} catch {
		t = "";
	}
	return Error(t || `Usługa zarządzana zwróciła błąd ${e.status}.`);
}
function _(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/shared/operation-error.ts
var v = class extends Error {
	details;
	constructor(e, t) {
		super(e), this.details = t, this.name = "OperationError";
	}
}, se = "You write concise FACEIT CS2 player reports in natural English.\n\nUse only the incidents supplied by the user. Never invent actions, quotes, rounds, frequency, intent, or consequences. You may make the wording firm and clear, but a gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it.\n\nWrite like a normal player: short direct sentences, familiar CS terminology, no headings, no bullet lists, no em dash, no corporate language, no conclusion sentence, and no mention of AI. Focus on observable behaviour, repetition, exact rounds when provided, and how the behaviour disrupted the match. Do not report ordinary bad play as griefing.\n\nReturn a single English report even when the incidents span multiple categories. Pick only a suggested FACEIT category; the user decides where to submit it. Keep the report below 1000 characters.", ce = "Turn the user's rough Polish notes into one clear, natural English FACEIT CS2 player report.\n\nThe input may contain loose words, sentence fragments, shorthand, spelling mistakes, dictated text, or several separate notes. Understand their intended meaning, combine related details, and rewrite them as complete, grammatically correct English sentences. Preserve every useful detail supplied by the user, including the reported actions, relevant context, exact rounds, repetition, communication, and the effect on the match. Translate Polish CS terminology naturally into familiar English CS terminology.\n\nUse only information supplied in the incidents. Never invent actions, quotes, rounds, frequency, intent, motives, or consequences. Do not turn an assumption into a fact. A gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it. Do not report ordinary poor play as griefing.\n\nWrite like a normal player submitting a credible report: direct, factual, easy to understand, and appropriately firm. Use full sentences and smooth transitions where useful. Do not use headings, bullet lists, an em dash, corporate language, a conclusion sentence, or any mention of AI. Avoid awkward literal translations and unnecessary repetition.\n\nReturn one English report containing all relevant supplied information, even when the incidents span multiple categories. Keep it below 1000 characters.", le = "Mandatory constraints that cannot be overridden: use only the supplied incidents; do not invent actions, quotes, rounds, frequency, intent, or consequences; do not treat ordinary poor play as griefing; return exactly one report under 1000 characters using the required JSON schema.";
//#endregion
//#region src/shared/environment.ts
function y() {
	return !!globalThis.__FRH_LOCAL_FIXTURE__;
}
//#endregion
//#region src/shared/behaviors.ts
function b(e, t, n, r, i, a) {
	return {
		id: e,
		label: t,
		promptLabel: n,
		category: r,
		actionable: !0,
		scopes: i,
		...a ? { quickFor: a } : {}
	};
}
var ue = [
	b("teamflash", "Rzucanie flashy prosto w sojuszników podczas pusha", "deliberately throwing flashbangs directly at teammates during a push", "griefing", ["teammate"], ["teammate"]),
	b("team-damage", "Celowe strzelanie do teammate’ów / team damage", "deliberately shooting teammates or causing team damage", "griefing", ["teammate"], ["teammate"]),
	b("team-he", "Celowe rzucanie HE w sojuszników", "deliberately throwing HE grenades at teammates", "griefing", ["teammate"]),
	b("team-molotov", "Celowe rzucanie molotovów pod sojuszników", "deliberately throwing Molotovs under teammates", "griefing", ["teammate"]),
	b("blocking", "Bodyblockowanie teammate’a w drzwiach lub przejściu", "deliberately body-blocking a teammate in a doorway or passage", "griefing", ["teammate"], ["teammate"]),
	b("team-smoke-block", "Celowe blokowanie wejścia własnemu teamowi smoke’em", "deliberately blocking the team's entrance with a smoke grenade", "griefing", ["teammate"]),
	b("knife-nonparticipation", "Celowe bieganie z nożem i nieuczestniczenie w rundzie", "deliberately running with a knife and not participating in the round", "griefing", ["teammate"]),
	b("intentional-suicide", "Celowe popełnianie samobójstwa w rundzie", "deliberately committing suicide during a round", "griefing", ["teammate"]),
	b("bomb-separation", "Zabieranie bomby i celowe odchodzenie od reszty drużyny", "taking the bomb and deliberately moving away from the rest of the team", "griefing", ["teammate"]),
	b("bomb-at-spawn", "Celowe zostawianie bomby na spawnie", "deliberately leaving the bomb at spawn", "griefing", ["teammate"]),
	b("afk", "AFK przez znaczną część rundy", "being AFK for a significant part of the round", "griefing", ["teammate"], ["teammate"]),
	b("evading-kick", "Minimalne poruszanie się tylko w celu uniknięcia AFK/kicka", "moving only enough to avoid an AFK removal or kick", "griefing", ["teammate"]),
	b("throwing", "Celowe oddawanie rund / brak próby wygrania rundy", "deliberately giving away rounds or making no attempt to win", "griefing", ["teammate"], ["teammate"]),
	b("position-revealing-shots", "Celowe strzelanie w ściany / powietrze w celu zdradzenia pozycji drużyny", "deliberately shooting walls or the air to reveal the team's position", "griefing", ["teammate"]),
	b("spawn-molotov", "Celowe rzucanie molotovów na własnym spawnie", "deliberately throwing Molotovs at the team's own spawn", "griefing", ["teammate"]),
	b("utility-waste", "Celowe marnowanie utility drużyny", "deliberately wasting the team's utility", "griefing", ["teammate"]),
	b("refuse-defuse", "Celowe niepodejmowanie próby defuse mimo możliwości", "deliberately refusing to attempt a possible defuse", "griefing", ["teammate"]),
	b("block-plant", "Celowe utrudnianie plantowania bomby", "deliberately obstructing a bomb plant", "griefing", ["teammate"]),
	b("block-defuse", "Celowe utrudnianie rozbrajania bomby teammate’owi", "deliberately obstructing a teammate's defuse", "griefing", ["teammate"]),
	b("discard-equipment", "Celowe wyrzucanie broni/utility w miejsca niedostępne dla drużyny", "deliberately throwing weapons or utility where teammates cannot retrieve them", "griefing", ["teammate"]),
	b("mic-spam", "Ciągłe krzyczenie i zakłócanie komunikacji voice", "repeatedly shouting and disrupting voice communication", "toxicity", ["teammate"], ["teammate"]),
	b("voice-music", "Puszczanie muzyki / soundboardu przez voice chat", "playing music or a soundboard over voice chat", "toxicity", ["teammate"]),
	b("chat-spam", "Spamowanie wiadomości lub bindów na czacie", "spamming messages or binds in text chat", "toxicity", ["any"]),
	b("early-giveup-spam", "Floodowanie „gg”, „end”, „ff” itp. od początku meczu", "flooding chat with 'gg', 'end', 'ff', or similar messages from the start of the match", "toxicity", ["any"]),
	b("harassment", "Ciągłe personalne obrażanie konkretnego gracza", "repeatedly directing personal insults at a specific player", "toxicity", ["any"], ["teammate", "opponent"]),
	b("racism", "Używanie rasistowskich wyzwisk", "using racist slurs", "toxicity", ["any"], ["teammate", "opponent"]),
	b("homophobia", "Homofobiczne komentarze lub wyzwiska", "making homophobic comments or using homophobic slurs", "toxicity", ["any"]),
	b("sexism", "Seksistowskie komentarze lub wyzwiska", "making sexist comments or using sexist slurs", "toxicity", ["any"]),
	b("threats", "Grożenie innemu graczowi śmiercią lub przemocą", "threatening another player with death or violence", "toxicity", ["any"]),
	b("self-harm", "Zachęcanie innego gracza do samobójstwa / self-harm", "encouraging another player to commit suicide or self-harm", "toxicity", ["any"]),
	b("hateful-nickname", "Obraźliwy / nienawistny nickname", "using an offensive or hateful nickname", "toxicity", ["any"], ["opponent"]),
	b("hateful-avatar", "Obraźliwy / nienawistny avatar lub zdjęcie profilowe", "using an offensive or hateful avatar or profile picture", "toxicity", ["any"]),
	b("report-spam", "Spamowanie komendą !report lub nawoływanie do masowego reportowania", "spamming the !report command or calling for mass reports", "toxicity", ["any"]),
	b("wallhack", "Używanie wallhacka / informacji o przeciwniku bez możliwości ich zdobycia", "using a wallhack or enemy information that could not legitimately be obtained", "cheating", ["any"], ["opponent"]),
	b("aimbot", "Używanie aimbota / nienaturalne automatyczne namierzanie przeciwników", "using an aimbot or unnatural automatic targeting of opponents", "cheating", ["any"], ["opponent"]),
	b("triggerbot", "Triggerbot / automatyczne oddawanie strzału po wejściu przeciwnika w celownik", "using a triggerbot that automatically fires when an opponent enters the crosshair", "cheating", ["any"], ["opponent"]),
	b("aim-assistance", "Inne niedozwolone wspomaganie celowania lub recoil control", "using other prohibited aim assistance or recoil control", "cheating", ["any"]),
	b("stream-sniping", "Stream sniping w celu zdobywania informacji o przeciwniku", "stream sniping to obtain information about an opponent", "cheating", ["any"], ["opponent"]),
	b("enemy-position-ghosting", "Ghosting — przekazywanie informacji o pozycjach przeciwników bez podstaw do ich posiadania", "communicating enemy positions without a legitimate source for that information", "cheating", ["any"]),
	b("ghosting", "Przekazywanie przeciwnikom pozycji własnych teammate’ów przez all-chat", "revealing teammates' positions to opponents through all-chat", "cheating", ["any"]),
	b("smurf", "Granie na dodatkowym koncie znacznie poniżej rzeczywistego poziomu gracza", "playing on an additional account far below the player's true skill level", "smurfing", ["any"], ["opponent"]),
	b("deranking", "Celowe zaniżanie ELO/ranku, aby grać przeciwko słabszym graczom", "deliberately lowering ELO or rank to play against weaker opponents", "smurfing", ["any"]),
	b("boosting", "Boostowanie konta innego gracza poprzez grę na znacznie niższym poziomie lobby", "boosting another player's account by playing in a substantially lower-skilled lobby", "smurfing", ["any"], ["opponent"]),
	b("account-sharing", "Udostępnianie / używanie cudzego konta w celu podniesienia jego ELO", "sharing or using another person's account to raise its ELO", "smurfing", ["any"]),
	b("matchmaking-evasion", "Tworzenie nowego konta w celu obchodzenia właściwego poziomu matchmakingu", "creating a new account to evade the player's proper matchmaking level", "smurfing", ["any"])
], de = new Map(ue.map((e) => [e.id, e]));
function fe(e) {
	let t = e.trim().replace(/\s+/g, " ").toLocaleLowerCase();
	return t ? `custom:${t}` : "";
}
//#endregion
//#region src/shared/domain.ts
function pe(e) {
	let t = e.playerId || e.nickname.toLocaleLowerCase();
	return `${e.matchId}:${t}`;
}
function me(e) {
	switch (e.kind) {
		case "single": return `Runda ${e.round}`;
		case "range": return `Rundy ${e.from}–${e.to}`;
		case "selected":
			if (e.rounds.length === 0) return "Runda nieznana";
			if (e.rounds.some((e) => e > 24)) {
				let t = [...new Set(e.rounds.filter((e) => e >= 1 && e <= 24))].sort((e, t) => e - t);
				return t.length === 0 ? "Dogrywka" : `${t.length === 1 ? `Runda ${t[0]}` : `Rundy ${ge(t)}`} i dogrywka`;
			}
			return e.rounds.length === 1 ? `Runda ${e.rounds[0]}` : `Rundy ${ge(e.rounds)}`;
		case "whole": return "Cały mecz";
		case "unknown": return "Bez wskazanych rund";
	}
}
function he(e) {
	return e.trim().replace(/\s+/g, " ");
}
function x(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e ?? []) {
		let e = he(r), i = e.toLocaleLowerCase();
		!e || n.has(i) || (n.add(i), t.push(e));
	}
	return t;
}
function ge(e) {
	let t = [...new Set(e)].sort((e, t) => e - t), n = [], r = t[0], i = t[0];
	for (let e of t.slice(1)) {
		if (e === i + 1) {
			i = e;
			continue;
		}
		n.push(r === i ? `${r}` : `${r}–${i}`), r = e, i = e;
	}
	return r !== void 0 && i !== void 0 && n.push(r === i ? `${r}` : `${r}–${i}`), n.join(", ");
}
//#endregion
//#region src/shared/prompt.ts
var S = [
	"Rewrite the report in a significantly firmer, more decisive tone. Make the player's behavior sound clearly unacceptable and emphasize how seriously it disrupted the team and harmed the match. Use strong, direct language that encourages a moderator to take the report seriously. Preserve every factual detail exactly. Do not invent actions, intent, repetition, quotes, consequences, or rounds.",
	"Rewrite the report to sound forceful, urgent, and uncompromising. Clearly condemn the reported behavior and strongly emphasize its negative impact on the team and the integrity of the match. Remove soft, hesitant, or neutral wording. Make every sentence direct and impactful while remaining suitable for a FACEIT moderation report. Do not add, alter, or exaggerate any factual claims.",
	"Rewrite this report using the strongest credible language appropriate for a formal FACEIT complaint. Present the described conduct as completely unacceptable and make its disruptive impact impossible to overlook. Use sharp, authoritative, high-impact sentences and an urgent tone. The result should strongly communicate that moderator attention is warranted. Intensify only the wording and presentation - never invent or exaggerate behavior, intent, frequency, evidence, quotes, rounds, or consequences."
], _e = {
	normal: "Write a balanced, factual report. Adapt length to the evidence, normally 3 to 5 short sentences.",
	stronger: S[0]
};
function ve(e, t, n, r = 1) {
	if (t !== "normal" && n) {
		let e = Math.min(3, Math.max(1, r));
		return [
			`Task: ${S[e - 1]}`,
			`Intensity pass: ${e} of 3`,
			"Edit only the latest ready English report below. Treat it as the sole source text for this rewrite.",
			"Preserve every factual claim, player identity, round number, category, and subcategory.",
			"Do not reconstruct the report from source notes and do not introduce new information.",
			`Category: ${n.category}`,
			`Subcategory: ${n.subcategory}`,
			`Rounds: ${n.rounds.length ? n.rounds.join(", ") : "none"}`,
			"Ready report:",
			n.text
		].join("\n");
	}
	let i = e.incidents.map((e, t) => {
		let n = [], r = [];
		for (let t of e.behaviorIds) {
			let e = de.get(t);
			e && (e.actionable ? n : r).push(e.promptLabel);
		}
		n.push(...x(e.customBehaviorLabels).map((e) => `user-defined offence: ${e}`));
		let i = e.rounds.kind === "unknown" ? [] : [`Time: ${me(e.rounds)}`], a = [...e.note.trim() ? [`User note: ${e.note.trim()}`] : [], ...(e.transcriptEntries ?? []).map((e) => e.trim()).filter(Boolean).map((e, t) => `Voice note ${t + 1}: ${e}`)];
		return [
			`Incident ${t + 1}`,
			...i,
			`Offences selected: ${n.length ? n.join("; ") : "none"}`,
			`Gameplay context: ${r.length ? r.join("; ") : "none"}`,
			`User confirmed deliberate sabotage: ${e.intentionalSabotage ? "yes" : "no"}`,
			...a.length > 0 ? a : ["User details: none"]
		].join("\n");
	});
	return [
		`Reported player: ${e.nickname}`,
		`Relation: ${e.relation}`,
		`Requested version: ${_e[t]}`,
		"",
		i.join("\n\n")
	].join("\n");
}
function ye(e) {
	let t = e.replace(/[—–]/g, "-").replace(/\s+/g, " ").trim();
	if (t.length <= 1e3) return t;
	let n = t.slice(0, 997), r = Math.max(n.lastIndexOf("."), n.lastIndexOf("!"), n.lastIndexOf("?"));
	if (r >= 650) return n.slice(0, r + 1);
	let i = n.lastIndexOf(" ");
	return `${n.slice(0, i > 0 ? i : 997)}...`;
}
//#endregion
//#region src/shared/preferences.ts
var C = "Zgłoś gracza";
function w(e) {
	if (typeof e != "string") return C;
	let t = e.trim().replace(/\s+/gu, " ");
	return t ? Array.from(t).slice(0, 32).join("") : C;
}
//#endregion
//#region src/shared/config.ts
var T = {
	apiAccessMode: "personal",
	xaiApiKey: "",
	deepgramApiKey: "",
	xaiModel: "grok-4.20-0309-non-reasoning",
	transcriptionLanguage: "pl",
	customPrompt: ce,
	rosterActionLabel: C
}, be = 108e5;
function xe(e) {
	let t = Date.parse(e.updatedAt);
	return Number.isFinite(t) ? t + be : 0;
}
function E(e, t = Date.now()) {
	return xe(e) <= t;
}
//#endregion
//#region src/shared/storage.ts
var D = {
	drafts: "frh:drafts",
	reports: "frh:reports",
	settings: "frh:settings",
	customBehaviors: "frh:custom-behaviors",
	behaviorUsage: "frh:behavior-usage",
	activeReportOwner: "frh:active-report-owner",
	deletedReports: "frh:deleted-reports",
	reportMutations: "frh:report-mutations",
	reportTombstones: "frh:report-tombstones",
	reportCursors: "frh:report-cursors",
	reportArchiveVersion: "frh:report-archive-version"
}, Se = "Zgłoś frajera", Ce = 2;
function we() {
	return {
		get(e) {
			if (y() || typeof chrome > "u" || !chrome.storage?.local) {
				let t = localStorage.getItem(e);
				return Promise.resolve(t ? JSON.parse(t) : void 0);
			}
			return new Promise((t, n) => {
				chrome.storage.local.get(e, (r) => {
					let i = chrome.runtime.lastError;
					i ? n(Error(i.message)) : t(r[e]);
				});
			});
		},
		set(e) {
			if (y() || typeof chrome > "u" || !chrome.storage?.local) {
				for (let [t, n] of Object.entries(e)) localStorage.setItem(t, JSON.stringify(n));
				return Promise.resolve();
			}
			return new Promise((t, n) => {
				chrome.storage.local.set(e, () => {
					let e = chrome.runtime.lastError;
					e ? n(Error(e.message)) : t();
				});
			});
		},
		subscribe(e) {
			if (y() || typeof chrome > "u" || !chrome.storage?.onChanged) return () => void 0;
			let t = (t, n) => {
				n === "local" && e(t);
			};
			return chrome.storage.onChanged.addListener(t), () => chrome.storage.onChanged.removeListener(t);
		}
	};
}
function Te(e) {
	let t = Promise.resolve(), n = async () => {
		let [t, n, r, i, a, o, s, c] = await Promise.all([
			e.get(D.drafts),
			e.get(D.reports),
			e.get(D.activeReportOwner),
			e.get(D.reportMutations),
			e.get(D.reportTombstones),
			e.get(D.reportCursors),
			e.get(D.deletedReports),
			e.get(D.reportArchiveVersion)
		]), l = Array.isArray(n) ? [...n] : [], u = A(r), d = Oe([...Array.isArray(a) ? a : [], ...Array.isArray(s) ? s : []]), f = ke(i);
		if (c !== Ce) {
			for (let e of l) !e.ownerFaceitId || je(d, e.ownerFaceitId, e.archiveId) || j(f, {
				mutationId: Me("upsert", e.archiveId),
				ownerFaceitId: e.ownerFaceitId,
				archiveId: e.archiveId,
				kind: "upsert"
			});
			for (let e of d) e.ownerFaceitId && j(f, {
				mutationId: Me("delete", e.archiveId),
				ownerFaceitId: e.ownerFaceitId,
				archiveId: e.archiveId,
				kind: "delete"
			});
		}
		return {
			drafts: M(t) ? { ...t } : {},
			reports: l,
			...u ? { activeOwnerFaceitId: u } : {},
			pendingMutations: f,
			tombstones: d,
			cursors: Ae(o)
		};
	}, r = (t) => e.set({
		[D.drafts]: t.drafts,
		[D.reports]: t.reports,
		[D.activeReportOwner]: t.activeOwnerFaceitId ?? null,
		[D.reportMutations]: t.pendingMutations,
		[D.reportTombstones]: t.tombstones,
		[D.reportCursors]: t.cursors,
		[D.reportArchiveVersion]: Ce,
		[D.deletedReports]: []
	});
	return {
		read: n,
		saveDraft(n) {
			let r = t.catch(() => void 0).then(async () => {
				let t = { ...await e.get(D.drafts) ?? {} };
				t[n.key] = Pe(n), await e.set({ [D.drafts]: t });
			});
			return t = r, r;
		},
		mutate(e) {
			let i = t.catch(() => void 0).then(async () => {
				let t = await n(), i = await e(t);
				return await r(t), i;
			});
			return t = i, i;
		},
		subscribe(t) {
			return e.subscribe?.((e) => {
				Object.keys(e).some((e) => De.has(e)) && t();
			}) ?? (() => void 0);
		}
	};
}
function Ee(e) {
	let t = Te(e), n = async () => {
		let e = await t.read();
		return Object.values(e.drafts).some((e) => E(e)) ? t.mutate((e) => {
			for (let [t, n] of Object.entries(e.drafts)) E(n) && delete e.drafts[t];
			return e;
		}) : e;
	}, r = async () => {
		let t = await e.get(D.settings), n = {
			...T,
			...t
		};
		return n.xaiModel.trim() === "grok-4.3" && (n.xaiModel = T.xaiModel), n.customPrompt.trim() === se.trim() && (n.customPrompt = T.customPrompt), n.apiAccessMode = t?.apiAccessMode === "managed" ? "managed" : "personal", n.rosterActionLabel = w(n.rosterActionLabel), n.rosterActionLabel === Se && (n.rosterActionLabel = C), n;
	}, i = (t) => e.set({ [D.settings]: {
		...t,
		rosterActionLabel: w(t.rosterActionLabel)
	} }), a = async () => Le(await e.get(D.behaviorUsage));
	return {
		persistence: {
			getSettings: r,
			saveSettings: i,
			async getBehaviorSnapshot() {
				let [t, n] = await Promise.all([e.get(D.customBehaviors), a()]);
				return {
					customBehaviors: x(t),
					usage: n
				};
			},
			async saveCustomBehaviors(t) {
				let n = x(t);
				return await e.set({ [D.customBehaviors]: n }), n;
			},
			async recordBehaviorUsage(t, n = []) {
				let r = await a(), i = Fe(t, n);
				for (let e of i) r[e] = (r[e] ?? 0) + 1;
				return await e.set({ [D.behaviorUsage]: r }), r;
			},
			async loadReportWorkspace(e) {
				let [t, i] = await Promise.all([n(), r()]);
				return {
					draft: t.drafts[pe(e)] ?? Object.values(t.drafts).find((t) => t.matchId === e.matchId && t.nickname.toLocaleLowerCase() === e.nickname.toLocaleLowerCase()),
					matchDrafts: Object.values(t.drafts).filter((t) => t.matchId === e.matchId),
					transcriptionLanguage: i.transcriptionLanguage
				};
			},
			async getLocalDrafts() {
				let e = await n();
				return Object.values(e.drafts).filter((e) => e.incidents.length > 0 || e.generated || e.composer?.note.trim()).sort((e, t) => t.updatedAt.localeCompare(e.updatedAt));
			},
			saveDraft(e) {
				return t.saveDraft(e);
			},
			async getRosterBadges() {
				let e = await n(), t = /* @__PURE__ */ new Map();
				for (let n of Object.values(e.drafts)) {
					let e = N(n.matchId, n.nickname), r = t.get(e) ?? {
						draftEntries: 0,
						reports: 0
					};
					r.draftEntries += n.incidents.length, t.set(e, r);
				}
				for (let n of Ne(e.reports, e.activeOwnerFaceitId)) {
					let e = N(n.matchId, n.nickname), r = t.get(e) ?? {
						draftEntries: 0,
						reports: 0
					};
					r.reports += 1, t.set(e, r);
				}
				return t;
			},
			async getRosterActionLabel() {
				return (await r()).rosterActionLabel;
			},
			subscribeRosterChanges(t) {
				return e.subscribe?.((e) => {
					let n = /* @__PURE__ */ new Set();
					(D.drafts in e || D.reports in e) && n.add("badges");
					let r = e[D.settings];
					r && Re(r) && n.add("action-label"), n.size > 0 && t(n);
				}) ?? (() => void 0);
			}
		},
		accountReportArchiveStore: t
	};
}
var O = Ee(we()), k = O.persistence;
O.accountReportArchiveStore;
var De = /* @__PURE__ */ new Set([
	D.reports,
	D.activeReportOwner,
	D.deletedReports,
	D.reportMutations,
	D.reportTombstones,
	D.reportCursors,
	D.reportArchiveVersion
]);
function A(e) {
	return typeof e == "string" && e.trim() ? e.trim() : void 0;
}
function Oe(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		if (!M(n) || typeof n.archiveId != "string" || !n.archiveId) continue;
		let e = A(n.ownerFaceitId), r = {
			archiveId: n.archiveId,
			...e ? { ownerFaceitId: e } : {}
		};
		t.set(ze(r), r);
	}
	return [...t.values()];
}
function ke(e) {
	if (!Array.isArray(e)) return [];
	let t = [];
	for (let n of e) !M(n) || typeof n.mutationId != "string" || typeof n.archiveId != "string" || typeof n.ownerFaceitId != "string" || !n.ownerFaceitId.trim() || n.kind !== "upsert" && n.kind !== "delete" || j(t, {
		mutationId: n.mutationId,
		ownerFaceitId: n.ownerFaceitId.trim(),
		archiveId: n.archiveId,
		kind: n.kind
	});
	return t;
}
function j(e, t) {
	let n = (e) => e.ownerFaceitId === t.ownerFaceitId && e.archiveId === t.archiveId, r = e.find(n);
	(r?.kind !== "delete" || t.kind !== "upsert") && (r && e.splice(e.findIndex(n), 1), e.push(t));
}
function Ae(e) {
	if (!M(e)) return {};
	let t = {};
	for (let [n, r] of Object.entries(e)) !n.trim() || !M(r) || (t[n] = {
		...typeof r.cursor == "string" && /^(?:0|[1-9][0-9]*)$/u.test(r.cursor) ? { cursor: r.cursor } : {},
		...typeof r.olderCursor == "string" && r.olderCursor ? { olderCursor: r.olderCursor } : {},
		hasMoreOlder: r.hasMoreOlder === !0
	});
	return t;
}
function je(e, t, n) {
	return e.some((e) => e.ownerFaceitId === t && e.archiveId === n);
}
function Me(e, t) {
	return `mutation-migration-${e}-${t.toLocaleLowerCase().replace(/[^a-z0-9-]/gu, "-").slice(0, 150)}`;
}
function Ne(e, t) {
	return e.filter((e) => t ? e.ownerFaceitId === t : !e.ownerFaceitId).sort(Be);
}
function M(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function Pe(e) {
	return {
		...e,
		incidents: e.incidents.map((e) => ({
			...e,
			customBehaviorLabels: x(e.customBehaviorLabels)
		})),
		composer: e.composer ? {
			...e.composer,
			customBehaviorLabels: x(e.composer.customBehaviorLabels)
		} : void 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function Fe(e, t) {
	return [...e.map((e) => e.trim()).filter(Boolean), ...x(t).map(fe)].filter((e, t, n) => e && n.indexOf(e) === t);
}
function Ie(e) {
	let t = e.trim();
	return t.startsWith("custom:") ? fe(t.slice(7)) : t;
}
function Le(e) {
	let t = {};
	for (let [n, r] of Object.entries(e ?? {})) {
		let e = Ie(n);
		!e || !Number.isFinite(r) || r <= 0 || (t[e] = (t[e] ?? 0) + Math.floor(r));
	}
	return t;
}
function N(e, t) {
	return `${e}:${t.toLocaleLowerCase()}`;
}
function Re(e) {
	let t = e.oldValue, n = e.newValue;
	return w(t?.rosterActionLabel) !== w(n?.rosterActionLabel);
}
function ze(e) {
	return `${e.ownerFaceitId ?? ""}:${e.archiveId}`;
}
function Be(e, t) {
	return Date.parse(t.submittedAt) - Date.parse(e.submittedAt) || t.archiveId.localeCompare(e.archiveId);
}
//#endregion
//#region src/shared/api.ts
async function Ve(e) {
	let t = await k.getSettings();
	if (!t.deepgramApiKey.trim()) throw Error("Brak klucza Deepgram. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = new URLSearchParams({
		model: "nova-3",
		language: e.language,
		smart_format: "true"
	}), r = y() ? `/__frh-api/deepgram/v1/listen?${n}` : `https://api.deepgram.com/v1/listen?${n}`, i = await fetch(r, {
		method: "POST",
		headers: {
			Authorization: `Token ${t.deepgramApiKey.trim()}`,
			"Content-Type": e.mimeType || "audio/webm"
		},
		body: Ue(e.audioBase64)
	});
	if (!i.ok) throw await P("Deepgram", i);
	let a = (await i.json()).results?.channels?.[0]?.alternatives?.[0]?.transcript?.trim();
	if (!a) throw Error("Deepgram nie rozpoznał mowy w nagraniu.");
	return { transcript: a };
}
async function He(e) {
	let t = await k.getSettings();
	if (!t.xaiApiKey.trim()) throw Error("Brak klucza xAI. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = t.xaiModel.trim() || "grok-4.20-0309-non-reasoning", r = {
		model: n,
		store: !1,
		max_output_tokens: 500,
		instructions: `${t.customPrompt.trim()}\n\n${le}`,
		input: [{
			role: "user",
			content: ve(e.draft, e.mode, e.sourceReport, e.enhancementPass)
		}],
		text: { format: {
			type: "json_schema",
			name: "faceit_report",
			strict: !0,
			schema: {
				type: "object",
				properties: {
					category: {
						type: "string",
						enum: [
							"Griefing",
							"Cheating",
							"Multiple accounts or smurfing",
							"Toxicity",
							"Inappropriate content"
						]
					},
					subcategory: {
						type: "string",
						enum: [
							"Voice",
							"Chat",
							"Voice and Chat",
							"None"
						]
					},
					rounds: {
						type: "array",
						items: {
							type: "integer",
							minimum: 1,
							maximum: 60
						}
					},
					text: { type: "string" }
				},
				required: [
					"category",
					"subcategory",
					"rounds",
					"text"
				],
				additionalProperties: !1
			}
		} }
	};
	n === "grok-4.3" && (r.reasoning_effort = "none");
	let i = y() ? "/__frh-api/xai/v1/responses" : "https://api.x.ai/v1/responses", a = await fetch(i, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${t.xaiApiKey.trim()}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify(r)
	});
	if (!a.ok) throw await P("xAI", a);
	let o = await a.json(), s = o.output_text ?? o.output?.flatMap((e) => e.content ?? []).find((e) => e.text)?.text;
	if (!s) throw Error("xAI zwróciło pustą odpowiedź.");
	let c;
	try {
		c = JSON.parse(s);
	} catch {
		throw Error("xAI zwróciło odpowiedź w nieprawidłowym formacie.");
	}
	if (!c.text || !c.category || !Array.isArray(c.rounds)) throw Error("xAI zwróciło niekompletny report.");
	let l = e.mode === "normal" ? void 0 : e.sourceReport;
	return {
		...c,
		category: l?.category ?? c.category,
		subcategory: l?.subcategory ?? c.subcategory,
		rounds: l?.rounds ?? [...new Set(c.rounds)].sort((e, t) => e - t),
		text: ye(c.text)
	};
}
function Ue(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = t.charCodeAt(e);
	return n;
}
async function P(e, t) {
	let n = "";
	try {
		let e = await t.json();
		n = typeof e.error == "string" ? e.error : e.error?.message || e.message || "";
	} catch {
		n = await t.text().catch(() => "");
	}
	return /* @__PURE__ */ Error(`${e} zwróciło błąd ${t.status}${n ? `: ${n.slice(0, 240)}` : ""}`);
}
//#endregion
//#region src/background/provider.ts
async function We(e) {
	let t = await k.getSettings();
	return t.apiAccessMode === "managed" ? m.generateReport(e, t.customPrompt) : He(e);
}
async function Ge(e) {
	return (await k.getSettings()).apiAccessMode === "managed" ? m.transcribeAudio(e) : Ve(e);
}
//#endregion
//#region src/shared/side-panel-state.ts
var F = "frh:side-panel-state", I = { view: "home" };
function L(e) {
	if (!Ye(e) || !Je(e.view)) return I;
	let t = Ke(e.target);
	if (e.view === "report" && !t) return I;
	let n = qe(e.availableRound);
	return {
		view: e.view,
		...t ? { target: t } : {},
		...n === void 0 ? {} : { availableRound: n }
	};
}
function Ke(e) {
	if (!(!Ye(e) || typeof e.matchId != "string" || !e.matchId.trim() || typeof e.matchUrl != "string" || !e.matchUrl.trim() || typeof e.nickname != "string" || !e.nickname.trim() || e.relation !== "teammate" && e.relation !== "opponent" && e.relation !== "unknown")) return {
		matchId: e.matchId.trim(),
		matchUrl: e.matchUrl.trim(),
		nickname: e.nickname.trim(),
		relation: e.relation,
		...typeof e.playerId == "string" && e.playerId.trim() ? { playerId: e.playerId.trim() } : {},
		...e.startingSide === "CT" || e.startingSide === "T" ? { startingSide: e.startingSide } : {}
	};
}
function qe(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60 ? Number(e) : void 0;
}
function Je(e) {
	return e === "home" || e === "report" || e === "settings";
}
function Ye(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/side-panel.ts
function Xe() {
	return {
		configureActionClick: () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }),
		openForTab: (e) => chrome.sidePanel.open({ tabId: e }),
		openForCurrentWindow: () => chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT }),
		getState: () => new Promise((e, t) => {
			chrome.storage.session.get(F, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[F]);
			});
		}),
		setState: (e) => new Promise((t, n) => {
			chrome.storage.session.set({ [F]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		})
	};
}
function Ze(e) {
	let t = async () => L(await e.getState()), n = async (t) => {
		let n = L(t);
		return await e.setState(n), n;
	}, r = async (t) => (typeof t == "number" ? await e.openForTab(t) : await e.openForCurrentWindow(), { opened: !0 });
	return {
		configureActionClick: () => e.configureActionClick(),
		async openSettings(e) {
			let i = r(e), a = await t();
			return await Promise.all([i, n({
				...a,
				view: "settings"
			})]), { opened: !0 };
		},
		async openReport(e, t, i) {
			let a = r(i);
			return await Promise.all([a, n({
				view: "report",
				target: e,
				availableRound: t
			})]), { opened: !0 };
		},
		async updateReport(e, r) {
			let i = await t();
			return i.target?.matchId !== e.matchId || i.target.nickname.toLocaleLowerCase() !== e.nickname.toLocaleLowerCase() ? i : n({
				...i,
				target: e,
				availableRound: r
			});
		},
		async setView(e) {
			let r = await t();
			return e === "report" && !r.target ? n(I) : n({
				...r,
				view: e
			});
		},
		getState: t
	};
}
var R = Ze(Xe()), z = {
	repository: "tommyin-it/faceit-report-helper",
	assetName: "faceit-report-helper.zip",
	metadataUrl: "https://tommyin-it.github.io/faceit-report-helper/latest.json"
}, Qe = z.metadataUrl, $e = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$/, et = 65535, B = `/${z.repository}/releases`, tt = `${B}/latest/download/${z.assetName}`;
function V(e) {
	if (!$e.test(e)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	let t = e.split(".").map(Number);
	if (t.every((e) => e === 0) || t.some((e) => e > et)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	return [...t, ...Array(4 - t.length).fill(0)];
}
function nt(e, t) {
	let n = V(e), r = V(t);
	for (let e = 0; e < n.length; e += 1) if (n[e] !== r[e]) return n[e] < r[e] ? -1 : 1;
	return 0;
}
function rt(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function H(e, t) {
	if (typeof e != "string") throw Error("Brak bezpiecznego adresu wydania.");
	let n = new URL(e);
	if (n.protocol !== "https:" || n.origin !== "https://github.com" || n.pathname !== t || n.search || n.hash || n.username || n.password) throw Error("Nieprawidłowy adres wydania.");
	return n.href;
}
function U(e) {
	if (!rt(e) || e.schemaVersion !== 1 || typeof e.version != "string") throw Error("Nieprawidłowy format informacji o aktualizacji.");
	if (V(e.version), typeof e.publishedAt != "string" || !Number.isFinite(Date.parse(e.publishedAt))) throw Error("Nieprawidłowa data wydania.");
	let t = `${B}/tag/v${e.version}`, n = e.sha256;
	if (n !== void 0 && (typeof n != "string" || !/^[a-f0-9]{64}$/.test(n))) throw Error("Nieprawidłowa suma kontrolna wydania.");
	return {
		schemaVersion: 1,
		version: e.version,
		downloadUrl: H(e.downloadUrl, tt),
		releaseNotesUrl: H(e.releaseNotesUrl, t),
		publishedAt: e.publishedAt,
		...n ? { sha256: n } : {}
	};
}
function W(e, t) {
	return !t || nt(e, t.version) >= 0 ? {
		updateAvailable: !1,
		currentVersion: e
	} : {
		updateAvailable: !0,
		currentVersion: e,
		latestVersion: t.version,
		downloadUrl: t.downloadUrl,
		releaseNotesUrl: t.releaseNotesUrl,
		publishedAt: t.publishedAt
	};
}
//#endregion
//#region src/background/update.ts
var G = "frh:update-check", it = 432e5, at = 8e3, K;
function ot() {
	return new Promise((e) => {
		chrome.storage.local.get(G, (t) => {
			if (chrome.runtime.lastError) {
				e(void 0);
				return;
			}
			let n = t[G];
			if (typeof n != "object" || !n) {
				e(void 0);
				return;
			}
			let r = n;
			if (typeof r.checkedAt != "number" || !Number.isFinite(r.checkedAt)) {
				e(void 0);
				return;
			}
			try {
				e({
					checkedAt: r.checkedAt,
					...r.metadata ? { metadata: U(r.metadata) } : {}
				});
			} catch {
				e(void 0);
			}
		});
	});
}
function q(e) {
	return new Promise((t) => {
		chrome.storage.local.set({ [G]: e }, () => t());
	});
}
async function st() {
	let e = await fetch(Qe, {
		cache: "no-store",
		credentials: "omit",
		redirect: "error",
		signal: AbortSignal.timeout(at)
	});
	if (!e.ok) throw Error(`Serwer aktualizacji zwrócił błąd ${e.status}.`);
	return U(await e.json());
}
async function ct() {
	let e = chrome.runtime.getManifest().version, t = Date.now(), n = await ot();
	if (n && t - n.checkedAt < it) return W(e, n.metadata);
	try {
		let n = await st();
		return await q({
			checkedAt: t,
			metadata: n
		}), W(e, n);
	} catch {
		return await q({
			checkedAt: t,
			...n?.metadata ? { metadata: n.metadata } : {}
		}), W(e, n?.metadata);
	}
}
function lt() {
	return K ||= ct().finally(() => {
		K = void 0;
	}), K;
}
//#endregion
//#region src/shared/faceit-report.ts
var ut = {
	Griefing: {
		category: "negative",
		subCategory: "griefing"
	},
	Toxicity: {
		category: "negative",
		subCategory: "toxic"
	},
	Cheating: {
		category: "cheat",
		subCategory: "cheating"
	},
	"Multiple accounts or smurfing": {
		category: "negative",
		subCategory: "smurfing"
	},
	"Inappropriate content": {
		category: "negative",
		subCategory: "inappropriate"
	}
}, J = 1e3, dt = 160;
function ft(e) {
	let t = _t(e.matchId, "identyfikatora meczu"), n = _t(e.playerId, "FACEIT ID zgłaszanego gracza");
	if (!e.generated) throw Error("Bezpośrednia wysyłka wymaga wygenerowanego zgłoszenia.");
	let r = ut[e.generated.category];
	if (!r) throw Error("Wygenerowane zgłoszenie ma nieobsługiwaną kategorię.");
	if (typeof e.generated.text != "string") throw Error("Treść zgłoszenia ma nieprawidłowy format.");
	let i = e.generated.text.trim();
	if (!i) throw Error("Treść zgłoszenia nie może być pusta.");
	if (i.length > J) throw Error(`Treść zgłoszenia może mieć maksymalnie ${J} znaków.`);
	let a = Y(e.generated.rounds), o = a.filter((e) => e <= 24), s = a.filter((e) => e > 24).map((e) => e - 24), c = o.length > 0 || s.length > 0 ? {
		...o.length > 0 ? { rounds: o } : {},
		...s.length > 0 ? { overtimes: s } : {}
	} : void 0;
	return {
		matchId: t,
		reportedUserId: n,
		...r,
		comment: i,
		...c ? { gameData: c } : {}
	};
}
function pt(e) {
	let t = mt(e);
	if (!t) throw Error("FACEIT zwrócił nieprawidłową historię zgłoszeń.");
	return t.flatMap((e) => {
		let t = ht(e);
		return t ? [t] : [];
	});
}
function mt(e) {
	if (Array.isArray(e)) return e;
	if (Z(e)) {
		if (Array.isArray(e.payload)) return e.payload;
		if (Z(e.data) && Array.isArray(e.data.payload)) return e.data.payload;
	}
}
function ht(e) {
	if (!Z(e)) return;
	let t = X(e.matchId), n = X(e.reportedUserId), r = X(e.category), i = X(e.subCategory);
	if (!t || !n || !r || !i) return;
	let a = gt(e.gameData);
	return {
		matchId: t,
		reportedUserId: n,
		category: r,
		subCategory: i,
		comment: typeof e.comment == "string" ? e.comment.slice(0, J) : "",
		...a ? { gameData: a } : {}
	};
}
function gt(e) {
	if (!Z(e)) return;
	let t = Y(e.rounds), n = Y(e.overtimes);
	if (t.length !== 0 || n.length !== 0) return {
		...t.length > 0 ? { rounds: t } : {},
		...n.length > 0 ? { overtimes: n } : {}
	};
}
function Y(e) {
	return Array.isArray(e) ? [...new Set(e)].filter((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60).sort((e, t) => e - t) : [];
}
function _t(e, t) {
	let n = X(e);
	if (!n) throw Error(`Brak ${t}. Odśwież pokój meczu i spróbuj ponownie.`);
	return n;
}
function X(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	if (!(!t || t.length > dt)) return t;
}
function Z(e) {
	return typeof e == "object" && !!e;
}
//#endregion
//#region src/background/faceit-report.ts
var vt = "https://www.faceit.com/api/fbi/v1", Q = 3e4;
function yt(e = {}) {
	let t = {
		request: fetch,
		now: () => (/* @__PURE__ */ new Date()).toISOString(),
		...e
	};
	return {
		async submit(e) {
			let n = ft(e), r = await bt(t, xt(n.matchId), {
				method: "POST",
				credentials: "include",
				headers: St(!0),
				body: JSON.stringify(n),
				signal: AbortSignal.timeout(Q)
			});
			if (!r.ok) throw await Ct(r, "POST");
			return {
				submittedAt: t.now(),
				httpStatus: r.status
			};
		},
		async getForMatch(e) {
			let n = await bt(t, xt(e), {
				method: "GET",
				credentials: "include",
				headers: St(!1),
				signal: AbortSignal.timeout(Q)
			});
			if (!n.ok) throw await Ct(n, "GET");
			return { reports: pt(await n.json()) };
		}
	};
}
async function bt(e, t, n) {
	try {
		return await e.request(t, n);
	} catch (e) {
		let t = e instanceof Error && (e.name === "TimeoutError" || e.name === "AbortError");
		throw new v(t ? "FACEIT nie odpowiedział w ciągu 30 sekund. Sprawdź historię zgłoszeń przed ponowną wysyłką." : "Nie udało się połączyć z FACEIT. Przeglądarka mogła zablokować żądanie albo wystąpił błąd sieci.", `${n.method} /api/fbi/v1/matches/{matchId}/report\n${t ? "Przekroczono limit czasu: 30 s." : "Błąd transportu: przeglądarka nie udostępniła odpowiedzi HTTP."}\nNie można ustalić, czy FACEIT przyjął zgłoszenie ani czy minął czas na jego wysłanie.`);
	}
}
function xt(e) {
	let t = e.trim();
	if (!t || t.length > 160) throw Error("Brak prawidłowego identyfikatora meczu.");
	return `${vt}/matches/${encodeURIComponent(t)}/report`;
}
function St(e) {
	return {
		Accept: "application/json, text/plain, */*",
		"faceit-referer": "web-next",
		...e ? { "Content-Type": "application/json" } : {}
	};
}
async function Ct(e, t) {
	let n = e.status, r = [`${t} /api/fbi/v1/matches/{matchId}/report`, `HTTP ${n}`], i = $(e.headers.get("x-request-id") ?? e.headers.get("cf-ray"));
	if (i && r.push(`Identyfikator żądania: ${i}`), e.headers.get("content-type")?.includes("json")) {
		let t = await wt(e);
		if (t && typeof t == "object") {
			let e = t, n = Array.isArray(e.errors) ? e.errors.slice(0, 3) : [e.error ?? e];
			for (let e of n) if (typeof e == "string") {
				let t = $(e);
				t && r.push(`FACEIT: ${t}`);
			} else if (e && typeof e == "object") {
				let t = e, n = $(t.code), i = $(t.message);
				n && r.push(`Kod FACEIT: ${n}`), i && r.push(`FACEIT: ${i}`);
			}
		}
	} else r.push("Serwer zwrócił odpowiedź inną niż JSON. Może to być strona blokady lub weryfikacji dostępu.");
	return new v(Tt(n), r.join("\n"));
}
async function wt(e) {
	let t = e.body?.getReader();
	if (!t) return;
	let n = new TextDecoder(), r = "", i = 0;
	try {
		for (;;) {
			let { done: e, value: a } = await t.read();
			if (e) break;
			if (i += a.byteLength, i > 16384) return;
			r += n.decode(a, { stream: !0 });
		}
		return JSON.parse(r + n.decode());
	} catch {
		return;
	} finally {
		await t.cancel().catch(() => void 0);
	}
}
function $(e) {
	return typeof e != "string" && typeof e != "number" ? "" : String(e).replace(/https?:\/\/\S+/gi, "[adres pominięty]").replace(/Bearer\s+\S+/gi, "Bearer [ukryto]").replace(/(?:token|secret|password|authorization|cookie|api[_-]?key)\s*[:=]\s*\S+/gi, "[dane uwierzytelniające ukryto]").replace(/[A-Za-z0-9_\-+/=]{64,}/g, "[długi identyfikator pominięty]").replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 500);
}
function Tt(e) {
	return e === 401 ? "Zaloguj się na stronie FACEIT w tej przeglądarce i spróbuj ponownie." : e === 403 ? "FACEIT odmówił dostępu (HTTP 403). Sprawdź szczegóły błędu i zalogowanie na stronie FACEIT. Sam status nie rozstrzyga, czy minął czas na zgłoszenie." : e === 409 ? "To zgłoszenie zostało już wysłane do FACEIT (HTTP 409)." : e === 429 ? "Zbyt wiele żądań do FACEIT. Odczekaj chwilę i spróbuj ponownie." : e >= 400 && e < 500 ? `FACEIT odrzucił żądanie (HTTP ${e}). Rozwiń szczegóły błędu.` : `FACEIT jest chwilowo niedostępny (HTTP ${e}).`;
}
var Et = yt();
//#endregion
//#region src/background/index.ts
function Dt(e, t) {
	switch (e.type) {
		case "OPEN_OPTIONS": return R.openSettings(t.tab?.id);
		case "OPEN_REPORT_PANEL": return R.openReport(e.target, e.availableRound, t.tab?.id);
		case "UPDATE_REPORT_PANEL": return R.updateReport(e.target, e.availableRound);
		case "SET_SIDE_PANEL_VIEW": return R.setView(e.view);
		case "GET_SIDE_PANEL_STATE": return R.getState();
		case "CHECK_FOR_UPDATE": return lt();
		case "GET_MANAGED_ACCESS_STATUS": return m.getStatus();
		case "SIGN_IN_MANAGED_ACCESS": return m.signIn();
		case "SIGN_OUT_MANAGED_ACCESS": return m.signOut();
		case "TRANSCRIBE_AUDIO": return Ge(e);
		case "GENERATE_REPORT": return We(e);
		case "SUBMIT_FACEIT_REPORT": return Et.submit(e.draft);
		case "GET_FACEIT_MATCH_REPORTS": return Et.getForMatch(e.matchId);
		case "SYNC_ACCOUNT_REPORTS": return m.syncReports(e);
	}
}
R.configureActionClick().catch((e) => {
	console.error("Unable to configure the extension side panel.", e);
}), chrome.runtime.onMessage.addListener((e, t, n) => (Dt(e, t).then((e) => n({
	ok: !0,
	data: e
})).catch((e) => n({
	ok: !1,
	error: e instanceof Error ? e.message : "Nieznany błąd.",
	...e instanceof v && e.details ? { details: e.details } : {}
})), !0));
//#endregion
