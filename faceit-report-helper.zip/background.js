//#endregion
//#region src/shared/managed-access-config.ts
var e = t({ apiUrl: "https://faceit-report-helper-api.tomaszmiller.workers.dev" }.apiUrl);
function t(e) {
	if (typeof e != "string" || !e.trim()) return "";
	let t = new URL(e.trim());
	if (t.protocol !== "https:" || t.username || t.password || t.search || t.hash || t.pathname !== "/" && t.pathname !== "") throw Error("Managed access API URL must be a plain HTTPS origin.");
	return t.origin;
}
//#endregion
//#region src/background/managed-access.ts
var n = "frh:managed-access-session", r = 9e4;
function i() {
	return {
		getSession: () => new Promise((e, t) => {
			chrome.storage.session.get(n, (r) => {
				let i = chrome.runtime.lastError;
				i ? t(Error(i.message)) : e(r[n]);
			});
		}),
		setSession: (e) => new Promise((t, r) => {
			chrome.storage.session.set({ [n]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? r(Error(e.message)) : t();
			});
		}),
		removeSession: () => new Promise((e, t) => {
			chrome.storage.session.remove(n, () => {
				let n = chrome.runtime.lastError;
				n ? t(Error(n.message)) : e();
			});
		}),
		getRedirectUrl: (e) => chrome.identity.getRedirectURL(e),
		launchWebAuthFlow: (e) => chrome.identity.launchWebAuthFlow({
			url: e,
			interactive: !0
		}),
		fetch: (e, t) => fetch(e, t),
		now: () => Date.now()
	};
}
function a(t, n = e) {
	let i = async () => {
		let e = s(await t.getSession());
		if (!e || Date.parse(e.expiresAt) <= t.now()) {
			e && await t.removeSession();
			return;
		}
		return e;
	}, a = async (e, a) => {
		if (!n) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
		let o = await i();
		if (!o) throw Error("Zaloguj się przez FACEIT w ustawieniach rozszerzenia.");
		let s = new Headers(a.headers);
		s.set("Authorization", `Bearer ${o.token}`);
		let c = await t.fetch(new URL(e, n), {
			...a,
			headers: s,
			cache: "no-store",
			credentials: "omit",
			redirect: "error",
			signal: AbortSignal.timeout(r)
		});
		return c.status === 401 && await t.removeSession(), c;
	}, o = async () => {
		if (!n) return { state: "unconfigured" };
		if (!await i()) return { state: "signed-out" };
		let e = await a("/auth/session", { method: "GET" });
		if (e.status === 401) return { state: "signed-out" };
		if (!e.ok) throw await u(e);
		return c(await e.json());
	};
	return {
		getStatus: o,
		async signIn() {
			if (!n) throw Error("Dostęp zarządzany nie został jeszcze skonfigurowany.");
			let e = t.getRedirectUrl("faceit"), r = new URL("/auth/start", n);
			r.searchParams.set("redirect_uri", e);
			let i = await t.launchWebAuthFlow(r.href);
			if (!i) throw Error("Logowanie FACEIT zostało anulowane.");
			let a = new URL(i), c = new URL(e);
			if (a.origin !== c.origin || a.pathname !== c.pathname) throw Error("FACEIT zwrócił nieprawidłowy adres logowania.");
			let l = new URLSearchParams(a.hash.replace(/^#/, "")), u = l.get("error");
			if (u === "access_denied") throw Error("To konto FACEIT nie ma dostępu do zarządzanych usług.");
			if (u) throw Error("Nie udało się zalogować przez FACEIT.");
			let d = s({
				token: l.get("token"),
				expiresAt: l.get("expires_at"),
				user: {
					faceitId: l.get("user_id"),
					nickname: l.get("nickname")
				}
			});
			if (!d || Date.parse(d.expiresAt) <= t.now()) throw Error("FACEIT zwrócił nieprawidłową sesję.");
			return await t.setSession(d), o();
		},
		async signOut() {
			return await t.removeSession(), n ? { state: "signed-out" } : { state: "unconfigured" };
		},
		async generateReport(e, t) {
			let n = await a("/v1/generate", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					...e,
					customPrompt: t
				})
			});
			if (!n.ok) throw await u(n);
			return l(await n.json());
		},
		async transcribeAudio(e) {
			let t = await a("/v1/transcribe", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(e)
			});
			if (!t.ok) throw await u(t);
			let n = await t.json();
			if (typeof n.transcript != "string" || !n.transcript.trim()) throw Error("Usługa zarządzana zwróciła nieprawidłową transkrypcję.");
			return { transcript: n.transcript.trim() };
		}
	};
}
var o = a(i());
function s(e) {
	if (!(!d(e) || !d(e.user)) && !(typeof e.token != "string" || e.token.length < 32 || typeof e.expiresAt != "string" || !Number.isFinite(Date.parse(e.expiresAt)) || typeof e.user.faceitId != "string" || !e.user.faceitId.trim() || typeof e.user.nickname != "string" || !e.user.nickname.trim())) return {
		token: e.token,
		expiresAt: e.expiresAt,
		user: {
			faceitId: e.user.faceitId.trim(),
			nickname: e.user.nickname.trim()
		}
	};
}
function c(e) {
	if (!d(e) || !d(e.user)) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	let t = s({
		token: "x".repeat(32),
		expiresAt: e.expiresAt,
		user: e.user
	});
	if (!t) throw Error("Usługa zarządzana zwróciła nieprawidłowy status sesji.");
	if (typeof e.hasManagedAccess != "boolean") throw Error("Usługa zarządzana zwróciła nieprawidłowy status dostępu.");
	return {
		state: "signed-in",
		user: t.user,
		expiresAt: t.expiresAt,
		hasManagedAccess: e.hasManagedAccess
	};
}
function l(e) {
	if (!d(e) || typeof e.text != "string" || ![
		"Griefing",
		"Cheating",
		"Multiple accounts or smurfing",
		"Toxicity",
		"Inappropriate content"
	].includes(String(e.category)) || ![
		"Voice",
		"Chat",
		"Voice and Chat",
		"None"
	].includes(String(e.subcategory)) || !Array.isArray(e.rounds) || e.rounds.length > 60 || !e.rounds.every((e) => Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60)) throw Error("Usługa zarządzana zwróciła nieprawidłowy report.");
	return e;
}
async function u(e) {
	let t = "";
	try {
		let n = await e.json();
		typeof n.error == "string" && (t = n.error);
	} catch {
		t = "";
	}
	return Error(t || `Usługa zarządzana zwróciła błąd ${e.status}.`);
}
function d(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/shared/defaultPrompt.ts
var ee = "You write concise FACEIT CS2 player reports in natural English.\n\nUse only the incidents supplied by the user. Never invent actions, quotes, rounds, frequency, intent, or consequences. You may make the wording firm and clear, but a gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it.\n\nWrite like a normal player: short direct sentences, familiar CS terminology, no headings, no bullet lists, no em dash, no corporate language, no conclusion sentence, and no mention of AI. Focus on observable behaviour, repetition, exact rounds when provided, and how the behaviour disrupted the match. Do not report ordinary bad play as griefing.\n\nReturn a single English report even when the incidents span multiple categories. Pick only a suggested FACEIT category; the user decides where to submit it. Keep the report below 1000 characters.", te = "Turn the user's rough Polish notes into one clear, natural English FACEIT CS2 player report.\n\nThe input may contain loose words, sentence fragments, shorthand, spelling mistakes, dictated text, or several separate notes. Understand their intended meaning, combine related details, and rewrite them as complete, grammatically correct English sentences. Preserve every useful detail supplied by the user, including the reported actions, relevant context, exact rounds, repetition, communication, and the effect on the match. Translate Polish CS terminology naturally into familiar English CS terminology.\n\nUse only information supplied in the incidents. Never invent actions, quotes, rounds, frequency, intent, motives, or consequences. Do not turn an assumption into a fact. A gameplay-context item is not an offence by itself unless the user explicitly confirmed deliberate sabotage and described it. Do not report ordinary poor play as griefing.\n\nWrite like a normal player submitting a credible report: direct, factual, easy to understand, and appropriately firm. Use full sentences and smooth transitions where useful. Do not use headings, bullet lists, an em dash, corporate language, a conclusion sentence, or any mention of AI. Avoid awkward literal translations and unnecessary repetition.\n\nReturn one English report containing all relevant supplied information, even when the incidents span multiple categories. Keep it below 1000 characters.", ne = "Mandatory constraints that cannot be overridden: use only the supplied incidents; do not invent actions, quotes, rounds, frequency, intent, or consequences; do not treat ordinary poor play as griefing; return exactly one report under 1000 characters using the required JSON schema.";
//#endregion
//#region src/shared/environment.ts
function f() {
	return !!globalThis.__FRH_LOCAL_FIXTURE__;
}
//#endregion
//#region src/shared/behaviors.ts
function p(e, t, n, r, i, a) {
	return {
		id: e,
		label: t,
		promptLabel: n,
		category: r,
		actionable: !0,
		scopes: i,
		...a ? { quickFor: a } : {}
	};
}
var re = [
	p("teamflash", "Rzucanie flashy prosto w sojuszników podczas pusha", "deliberately throwing flashbangs directly at teammates during a push", "griefing", ["teammate"], ["teammate"]),
	p("team-damage", "Celowe strzelanie do teammate’ów / team damage", "deliberately shooting teammates or causing team damage", "griefing", ["teammate"], ["teammate"]),
	p("team-he", "Celowe rzucanie HE w sojuszników", "deliberately throwing HE grenades at teammates", "griefing", ["teammate"]),
	p("team-molotov", "Celowe rzucanie molotovów pod sojuszników", "deliberately throwing Molotovs under teammates", "griefing", ["teammate"]),
	p("blocking", "Bodyblockowanie teammate’a w drzwiach lub przejściu", "deliberately body-blocking a teammate in a doorway or passage", "griefing", ["teammate"], ["teammate"]),
	p("team-smoke-block", "Celowe blokowanie wejścia własnemu teamowi smoke’em", "deliberately blocking the team's entrance with a smoke grenade", "griefing", ["teammate"]),
	p("knife-nonparticipation", "Celowe bieganie z nożem i nieuczestniczenie w rundzie", "deliberately running with a knife and not participating in the round", "griefing", ["teammate"]),
	p("intentional-suicide", "Celowe popełnianie samobójstwa w rundzie", "deliberately committing suicide during a round", "griefing", ["teammate"]),
	p("bomb-separation", "Zabieranie bomby i celowe odchodzenie od reszty drużyny", "taking the bomb and deliberately moving away from the rest of the team", "griefing", ["teammate"]),
	p("bomb-at-spawn", "Celowe zostawianie bomby na spawnie", "deliberately leaving the bomb at spawn", "griefing", ["teammate"]),
	p("afk", "AFK przez znaczną część rundy", "being AFK for a significant part of the round", "griefing", ["teammate"], ["teammate"]),
	p("evading-kick", "Minimalne poruszanie się tylko w celu uniknięcia AFK/kicka", "moving only enough to avoid an AFK removal or kick", "griefing", ["teammate"]),
	p("throwing", "Celowe oddawanie rund / brak próby wygrania rundy", "deliberately giving away rounds or making no attempt to win", "griefing", ["teammate"], ["teammate"]),
	p("position-revealing-shots", "Celowe strzelanie w ściany / powietrze w celu zdradzenia pozycji drużyny", "deliberately shooting walls or the air to reveal the team's position", "griefing", ["teammate"]),
	p("spawn-molotov", "Celowe rzucanie molotovów na własnym spawnie", "deliberately throwing Molotovs at the team's own spawn", "griefing", ["teammate"]),
	p("utility-waste", "Celowe marnowanie utility drużyny", "deliberately wasting the team's utility", "griefing", ["teammate"]),
	p("refuse-defuse", "Celowe niepodejmowanie próby defuse mimo możliwości", "deliberately refusing to attempt a possible defuse", "griefing", ["teammate"]),
	p("block-plant", "Celowe utrudnianie plantowania bomby", "deliberately obstructing a bomb plant", "griefing", ["teammate"]),
	p("block-defuse", "Celowe utrudnianie rozbrajania bomby teammate’owi", "deliberately obstructing a teammate's defuse", "griefing", ["teammate"]),
	p("discard-equipment", "Celowe wyrzucanie broni/utility w miejsca niedostępne dla drużyny", "deliberately throwing weapons or utility where teammates cannot retrieve them", "griefing", ["teammate"]),
	p("mic-spam", "Ciągłe krzyczenie i zakłócanie komunikacji voice", "repeatedly shouting and disrupting voice communication", "toxicity", ["teammate"], ["teammate"]),
	p("voice-music", "Puszczanie muzyki / soundboardu przez voice chat", "playing music or a soundboard over voice chat", "toxicity", ["teammate"]),
	p("chat-spam", "Spamowanie wiadomości lub bindów na czacie", "spamming messages or binds in text chat", "toxicity", ["any"]),
	p("early-giveup-spam", "Floodowanie „gg”, „end”, „ff” itp. od początku meczu", "flooding chat with 'gg', 'end', 'ff', or similar messages from the start of the match", "toxicity", ["any"]),
	p("harassment", "Ciągłe personalne obrażanie konkretnego gracza", "repeatedly directing personal insults at a specific player", "toxicity", ["any"], ["teammate", "opponent"]),
	p("racism", "Używanie rasistowskich wyzwisk", "using racist slurs", "toxicity", ["any"], ["teammate", "opponent"]),
	p("homophobia", "Homofobiczne komentarze lub wyzwiska", "making homophobic comments or using homophobic slurs", "toxicity", ["any"]),
	p("sexism", "Seksistowskie komentarze lub wyzwiska", "making sexist comments or using sexist slurs", "toxicity", ["any"]),
	p("threats", "Grożenie innemu graczowi śmiercią lub przemocą", "threatening another player with death or violence", "toxicity", ["any"]),
	p("self-harm", "Zachęcanie innego gracza do samobójstwa / self-harm", "encouraging another player to commit suicide or self-harm", "toxicity", ["any"]),
	p("hateful-nickname", "Obraźliwy / nienawistny nickname", "using an offensive or hateful nickname", "toxicity", ["any"], ["opponent"]),
	p("hateful-avatar", "Obraźliwy / nienawistny avatar lub zdjęcie profilowe", "using an offensive or hateful avatar or profile picture", "toxicity", ["any"]),
	p("report-spam", "Spamowanie komendą !report lub nawoływanie do masowego reportowania", "spamming the !report command or calling for mass reports", "toxicity", ["any"]),
	p("wallhack", "Używanie wallhacka / informacji o przeciwniku bez możliwości ich zdobycia", "using a wallhack or enemy information that could not legitimately be obtained", "cheating", ["any"], ["opponent"]),
	p("aimbot", "Używanie aimbota / nienaturalne automatyczne namierzanie przeciwników", "using an aimbot or unnatural automatic targeting of opponents", "cheating", ["any"], ["opponent"]),
	p("triggerbot", "Triggerbot / automatyczne oddawanie strzału po wejściu przeciwnika w celownik", "using a triggerbot that automatically fires when an opponent enters the crosshair", "cheating", ["any"], ["opponent"]),
	p("aim-assistance", "Inne niedozwolone wspomaganie celowania lub recoil control", "using other prohibited aim assistance or recoil control", "cheating", ["any"]),
	p("stream-sniping", "Stream sniping w celu zdobywania informacji o przeciwniku", "stream sniping to obtain information about an opponent", "cheating", ["any"], ["opponent"]),
	p("enemy-position-ghosting", "Ghosting — przekazywanie informacji o pozycjach przeciwników bez podstaw do ich posiadania", "communicating enemy positions without a legitimate source for that information", "cheating", ["any"]),
	p("ghosting", "Przekazywanie przeciwnikom pozycji własnych teammate’ów przez all-chat", "revealing teammates' positions to opponents through all-chat", "cheating", ["any"]),
	p("smurf", "Granie na dodatkowym koncie znacznie poniżej rzeczywistego poziomu gracza", "playing on an additional account far below the player's true skill level", "smurfing", ["any"], ["opponent"]),
	p("deranking", "Celowe zaniżanie ELO/ranku, aby grać przeciwko słabszym graczom", "deliberately lowering ELO or rank to play against weaker opponents", "smurfing", ["any"]),
	p("boosting", "Boostowanie konta innego gracza poprzez grę na znacznie niższym poziomie lobby", "boosting another player's account by playing in a substantially lower-skilled lobby", "smurfing", ["any"], ["opponent"]),
	p("account-sharing", "Udostępnianie / używanie cudzego konta w celu podniesienia jego ELO", "sharing or using another person's account to raise its ELO", "smurfing", ["any"]),
	p("matchmaking-evasion", "Tworzenie nowego konta w celu obchodzenia właściwego poziomu matchmakingu", "creating a new account to evade the player's proper matchmaking level", "smurfing", ["any"])
], m = new Map(re.map((e) => [e.id, e]));
function h(e) {
	let t = e.trim().replace(/\s+/g, " ").toLocaleLowerCase();
	return t ? `custom:${t}` : "";
}
//#endregion
//#region src/shared/domain.ts
function g(e) {
	return `${e}-${crypto.randomUUID()}`;
}
function _(e) {
	let t = e.playerId || e.nickname.toLocaleLowerCase();
	return `${e.matchId}:${t}`;
}
function ie(e) {
	switch (e.kind) {
		case "single": return `Runda ${e.round}`;
		case "range": return `Rundy ${e.from}–${e.to}`;
		case "selected":
			if (e.rounds.length === 0) return "Runda nieznana";
			if (e.rounds.some((e) => e > 24)) {
				let t = [...new Set(e.rounds.filter((e) => e >= 1 && e <= 24))].sort((e, t) => e - t);
				return t.length === 0 ? "Dogrywka" : `${t.length === 1 ? `Runda ${t[0]}` : `Rundy ${y(t)}`} i dogrywka`;
			}
			return e.rounds.length === 1 ? `Runda ${e.rounds[0]}` : `Rundy ${y(e.rounds)}`;
		case "whole": return "Cały mecz";
		case "unknown": return "Bez wskazanych rund";
	}
}
function ae(e) {
	return e.trim().replace(/\s+/g, " ");
}
function v(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e ?? []) {
		let e = ae(r), i = e.toLocaleLowerCase();
		!e || n.has(i) || (n.add(i), t.push(e));
	}
	return t;
}
function y(e) {
	let t = [...new Set(e)].sort((e, t) => e - t), n = [], r = t[0], i = t[0];
	for (let e of t.slice(1)) {
		if (e === i + 1) {
			i = e;
			continue;
		}
		n.push(r === i ? `${r}` : `${r}–${i}`), r = e, i = e;
	}
	return r !== void 0 && i !== void 0 && n.push(r === i ? `${r}` : `${r}–${i}`), n.join(", ");
}
//#endregion
//#region src/shared/prompt.ts
var b = [
	"Rewrite the report in a significantly firmer, more decisive tone. Make the player's behavior sound clearly unacceptable and emphasize how seriously it disrupted the team and harmed the match. Use strong, direct language that encourages a moderator to take the report seriously. Preserve every factual detail exactly. Do not invent actions, intent, repetition, quotes, consequences, or rounds.",
	"Rewrite the report to sound forceful, urgent, and uncompromising. Clearly condemn the reported behavior and strongly emphasize its negative impact on the team and the integrity of the match. Remove soft, hesitant, or neutral wording. Make every sentence direct and impactful while remaining suitable for a FACEIT moderation report. Do not add, alter, or exaggerate any factual claims.",
	"Rewrite this report using the strongest credible language appropriate for a formal FACEIT complaint. Present the described conduct as completely unacceptable and make its disruptive impact impossible to overlook. Use sharp, authoritative, high-impact sentences and an urgent tone. The result should strongly communicate that moderator attention is warranted. Intensify only the wording and presentation - never invent or exaggerate behavior, intent, frequency, evidence, quotes, rounds, or consequences."
], oe = {
	normal: "Write a balanced, factual report. Adapt length to the evidence, normally 3 to 5 short sentences.",
	stronger: b[0]
};
function se(e, t, n, r = 1) {
	if (t !== "normal" && n) {
		let e = Math.min(3, Math.max(1, r));
		return [
			`Task: ${b[e - 1]}`,
			`Intensity pass: ${e} of 3`,
			"Edit only the latest ready English report below. Treat it as the sole source text for this rewrite.",
			"Preserve every factual claim, player identity, round number, category, and subcategory.",
			"Do not reconstruct the report from source notes and do not introduce new information.",
			`Category: ${n.category}`,
			`Subcategory: ${n.subcategory}`,
			`Rounds: ${n.rounds.length ? n.rounds.join(", ") : "none"}`,
			"Ready report:",
			n.text
		].join("\n");
	}
	let i = e.incidents.map((e, t) => {
		let n = [], r = [];
		for (let t of e.behaviorIds) {
			let e = m.get(t);
			e && (e.actionable ? n : r).push(e.promptLabel);
		}
		n.push(...v(e.customBehaviorLabels).map((e) => `user-defined offence: ${e}`));
		let i = e.rounds.kind === "unknown" ? [] : [`Time: ${ie(e.rounds)}`], a = [...e.note.trim() ? [`User note: ${e.note.trim()}`] : [], ...(e.transcriptEntries ?? []).map((e) => e.trim()).filter(Boolean).map((e, t) => `Voice note ${t + 1}: ${e}`)];
		return [
			`Incident ${t + 1}`,
			...i,
			`Offences selected: ${n.length ? n.join("; ") : "none"}`,
			`Gameplay context: ${r.length ? r.join("; ") : "none"}`,
			`User confirmed deliberate sabotage: ${e.intentionalSabotage ? "yes" : "no"}`,
			...a.length > 0 ? a : ["User details: none"]
		].join("\n");
	});
	return [
		`Reported player: ${e.nickname}`,
		`Relation: ${e.relation}`,
		`Requested version: ${oe[t]}`,
		"",
		i.join("\n\n")
	].join("\n");
}
function x(e) {
	let t = e.replace(/[—–]/g, "-").replace(/\s+/g, " ").trim();
	if (t.length <= 1e3) return t;
	let n = t.slice(0, 997), r = Math.max(n.lastIndexOf("."), n.lastIndexOf("!"), n.lastIndexOf("?"));
	if (r >= 650) return n.slice(0, r + 1);
	let i = n.lastIndexOf(" ");
	return `${n.slice(0, i > 0 ? i : 997)}...`;
}
//#endregion
//#region src/shared/preferences.ts
var S = "Zgłoś gracza";
function C(e) {
	if (typeof e != "string") return S;
	let t = e.trim().replace(/\s+/gu, " ");
	return t ? Array.from(t).slice(0, 32).join("") : S;
}
//#endregion
//#region src/shared/config.ts
var w = {
	apiAccessMode: "personal",
	xaiApiKey: "",
	deepgramApiKey: "",
	xaiModel: "grok-4.20-0309-non-reasoning",
	transcriptionLanguage: "pl",
	customPrompt: te,
	rosterActionLabel: S
}, T = {
	drafts: "frh:drafts",
	reports: "frh:reports",
	settings: "frh:settings",
	customBehaviors: "frh:custom-behaviors",
	behaviorUsage: "frh:behavior-usage"
}, E = "Zgłoś frajera";
function D() {
	return {
		get(e) {
			if (f() || typeof chrome > "u" || !chrome.storage?.local) {
				let t = localStorage.getItem(e);
				return Promise.resolve(t ? JSON.parse(t) : void 0);
			}
			return new Promise((t, n) => {
				chrome.storage.local.get(e, (r) => {
					let i = chrome.runtime.lastError;
					i ? n(Error(i.message)) : t(r[e]);
				});
			});
		},
		set(e) {
			if (f() || typeof chrome > "u" || !chrome.storage?.local) {
				for (let [t, n] of Object.entries(e)) localStorage.setItem(t, JSON.stringify(n));
				return Promise.resolve();
			}
			return new Promise((t, n) => {
				chrome.storage.local.set(e, () => {
					let e = chrome.runtime.lastError;
					e ? n(Error(e.message)) : t();
				});
			});
		},
		subscribe(e) {
			if (f() || typeof chrome > "u" || !chrome.storage?.onChanged) return () => void 0;
			let t = (t, n) => {
				n === "local" && e(t);
			};
			return chrome.storage.onChanged.addListener(t), () => chrome.storage.onChanged.removeListener(t);
		}
	};
}
function ce(e) {
	let t = Promise.resolve(), n = async () => {
		let t = await e.get(T.settings), n = {
			...w,
			...t
		};
		return n.xaiModel.trim() === "grok-4.3" && (n.xaiModel = w.xaiModel), n.customPrompt.trim() === ee.trim() && (n.customPrompt = w.customPrompt), n.apiAccessMode = t?.apiAccessMode === "managed" ? "managed" : "personal", n.rosterActionLabel = C(n.rosterActionLabel), n.rosterActionLabel === E && (n.rosterActionLabel = S), n;
	}, r = (t) => e.set({ [T.settings]: {
		...t,
		rosterActionLabel: C(t.rosterActionLabel)
	} }), i = async () => await e.get(T.drafts) ?? {}, a = async () => await e.get(T.reports) ?? [], o = (n) => {
		let r = t.catch(() => void 0).then(async () => {
			let [t, r] = await Promise.all([i(), a()]), o = await n(t, r);
			return await e.set({
				[T.drafts]: t,
				[T.reports]: r
			}), o;
		});
		return t = r, r;
	}, s = async () => de(await e.get(T.behaviorUsage));
	return {
		getSettings: n,
		saveSettings: r,
		async getBehaviorSnapshot() {
			let [t, n] = await Promise.all([e.get(T.customBehaviors), s()]);
			return {
				customBehaviors: v(t),
				usage: n
			};
		},
		async saveCustomBehaviors(t) {
			let n = v(t);
			return await e.set({ [T.customBehaviors]: n }), n;
		},
		async recordBehaviorUsage(t, n = []) {
			let r = await s(), i = le(t, n);
			for (let e of i) r[e] = (r[e] ?? 0) + 1;
			return await e.set({ [T.behaviorUsage]: r }), r;
		},
		async loadReportWorkspace(e) {
			let [t, r, o] = await Promise.all([
				i(),
				a(),
				n()
			]);
			return {
				draft: t[_(e)] ?? Object.values(t).find((t) => t.matchId === e.matchId && t.nickname.toLocaleLowerCase() === e.nickname.toLocaleLowerCase()),
				reports: r,
				matchDrafts: Object.values(t).filter((t) => t.matchId === e.matchId),
				transcriptionLanguage: o.transcriptionLanguage
			};
		},
		saveDraft(e) {
			return o((t) => {
				t[e.key] = k(e);
			});
		},
		archiveDraft(e) {
			return o((t, n) => {
				let r = {
					...k(e),
					archiveId: g("report"),
					submittedAt: (/* @__PURE__ */ new Date()).toISOString()
				};
				return n.unshift(r), delete t[e.key], [...n];
			});
		},
		deleteArchivedReport(e) {
			return o((t, n) => {
				let r = n.filter((t) => t.archiveId !== e);
				return n.splice(0, n.length, ...r), [...n];
			});
		},
		async getRosterBadges() {
			let [e, t] = await Promise.all([i(), a()]), n = /* @__PURE__ */ new Map();
			for (let t of Object.values(e)) {
				let e = A(t.matchId, t.nickname), r = n.get(e) ?? {
					draftEntries: 0,
					reports: 0
				};
				r.draftEntries += t.incidents.length, n.set(e, r);
			}
			for (let e of t) {
				let t = A(e.matchId, e.nickname), r = n.get(t) ?? {
					draftEntries: 0,
					reports: 0
				};
				r.reports += 1, n.set(t, r);
			}
			return n;
		},
		async getRosterActionLabel() {
			return (await n()).rosterActionLabel;
		},
		subscribeRosterChanges(t) {
			return e.subscribe?.((e) => {
				let n = /* @__PURE__ */ new Set();
				(T.drafts in e || T.reports in e) && n.add("badges");
				let r = e[T.settings];
				r && j(r) && n.add("action-label"), n.size > 0 && t(n);
			}) ?? (() => void 0);
		}
	};
}
var O = ce(D());
function k(e) {
	return {
		...e,
		incidents: e.incidents.map((e) => ({
			...e,
			customBehaviorLabels: v(e.customBehaviorLabels)
		})),
		composer: e.composer ? {
			...e.composer,
			customBehaviorLabels: v(e.composer.customBehaviorLabels)
		} : void 0,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function le(e, t) {
	return [...e.map((e) => e.trim()).filter(Boolean), ...v(t).map(h)].filter((e, t, n) => e && n.indexOf(e) === t);
}
function ue(e) {
	let t = e.trim();
	return t.startsWith("custom:") ? h(t.slice(7)) : t;
}
function de(e) {
	let t = {};
	for (let [n, r] of Object.entries(e ?? {})) {
		let e = ue(n);
		!e || !Number.isFinite(r) || r <= 0 || (t[e] = (t[e] ?? 0) + Math.floor(r));
	}
	return t;
}
function A(e, t) {
	return `${e}:${t.toLocaleLowerCase()}`;
}
function j(e) {
	let t = e.oldValue, n = e.newValue;
	return C(t?.rosterActionLabel) !== C(n?.rosterActionLabel);
}
//#endregion
//#region src/shared/api.ts
async function M(e) {
	let t = await O.getSettings();
	if (!t.deepgramApiKey.trim()) throw Error("Brak klucza Deepgram. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = new URLSearchParams({
		model: "nova-3",
		language: e.language,
		smart_format: "true"
	}), r = f() ? `/__frh-api/deepgram/v1/listen?${n}` : `https://api.deepgram.com/v1/listen?${n}`, i = await fetch(r, {
		method: "POST",
		headers: {
			Authorization: `Token ${t.deepgramApiKey.trim()}`,
			"Content-Type": e.mimeType || "audio/webm"
		},
		body: P(e.audioBase64)
	});
	if (!i.ok) throw await F("Deepgram", i);
	let a = (await i.json()).results?.channels?.[0]?.alternatives?.[0]?.transcript?.trim();
	if (!a) throw Error("Deepgram nie rozpoznał mowy w nagraniu.");
	return { transcript: a };
}
async function N(e) {
	let t = await O.getSettings();
	if (!t.xaiApiKey.trim()) throw Error("Brak klucza xAI. Uzupełnij go w ustawieniach rozszerzenia.");
	let n = t.xaiModel.trim() || "grok-4.20-0309-non-reasoning", r = {
		model: n,
		store: !1,
		max_output_tokens: 500,
		instructions: `${t.customPrompt.trim()}\n\n${ne}`,
		input: [{
			role: "user",
			content: se(e.draft, e.mode, e.sourceReport, e.enhancementPass)
		}],
		text: { format: {
			type: "json_schema",
			name: "faceit_report",
			strict: !0,
			schema: {
				type: "object",
				properties: {
					category: {
						type: "string",
						enum: [
							"Griefing",
							"Cheating",
							"Multiple accounts or smurfing",
							"Toxicity",
							"Inappropriate content"
						]
					},
					subcategory: {
						type: "string",
						enum: [
							"Voice",
							"Chat",
							"Voice and Chat",
							"None"
						]
					},
					rounds: {
						type: "array",
						items: {
							type: "integer",
							minimum: 1,
							maximum: 60
						}
					},
					text: { type: "string" }
				},
				required: [
					"category",
					"subcategory",
					"rounds",
					"text"
				],
				additionalProperties: !1
			}
		} }
	};
	n === "grok-4.3" && (r.reasoning_effort = "none");
	let i = f() ? "/__frh-api/xai/v1/responses" : "https://api.x.ai/v1/responses", a = await fetch(i, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${t.xaiApiKey.trim()}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify(r)
	});
	if (!a.ok) throw await F("xAI", a);
	let o = await a.json(), s = o.output_text ?? o.output?.flatMap((e) => e.content ?? []).find((e) => e.text)?.text;
	if (!s) throw Error("xAI zwróciło pustą odpowiedź.");
	let c;
	try {
		c = JSON.parse(s);
	} catch {
		throw Error("xAI zwróciło odpowiedź w nieprawidłowym formacie.");
	}
	if (!c.text || !c.category || !Array.isArray(c.rounds)) throw Error("xAI zwróciło niekompletny report.");
	let l = e.mode === "normal" ? void 0 : e.sourceReport;
	return {
		...c,
		category: l?.category ?? c.category,
		subcategory: l?.subcategory ?? c.subcategory,
		rounds: l?.rounds ?? [...new Set(c.rounds)].sort((e, t) => e - t),
		text: x(c.text)
	};
}
function P(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e += 1) n[e] = t.charCodeAt(e);
	return n;
}
async function F(e, t) {
	let n = "";
	try {
		let e = await t.json();
		n = typeof e.error == "string" ? e.error : e.error?.message || e.message || "";
	} catch {
		n = await t.text().catch(() => "");
	}
	return /* @__PURE__ */ Error(`${e} zwróciło błąd ${t.status}${n ? `: ${n.slice(0, 240)}` : ""}`);
}
//#endregion
//#region src/background/provider.ts
async function I(e) {
	let t = await O.getSettings();
	return t.apiAccessMode === "managed" ? o.generateReport(e, t.customPrompt) : N(e);
}
async function L(e) {
	return (await O.getSettings()).apiAccessMode === "managed" ? o.transcribeAudio(e) : M(e);
}
//#endregion
//#region src/shared/side-panel-state.ts
var R = "frh:side-panel-state", z = { view: "home" };
function B(e) {
	if (!U(e) || !fe(e.view)) return z;
	let t = V(e.target);
	if (e.view === "report" && !t) return z;
	let n = H(e.availableRound);
	return {
		view: e.view,
		...t ? { target: t } : {},
		...n === void 0 ? {} : { availableRound: n }
	};
}
function V(e) {
	if (!(!U(e) || typeof e.matchId != "string" || !e.matchId.trim() || typeof e.matchUrl != "string" || !e.matchUrl.trim() || typeof e.nickname != "string" || !e.nickname.trim() || e.relation !== "teammate" && e.relation !== "opponent" && e.relation !== "unknown")) return {
		matchId: e.matchId.trim(),
		matchUrl: e.matchUrl.trim(),
		nickname: e.nickname.trim(),
		relation: e.relation,
		...typeof e.playerId == "string" && e.playerId.trim() ? { playerId: e.playerId.trim() } : {},
		...e.startingSide === "CT" || e.startingSide === "T" ? { startingSide: e.startingSide } : {}
	};
}
function H(e) {
	return Number.isInteger(e) && Number(e) >= 1 && Number(e) <= 60 ? Number(e) : void 0;
}
function fe(e) {
	return e === "home" || e === "report" || e === "settings";
}
function U(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
//#endregion
//#region src/background/side-panel.ts
function pe() {
	return {
		configureActionClick: () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }),
		openForTab: (e) => chrome.sidePanel.open({ tabId: e }),
		openForCurrentWindow: () => chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT }),
		getState: () => new Promise((e, t) => {
			chrome.storage.session.get(R, (n) => {
				let r = chrome.runtime.lastError;
				r ? t(Error(r.message)) : e(n[R]);
			});
		}),
		setState: (e) => new Promise((t, n) => {
			chrome.storage.session.set({ [R]: e }, () => {
				let e = chrome.runtime.lastError;
				e ? n(Error(e.message)) : t();
			});
		})
	};
}
function me(e) {
	let t = async () => B(await e.getState()), n = async (t) => {
		let n = B(t);
		return await e.setState(n), n;
	}, r = async (t) => (typeof t == "number" ? await e.openForTab(t) : await e.openForCurrentWindow(), { opened: !0 });
	return {
		configureActionClick: () => e.configureActionClick(),
		async openSettings(e) {
			let i = await t();
			return await n({
				...i,
				view: "settings"
			}), r(e);
		},
		async openReport(e, t, i) {
			return await n({
				view: "report",
				target: e,
				availableRound: t
			}), r(i);
		},
		async updateReport(e, r) {
			let i = await t();
			return i.target?.matchId !== e.matchId || i.target.nickname.toLocaleLowerCase() !== e.nickname.toLocaleLowerCase() ? i : n({
				...i,
				target: e,
				availableRound: r
			});
		},
		async setView(e) {
			let r = await t();
			return e === "report" && !r.target ? n(z) : n({
				...r,
				view: e
			});
		},
		getState: t
	};
}
var W = me(pe()), G = {
	repository: "tommyin-it/faceit-report-helper",
	assetName: "faceit-report-helper.zip",
	metadataUrl: "https://tommyin-it.github.io/faceit-report-helper/latest.json"
}, he = G.metadataUrl, ge = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?$/, _e = 65535, K = `/${G.repository}/releases`, ve = `${K}/latest/download/${G.assetName}`;
function q(e) {
	if (!ge.test(e)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	let t = e.split(".").map(Number);
	if (t.every((e) => e === 0) || t.some((e) => e > _e)) throw Error(`Nieprawidłowy numer wersji: ${e}`);
	return [...t, ...Array(4 - t.length).fill(0)];
}
function ye(e, t) {
	let n = q(e), r = q(t);
	for (let e = 0; e < n.length; e += 1) if (n[e] !== r[e]) return n[e] < r[e] ? -1 : 1;
	return 0;
}
function be(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function J(e, t) {
	if (typeof e != "string") throw Error("Brak bezpiecznego adresu wydania.");
	let n = new URL(e);
	if (n.protocol !== "https:" || n.origin !== "https://github.com" || n.pathname !== t || n.search || n.hash || n.username || n.password) throw Error("Nieprawidłowy adres wydania.");
	return n.href;
}
function Y(e) {
	if (!be(e) || e.schemaVersion !== 1 || typeof e.version != "string") throw Error("Nieprawidłowy format informacji o aktualizacji.");
	if (q(e.version), typeof e.publishedAt != "string" || !Number.isFinite(Date.parse(e.publishedAt))) throw Error("Nieprawidłowa data wydania.");
	let t = `${K}/tag/v${e.version}`, n = e.sha256;
	if (n !== void 0 && (typeof n != "string" || !/^[a-f0-9]{64}$/.test(n))) throw Error("Nieprawidłowa suma kontrolna wydania.");
	return {
		schemaVersion: 1,
		version: e.version,
		downloadUrl: J(e.downloadUrl, ve),
		releaseNotesUrl: J(e.releaseNotesUrl, t),
		publishedAt: e.publishedAt,
		...n ? { sha256: n } : {}
	};
}
function X(e, t) {
	return !t || ye(e, t.version) >= 0 ? {
		updateAvailable: !1,
		currentVersion: e
	} : {
		updateAvailable: !0,
		currentVersion: e,
		latestVersion: t.version,
		downloadUrl: t.downloadUrl,
		releaseNotesUrl: t.releaseNotesUrl,
		publishedAt: t.publishedAt
	};
}
//#endregion
//#region src/background/update.ts
var Z = "frh:update-check", xe = 432e5, Se = 8e3, Q;
function Ce() {
	return new Promise((e) => {
		chrome.storage.local.get(Z, (t) => {
			if (chrome.runtime.lastError) {
				e(void 0);
				return;
			}
			let n = t[Z];
			if (typeof n != "object" || !n) {
				e(void 0);
				return;
			}
			let r = n;
			if (typeof r.checkedAt != "number" || !Number.isFinite(r.checkedAt)) {
				e(void 0);
				return;
			}
			try {
				e({
					checkedAt: r.checkedAt,
					...r.metadata ? { metadata: Y(r.metadata) } : {}
				});
			} catch {
				e(void 0);
			}
		});
	});
}
function $(e) {
	return new Promise((t) => {
		chrome.storage.local.set({ [Z]: e }, () => t());
	});
}
async function we() {
	let e = await fetch(he, {
		cache: "no-store",
		credentials: "omit",
		redirect: "error",
		signal: AbortSignal.timeout(Se)
	});
	if (!e.ok) throw Error(`Serwer aktualizacji zwrócił błąd ${e.status}.`);
	return Y(await e.json());
}
async function Te() {
	let e = chrome.runtime.getManifest().version, t = Date.now(), n = await Ce();
	if (n && t - n.checkedAt < xe) return X(e, n.metadata);
	try {
		let n = await we();
		return await $({
			checkedAt: t,
			metadata: n
		}), X(e, n);
	} catch {
		return await $({
			checkedAt: t,
			...n?.metadata ? { metadata: n.metadata } : {}
		}), X(e, n?.metadata);
	}
}
function Ee() {
	return Q ||= Te().finally(() => {
		Q = void 0;
	}), Q;
}
//#endregion
//#region src/background/index.ts
function De(e, t) {
	switch (e.type) {
		case "OPEN_OPTIONS": return W.openSettings(t.tab?.id);
		case "OPEN_REPORT_PANEL": return W.openReport(e.target, e.availableRound, t.tab?.id);
		case "UPDATE_REPORT_PANEL": return W.updateReport(e.target, e.availableRound);
		case "SET_SIDE_PANEL_VIEW": return W.setView(e.view);
		case "GET_SIDE_PANEL_STATE": return W.getState();
		case "CHECK_FOR_UPDATE": return Ee();
		case "GET_MANAGED_ACCESS_STATUS": return o.getStatus();
		case "SIGN_IN_MANAGED_ACCESS": return o.signIn();
		case "SIGN_OUT_MANAGED_ACCESS": return o.signOut();
		case "TRANSCRIBE_AUDIO": return L(e);
		case "GENERATE_REPORT": return I(e);
	}
}
W.configureActionClick().catch((e) => {
	console.error("Unable to configure the extension side panel.", e);
}), chrome.runtime.onMessage.addListener((e, t, n) => (De(e, t).then((e) => n({
	ok: !0,
	data: e
})).catch((e) => n({
	ok: !1,
	error: e instanceof Error ? e.message : "Nieznany błąd."
})), !0));
//#endregion
